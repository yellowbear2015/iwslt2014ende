#!/usr/bin/perl

use strict;

my %phrasebook = ();
my %testngram = ();
my %testngram_fq = ();


my $phrasenum = 0;

if($ARGV[0] =~ /\.gz$/) {
  open WL, "zcat $ARGV[0] | " or die "Can't open phrase book $ARGV[0]. $!\n";
}
else {
  open WL, $ARGV[0] or die "Can't open phrase book $ARGV[0]. $!\n";
}
while(<WL>) {
    print STDERR "Read $phrasenum phrases ...\n" if ($phrasenum++ % 10000 == 0);
    chomp;
    s/^\s*//g; s/\s*$//g;
    $phrasebook{$_} = 1;
}
close WL;

print "Read ", scalar(keys %phrasebook), " phrases.\n";

my %totaltype = ();
my %totalfq = ();

open FILE, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
while(<FILE>) {
    chomp;
    my ($ngram, $fq) = split "\t";
    $ngram =~ s/^\s*//g;
    $ngram =~ s/\s*$//g;
    my @ngwords = split " ", $ngram;
    my $len = $#ngwords+1;
    $totalfq{$len} += $fq;
    $totaltype{$len} ++;
    if(exists $phrasebook{$ngram}) {
        print "Covered: $ngram\n";
        $testngram{$len}++;
        $testngram_fq{$len} += $fq;
    }
}
close FILE;



print "n-gram\t\ttype\t\ttoken\n";

foreach my $len (sort {$a <=> $b} keys %testngram) {
    printf "$len\t\t$testngram{$len}/$totaltype{$len} %6.2f\t\t$testngram_fq{$len}/$totalfq{$len} %6.2f\n", $testngram{$len}/$totaltype{$len}, $testngram_fq{$len}/$totalfq{$len};
}
