#!/bin/bash
java -cp /home/feihuang/Download/stanford-word-segmenter/stanford-segmenter-2014-01-04/seg.jar  -mx8g edu.stanford.nlp.international.arabic.process.ArabicSegmenter -loadClassifier /home/feihuang/Download/stanford-word-segmenter/stanford-segmenter-2014-01-04/data/arabic-segmenter-atbtrain.ser.gz -prefixMarker '+' -suffixMarker '+' -nthreads 8 < $1 
