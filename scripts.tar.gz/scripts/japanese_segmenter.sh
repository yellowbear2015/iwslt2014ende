#! /bin/bash

cat $1 | perl -nae 'chomp; s/([\x00-\x7f]+?) ([\x00-\x7f]+?)/\1 _SPACE_ \2/g; print "$_ END_OF_LINE\n";'  | perl -pe 's/ //g;' > $1.pretag
chasen -i w $1.pretag > $1.pretag.seg
cat $1.pretag.seg | cut -f 1 | tr "\n" " " | perl -pe 's/EOS//g; s/E\s*N\s*D\s*_\s*O\s*F\s*_\s*L\s*I\s*N\s*E/\n/g;' | ~feihuang/bin/filter_invalid_utf8.pl | perl -CSD  ~feihuang/bin/concat_ascii.pl
#rm $1.pretag $1.pretag.seg
