#!/usr/bin/perl
open FILE0, $ARGV[0] or die;
open FILE1, $ARGV[1] or die;
while($score = <FILE0>) {
    $label=<FILE1>;
    $dict{$sore} = $label;
}

