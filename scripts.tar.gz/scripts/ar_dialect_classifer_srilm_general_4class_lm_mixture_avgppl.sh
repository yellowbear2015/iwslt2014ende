#!/bin/bash

~/Download/srilm/bin/i686-m64/ngram -lm /home/feihuang/Download/AOC-dialectal-annotations_indiv/new_data/ab/egy.train.1g.srilm  -ppl $2 -debug 1 | /home/feihuang/bin/compute_avg_logprob_from_srilm_perp.pl  > $2.0.label
~/Download/srilm/bin/i686-m64/ngram -lm /home/feihuang/Download/AOC-dialectal-annotations_indiv/new_data/ab/gul.train.1g.srilm  -ppl $2 -debug 1 | /home/feihuang/bin/compute_avg_logprob_from_srilm_perp.pl  > $2.1.label
~/Download/srilm/bin/i686-m64/ngram -lm /home/feihuang/Download/AOC-dialectal-annotations_indiv/new_data/ab/lev.train.1g.srilm  -ppl $2 -debug 1 | /home/feihuang/bin/compute_avg_logprob_from_srilm_perp.pl  > $2.2.label
~/Download/srilm/bin/i686-m64/ngram -lm /home/feihuang/Download/AOC-dialectal-annotations_indiv/new_data/ab/msa.train.1g.srilm  -ppl $2 -debug 1 | /home/feihuang/bin/compute_avg_logprob_from_srilm_perp.pl  > $2.3.label

~/Download/srilm/bin/i686-m64/ngram -lm $1/egy.train.1g.srilm  -ppl $2 -debug 1 | /home/feihuang/bin/compute_avg_logprob_from_srilm_perp.pl  > $2.0.unlabel
~/Download/srilm/bin/i686-m64/ngram -lm $1/gul.train.1g.srilm  -ppl $2 -debug 1 | /home/feihuang/bin/compute_avg_logprob_from_srilm_perp.pl > $2.1.unlabel
~/Download/srilm/bin/i686-m64/ngram -lm $1/lev.train.1g.srilm  -ppl $2 -debug 1 | /home/feihuang/bin/compute_avg_logprob_from_srilm_perp.pl  > $2.2.unlabel
~/Download/srilm/bin/i686-m64/ngram -lm $1/msa.train.1g.srilm  -ppl $2 -debug 1 | /home/feihuang/bin/compute_avg_logprob_from_srilm_perp.pl  > $2.3.unlabel

paste $2.0.label $2.0.unlabel | perl -nae '$weight = 0.5; @sco = split " "; print $sco[-1] * $weight + $sco[1] * (1-$weight), "\n"' > $2.0
paste $2.1.label $2.1.unlabel | perl -nae '$weight = 0.5; @sco = split " "; print $sco[0] * $weight + $sco[1] * (1-$weight), "\n"' > $2.1
paste $2.2.label $2.2.unlabel | perl -nae '$weight = 0.5; @sco = split " "; print $sco[0] * $weight + $sco[1] * (1-$weight), "\n"' > $2.2
paste $2.3.label $2.3.unlabel | perl -nae '$weight = 0.5; @sco = split " "; print $sco[0] * $weight + $sco[1] * (1-$weight), "\n"' > $2.3

paste -d ' ' $2.0 $2.1 $2.2 $2.3 | perl -nae '@name=("egy", "gul", "lev", "msa"); @data = split " "; $idxMax=0; $data[$idxMax] > $data[$_] or $idxMax = $_ for 1 ..$#data;  print "$name[$idxMax]\n";' > $2.dialectID.4class.$3
