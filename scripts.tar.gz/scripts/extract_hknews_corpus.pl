#!?usr/bin/perl
open EN, $ARGV[0] or die;
while(<EN>) {
    if(/<DOC docid="(.+?)" language="English">/) {
        $docid = $1;
    }
    if(/<seg id=(.+?)> (.+?) <\/seg>/) {
        $sentid = $1;
        $sent = $2;
        $enmap{"$docid:$sentid"} = $sent;
    }
}
close EN;
open ZH, $ARGV[1] or die;
while(<ZH>) {
     if(/<DOC docid="(.+?)" language="Chinese">/) {
        $docid = $1;
    }
    if(/<seg id=(.+?)> (.+?) <\/seg>/) {
        $sentid = $1;
        $sent = $2;
        $zhmap{"$docid:$sentid"} = $sent;
    }
}
close ZH;
open ALI, $ARGV[2] or die;
$path = $ARGV[1];
while(<ALI>) {
    if(/<ALIGNMENT docid="(.+?)" LanguagePair="English,Chinese">/) {
        $docid = $1;
    }
    if(/<SentPair EnglishSegId= "(\d+)" ChineseSegId= "(\d+)" ><\/SentPair>/) {
        $enid = $1;
        $zhid = $2;
        print $enmap{"$docid:$enid"}, "\n";
        print $zhmap{"$docid:$zhid"}, "\n";
        print "-----\n";
    }
}
close ALI;
