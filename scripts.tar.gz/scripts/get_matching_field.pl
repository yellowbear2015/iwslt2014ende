#!/usr/bin/perl
$keptclassname = $ARGV[1];
@keptcls = split ",", $keptclassname;

$removeclassname = $ARGV[2];
@remcls = split ",", $removeclassname;

open FILE, $ARGV[0] or die;
while(<FILE>) {
  $txt .= $_;
}

$txt=~ s/\n/XXXXXXXX/g;

$txt0 = "";
foreach $cl (@keptcls) {
  while($txt =~ /<span class=\"$cl\">(.+?)<\/span>/g) {
      $txt0 .= $1;
  }
}

$txt1 = "";
while($txt0 =~ /<p>(.+?)<\/p>/g) {
      $txt1 .= $1;
      $txt1 .= "XXXXXXXX";
}




foreach $cl (@remcls) {
  $txt1 =~ s/<span class=\"$cl\">(.+?)<\/span>//g;
}

$txt1 =~ s/<(.+?)>//g;


$txt1 =~ s/XXXXXXXX/\n/g;
print "$txt1";
print "\n";
