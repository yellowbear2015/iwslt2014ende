#!/bin/bash
cat $1 | grep -B 1 'TRANSLATED AS' | perl -nae 's/\n/|||/g; s/TRANSLATED AS://g; print' | perl -pe 's/\|\|\|\-\-\|\|\|/\n/g; s/\|\|\|/ \|\|\|/g;' | perl -pe 's/^\s+SOURCE://g;' 
