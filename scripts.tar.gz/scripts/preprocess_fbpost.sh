#!/bin/bash
python ~/bin/unescape-unicode.py $1 $1.utf8
~/fbcode/_bin/language_technology/yoda /mnt/vol/language_technology_mt/models/tp-gen-en-051214/ inscript $1.utf8 |  ~/bin/remove_tp_tag.sh
