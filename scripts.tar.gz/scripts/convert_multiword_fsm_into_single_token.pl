#!/usr/bin/perl

use strict;

open FILE, $ARGV[0] or die;
open NFSM, ">$ARGV[0].st" or die;
open DICT, ">$ARGV[0].sym" or die;

my %dict = ();
my $fsm_flag = 0;
while(<FILE>) {
    if(/END_OF_FSM/) {
        $fsm_flag = 0;
    }
    if(/BEING_OF_FSM/){
        <FILE>;
        $fsm_flag =1;
        next;
    }
    if($fsm_flag == 1) {
        my @w = split "\t";
        if($#w == 3 ) {
            #$w[2] =~ s/ /ReplaceWhiteSpaceToMakeFSMHappy/g;
            $w[2] =~ s/ /_/g;
            $dict{$w[2]} = 1;
        }
        print NFSM join "\t", @w;
    }

}

my $t = 1;
foreach my $d (keys %dict) {
    next if($d eq "");
    print DICT "$d $t\n";
    $t++;
}

close DICT;
close NFSM;
close FILE;
