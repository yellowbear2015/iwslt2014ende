#!/usr/bin/perl


print "<mteval>\n";
print "<srcset setid=\"foo\" srclang=\"src\">\n";
print "<doc docid=\"foo.0\", genre=\"0\">\n";

my $segid = 0;
while(<>) {
  chomp;
  print "<seg id=\"$segid\"> $_ <\/seg>\n";
}
print "<\/doc>\n<\/srcset>\n<\/mteval>\n";
