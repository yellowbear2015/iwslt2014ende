#!/bin/sh

cat $1 | perl -nae 'chomp; $count++; $sum += $_; print "$sum\t", $sum/$count,"\n";' | tail -1
