#!/usr/bin/perl
while(<>) {
  chomp;
  ($src, $tgt, $rate) = split "\t";
  $map{join "-", $src, $tgt} += $rate;
  $count{join "-", $src, $tgt} += 1;
}

foreach $p (keys %map) {
  $map{$p} /= $count{$p};
  print "$p\t$map{$p}\t$count{$p}\n";
}
