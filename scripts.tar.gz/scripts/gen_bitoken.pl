#!/usr/bin/perl
open FILE0, $ARGV[0] or die "Can't open source file. $!\n";
open FILE1, $ARGV[1] or die "Can't open target file. $!\n";
open FILE2, $ARGV[2] or die "Cna't open alignment file. $!\n";

while($src=<FILE0>) {
  $tgt = <FILE1>;
  $al = <FILE2>;
  @swords = split " ", $src;
  @twords = split " ", $tgt;
  @align = split " ", $al;
  #print "=====================================================\n";
  #print "$src$tgt$al";
  foreach $e (@align) {
    ($spos, $tpos) = split "-", $e;
    $twords[$tpos] .= "_".$swords[$spos]
    #print "$swords[$spos] <==> $twords[$tpos]\n";
  }
  for($t = 0; $t <= $#twords; $t++) {
    print "$twords[$t] ";
  }
  print "\n";
  #print "=====================================================\n";
}
