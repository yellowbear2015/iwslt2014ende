#!/bin/bash
cat $1 | grep -P '\t1' | head -80 >> $1.sample
cat $1 | grep -P '\t2' | head -80 >> $1.sample
cat $1 | grep -P '\t3' | head -80 >> $1.sample
cat $1 | grep -P '\t4' | head -80 >> $1.sample
cat $1 | grep -P '\t5' | head -80 >> $1.sample

cat $1.sample | perl -nae 'print if($t++ % 2 == 0);' > $1.sample.train
cat $1.sample | perl -nae 'print if($t++ % 2 == 1);' > $1.sample.test

cat $1.sample.train | cut -f 1,2 > $1.sample.train.txt
cat $1.sample.train | cut -f 3 > $1.sample.train.rating
cat $1.sample.test | cut -f 1,2 > $1.sample.test.txt
cat $1.sample.test | cut -f 3 > $1.sample.test.rating
/home/feihuang/bin/FeatureGeneratorConsole $2 $1.sample.train.txt > $1.sample.train.feat
paste -d  ' ' $1.sample.train.rating $1.sample.train.feat > $1.sample.train.rating_feat
/home/feihuang/bin/mtconfest_train.par --svm_type=4 --kernel_type=2  --train_feature_file=$1.sample.train.rating_feat --model_output=$1.sample.train.model
/home/feihuang/bin/FeatureGeneratorConsole $2 $1.sample.test.txt $1.sample.train.model > $1.sample.test.pred
cat $1.sample.test.pred | cut -f 2 -d ' ' > $1.sample.test.pred_label
/home/feihuang/bin/precision_acceptance_curve.par $1.sample.test.rating $1.sample.test.pred_label
