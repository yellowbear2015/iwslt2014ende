#!/usr/bin/perl

while(<>) {
  chomp;
  @wds = split " ";
  print $#wds+1, "\n";
}
