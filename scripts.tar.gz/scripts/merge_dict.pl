#!/usr/bin/perl

my %atbmap = ();
open FILE, $ARGV[0];
while(<FILE>) {
    chomp;
    ($ar, $fq) = split "\t";
    $atbmap{$ar} += $fq;
}
close FILE;
open FILE, $ARGV[1];
while(<FILE>) {
      chomp;
      ($ar, $fq) = split "\t";
      $atbmap{$ar} += $fq;
}
foreach $ar (sort { $atbmap{$b} <=> $atbmap{$a} } keys %atbmap) {
        print "$ar\t$atbmap{$ar}\n";
}
