#!/usr/bin/perl

=for comment

s1: remove repeated letters

generate candidates

s2: split string into words
s3: generate candidate based on editng distance
s4: convert word into IPA, generate word according to IPA sequence
s5: map word into normalized form according to dictionary

4=>for
2=>to
str8=>straight


=cut

while(<>) {
    chomp;
    #print;
    s/\s*http(\S+)\s*/ _URL_ /g;
    #print;
    if(!/\@URL/) {
        s/\s*\S*\@\S*\s*/ _EMAIL_ /g;
    }
    #print;
    s/\s[0-9]+\s/ _NUM_ /g;
    #print;
    if(!/www\./) {
        s/([a-zA-Z])(\1+)/\1\1/g;
    }
    print "$_\n";
}
