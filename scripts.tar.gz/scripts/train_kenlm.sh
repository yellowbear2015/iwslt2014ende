#/bin/bash
filename=`basename $1`
cp $1 /tmp/$filename
~/bin/lmplz -o $2 -S 2G < /tmp/$filename > /tmp/$filename.$2g.arpa
~/bin/build_binary trie -q 8 /tmp/$filename.$2g.arpa /tmp/$filename.$2g.trie.q8.kenlm
mv /tmp/$filename.$2g.trie.q8.kenlm $1.$2g.trie.q8.kenlm
rm /tmp/$filename.$2g.arpa
