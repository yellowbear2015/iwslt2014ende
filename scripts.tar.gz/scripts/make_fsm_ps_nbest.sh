#!/bin/bash
SYM=$1
TXT=$2
~/Download/fsm-4.0/bin/fsmcompile -i $SYM < $TXT > $TXT.fsa
#~/Download/fsm-4.0/bin/fsmdraw -i $SYM < $TXT.fsa | dot -Tps > $TXT.ps
~/Download/fsm-4.0/bin/fsmbestpath -n 1 < $TXT.fsa > $TXT.fsa.1best
#~/Download/fsm-4.0/bin/fsmprint -i $SYM < $TXT.fsa.5best | perl -≈bpe 's/ReplaceWhiteSpaceToMakeFSMHappy/ /g;' > $TXT.5best
~/Download/fsm-4.0/bin/fsmprint -i $SYM < $TXT.fsa.1best  > $TXT.1best
cat $TXT.1best | cut -f 3 | tr "\n" " " | perl -nae 's/ReplaceWhiteSpaceToMakeFSMHappy/ /g; print "$_\n";'
