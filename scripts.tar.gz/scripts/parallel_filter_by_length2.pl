#!/usr/bin/perl
open FILE0, $ARGV[0] or die;
open FILE1, $ARGV[1] or die;

$max_len=175;

if($ARGV[2] ne "") {
  $max_len = $ARGV[2];
}
while($src=<FILE0>) {
  $tgt=<FILE1>;
  @srcwords = split " ", $src;
  @tgtwords = split " ", $tgt;
  if($#srcwords <= $max_len && $#tgtwords <= $max_len) {
    print "1\n"; 
  }
  else {
    print "0\n";
  }
}
close FILE1;
close FILE2;

