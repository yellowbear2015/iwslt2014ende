cat $1 | perl -pe 's/\@(HASHTAG|URL|LAUGHTER|MULTIPUNCT|EMOTICON|NUMERIC|NUMBER.ordinal|DATE.year|DATE.dayofweek|DATE.month |TIME|INTERNETLANGUAGE|DATE|NUMBER.sequence) { (.+?) }/ \2 /g;' 
