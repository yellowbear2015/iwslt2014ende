#!/usr/bin/perl

while($sentid=<>) {
    $src=<>;
    $trans1=<>;
    $trans2=<>;
    $trans3=<>;
    if($trans1 eq $trans2 && $trans2 eq $trans3) {
        next;
    }
    else {
        print $sentid,$src,$trans1,$trans2,$trans3;
    }
}
