#!/usr/bin/perl

while(<>) {
    chomp;
    @w = split " ";
    for($i = 0; $i <= $#w; $i++) {
        print "$i-$i ";
    }
    print "\n";
}
