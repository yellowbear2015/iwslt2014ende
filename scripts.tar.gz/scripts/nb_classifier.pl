#!/usr/bin/perl
open MODELLIST, $ARGV[0] or die "Can't open model list file. $!\n";
while($filename=<MODELLIST>) {
  chomp $filename;
  open FILE, $filename or die "can't open $filename. $!\n";
  while(<FILE>) {
    chomp;
    ($wd, $wg) = split "\t";
    $models{$filename}{$wd}=$wg;
  }
  close FILE;
}
close MODELLIST;


open TEST, $ARGV[1] or die "Can't open test file. $!\n";
while(<TEST>) {
  chomp;
  @words = split " ";
  foreach $m (keys %models) {
    $scores{$m} = 0;
  }
  foreach $w (@words) {
    foreach $m (keys %models) {
      if(exists $models{$m}{$w}) {
        $scores{$m} += log($models{$m}{$w});
      }
      else {
        $scores{$m} += -10;
      }
    }
  }
  $maxscore = -9999;
  $maxm = "unk";
  foreach $m (keys %models) {
    if($maxscore < $scores{$m}) {
      $maxscore = $scores{$m};
      $maxm = $m;
    }
  }
  print "$maxm\t$maxscore\n";
}
close TEST;
