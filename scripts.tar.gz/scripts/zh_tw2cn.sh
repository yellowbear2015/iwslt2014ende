#!/bin/bash
cat $1 | /home/feihuang/bin/yoda_batch_runner --fbpkg_config=language_technology.translation.yoda.core.zh_TW.tw2cn:3 --usage=default
#cat $1 | /mnt/vol/gfsetlprocstore-oregon/fblearner/flow/data/fbpkgs/.staging/ad42c1f0-94a2-4543-b341-0f37626fff27/language_technology.translation.yoda.bin/6/yoda_batch_runner --fbpkg_config=language_technology.translation.yoda.core.zh_TW.tw2cn:3 --usage=default
