#!/usr/bin/perl


open FILE, $ARGV[0] or die;
my $sysid = $ARGV[1];

$sysid = "foo" if($sysid eq ""); 

print "<mteval>\n";
print "<refset setid=\"foo\" srclang=\"src\" trglang=\"trg\">\n";
print "<doc docid=\"foo.0\" genre=\"0\" sysid=\"$sysid\">\n";

my $segid = 0;
while(<FILE>) {
  chomp;
  print "<seg id=\"$segid\"> $_ <\/seg>\n";
}
print "<\/doc>\n<\/refset>\n<\/mteval>\n";
