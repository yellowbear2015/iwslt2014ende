#!/bin/bash
srccorpus=$1
tgtcorpus=$2
alignment=$3
outputdir=$4

echo "extract phrases..."

perl /home/feihuang/bin/FBinary/jedi/scripts/generic/extract-parallel.perl 19 split "sort --buffer-size=11333M" /home/feihuang/bin/FBinary/jedi/bin/extract $tgtcorpus $srccorpus $alignment $outputdir/extract 6 orientation --model wbe-msd --GZOutput

echo "extract lexicon..."
perl /home/feihuang/bin/FBinary/jedi/scripts/training/get-lexical.perl $srccorpus $tgtcorpus $alignment $outputdir/lex

echo "score e2f..."
perl /home/feihuang/bin/FBinary/jedi/scripts/generic/score-parallel.perl 19 "sort --buffer-size=38000M"   /home/feihuang/bin/FBinary/jedi/bin/score $outputdir/extract.inv.sorted.gz $outputdir/lex.e2f $outputdir/phrase_table_half.e2f.gz --Inverse 1

echo "score f2e..."
perl /home/feihuang/bin/FBinary/jedi/scripts/generic/score-parallel.perl 19 "sort --buffer-size=38000M"   /home/feihuang/bin/FBinary/jedi/bin/score $outputdir/extract.sorted.gz $outputdir/lex.f2e $outputdir/phrase_table_half.f2e.gz  --GoodTuring 0

echo "consolidate phrase table..."
/home/feihuang/bin/FBinary/jedi/bin/consolidate $outputdir/phrase_table_half.f2e.gz $outputdir/phrase_table_half.e2f.gz /dev/stdout --GoodTuring $outputdir/phrase_table_half.f2e.gz.coc | pigz --processes 19 --stdout > $outputdir/phrase_table.gz

echo "extract reordering table..."
/mnt/vol/gfsfblearner-carolina/flow/data/fbpkgs/.staging/20ee2226-9a44-405e-975a-4525b177dccf/language_technology.translation.jedi.bin/54/jedi/bin/lexical-reordering-score     $outputdir/extract.o.sorted.gz  0.5 $outputdir/reordering-table.  --model   "wbe msd wbe-msd-bidirectional-fe"
