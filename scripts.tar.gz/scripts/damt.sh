#!/bin/bash

srclang=$1
tarlang=$2
source_data=$3
target_data=$4
work_dir=$5
/home/feihuang/Download/word2vec/word2vec -train $source_data -output $work_dir/vectors.all.$srclang.d300 -cbow 0 -size 300 -window 11 -negative 0 -hs 1 -sample 1e-3 -threads 4  -min-count 2
/home/feihuang/Download/word2vec/word2vec -train $target_data -output $work_dir/vectors.all.$tarlang.d300 -cbow 0 -size 300 -window 11 -negative 0 -hs 1 -sample 1e-3 -threads 4  -min-count 2

linenum=`wc -l $work_dir/vectors.all.$srclang.d300 | cut -f1 -d' '`
src_voc_size=`expr $linenum - 1 `
tail -$src_voc_size vectors.all.$srclang.d300 | cut -d' ' -f1 > $work_dir/all.$srclang.d300.vec.vocab
tail -$src_voc_size vectors.all.$srclang.d300 | cut -d' ' -f2-301 > $work_dir/all.$srclang.d300.vec

linenum=`wc -l $work_dir/vectors.all.$tarlang.d300 | cut -f1 -d' '`
tar_voc_size=`expr $linenum - 1 `
tail -$tar_voc_size vectors.all.$tarlang.d300 | cut -d' ' -f1 > $work_dir/all.$tarlang.d300.vec.vocab
tail -$tar_voc_size vectors.all.$tarlang.d300 | cut -d' ' -f2-301 > $work_dir/all.$tarlang.d300.vec
