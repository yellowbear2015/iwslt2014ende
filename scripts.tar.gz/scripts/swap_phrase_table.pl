#!/usr/bin/perl

while(<>) {
  @w = split "\Q|||\E"; 
  @m = split " ", $w[3]; 
  $newal = " "; 
  foreach $k (@m) { 
    ($f, $t) = split "-", $k;
    $newal .= $t."-".$f. " ";
  }
  $w[3] = $newal;
  print "$w[1]|||$w[0]|||$w[2]|||$w[3]|||$w[4]\n";
}
