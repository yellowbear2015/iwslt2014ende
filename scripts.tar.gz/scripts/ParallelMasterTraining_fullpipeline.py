from __future__ import division
import os
import sys
import string
import re
import fileinput
import subprocess

from multiprocessing import Pool
from time import time




steps = [1, 2, 2.5, 3, 4, 4.5, 5]#, 6, 7, 8, 9]
#steps = [5]
parallel_processes = 16
opt_filter_unbalanced_moses_phrases = 1
maxTranslationAlternative = 50
vocSize = "4G"  # 64K or 4G


pandoraBin = "/home/rottmann//fbcode/_bin/language_technology/pandora"
externalEvaluationScript = "/home/rottmann/SystemConv/mosesdecoder/scripts/generic/multi-bleu.perl"
cleanCorpusScript = "/home/rottmann/SystemConv/MasterScriptNeeds/clean-corpus-n.perl"
phraseTableExtractionScript = "/home/rottmann/SystemConv/mosesdecoder/scripts/training/train-model.perl"
moseBinary = "/home/rottmann/SystemConv/mosesdecoder/bin/moses"
mertScript = "/home/rottmann/SystemConv/mosesdecoder/scripts/training/mert-moses.pl"
ngramCount = "/home/rottmann/SystemConv/srilm/bin/i686-m64/ngram-count"
combineMultipleScoreMosesTdToSingleScorePanDoRATd = "/home/rottmann/SystemConv/MasterScriptNeeds/combineMultipleScoreMosesTdToSingleScorePanDoRATdWithFiltering.pl"
perl_sort_uniq = "/home/rottmann/SystemConv/MasterScriptNeeds/perluniqsort_stdio.pl"

filterUnbalancedMosesPhrases  = "/home/rottmann/SystemConv/MasterScriptNeeds/filterUnbalancedMosesPhraseEntries.pl"
filterUnbalancedPhraseEntries = "/home/rottmann/SystemConv/MasterScriptNeeds//filterUnbalancedPhraseEntries.pl"
filterTdContainingTooLongToken = "/home/rottmann/SystemConv/MasterScriptNeeds/filterTooLongTokenEntries.pl"

extractInfoFromPhrasebook = "/home/rottmann/SystemConv/MasterScriptNeeds/preparePhraseBook.pl"

offline_pandora_model_coversion = "/home/rottmann/SystemConv/MasterScriptNeeds/offline.preproc.linux.no-lm-training.pl"

#utility scripts
filterOutIllegalChar = "/home/rottmann/SystemConv/MasterScriptNeeds/filterOutIllegalChar.pl"
outputCorpusWithUniqSentences = "/home/rottmann/SystemConv/MasterScriptNeeds/outputCorpusWithUniqSentences.pl"

discountMethod = "ukndiscount"  # -ukndiscount1 for original KN smoothing
                                  # -kndiscount for KN Kneser-Ney discount parameter file


if discountMethod == "ukndiscount":
    discountMethod1 = "ukndiscount1"
    discountMethod2 = "ukndiscount2"
    discountMethod3 = "ukndiscount3"
    discountMethod4 = "ukndiscount4"
    discountMethod5 = "ukndiscount5"

else:
	discountMethod1 = "kndiscount1"
	discountMethod2 = "kndiscount2"
	discountMethod3 = "kndiscount3"
	discountMethod4 = "kndiscount4"
	discountMethod5 = "kndiscount5"




sentenceLengthLimit = 80

# pandora tuning settings
srcTgtLMScales = [100]
srcTgtTMScales = [40]
#srcTgtTMScales = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100]
srcTgtRMScales = [1400]
srcTgtReorderWindows = [5]
srcTgtBeamSizes = [15]

tgtSrcLMScales = [100]
tgtSrcTMScales = [40]
#tgtSrcTMScales = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100]
tgtSrcRMScales = [1400]
tgtSrcReorderWindows = [5]
tgtSrcBeamSizes = [15]


#--------------------------- Step 1: check if all files needed exist ----------------------------
def check_if_files_exist(src_tag_file, tgt_tag_file):
	if not os.path.isfile(src_tag_file):
		print src_tag_file+" does not exist"
		return False
	if not os.path.isfile(tgt_tag_file):
		print tgt_tag_file+" does not exist"
		return False

	return True

#--------------------------- Step 2: remove training directories ----------------------------
def remove_training_directories():
	os.system("rm -rf training")
	os.system("rm -rf pandora")
	return True


#--------------------------- Step 2.5: remove training directories ----------------------------
def create_training_directories(srcLangExt, tgtLangExt):
	os.system("mkdir training")
	os.system("mkdir pandora")

	os.system("mkdir training/"+srcLangExt+"-"+tgtLangExt)
	os.system("mkdir training/"+srcLangExt+"-"+tgtLangExt+"/corpus")
	os.system("mkdir training/"+srcLangExt+"-"+tgtLangExt+"/lm")


	#for tgt->src direction
	os.system("mkdir training/"+tgtLangExt+"-"+srcLangExt)
	os.system("mkdir training/"+tgtLangExt+"-"+srcLangExt+"/corpus")
	os.system("mkdir training/"+tgtLangExt+"-"+srcLangExt+"/lm")
	return True


#--------------------------- Step 3: clean up corpus -------------------------------------------
def clean_up_corpus(trainingCorpusDir, trainingStem, srcLangExt, tgtLangExt):
	print "perl "+cleanCorpusScript+" "+trainingCorpusDir+"/"+trainingStem+" "+srcLangExt+" "+tgtLangExt+" training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+" 1 "+str(sentenceLengthLimit)
	os.system("perl "+cleanCorpusScript+" "+trainingCorpusDir+"/"+trainingStem+" "+srcLangExt+" "+tgtLangExt+" training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+" 1 "+str(sentenceLengthLimit))

	#filter out illegal chars
	os.system("cat training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+srcLangExt+" | perl "+filterOutIllegalChar+" > training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+srcLangExt+".clean")
	os.system("cat training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+tgtLangExt+" | perl "+filterOutIllegalChar+" > training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+tgtLangExt+".clean")
	os.system("mv training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+srcLangExt+".clean training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+srcLangExt)
	os.system("mv training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+tgtLangExt+".clean training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+tgtLangExt)
	os.system("cp training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+srcLangExt+" training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+tgtLangExt+" training/"+srcLangExt+"-"+tgtLangExt+"/corpus")
	return True



#--------------------------- Step 4: training language model ------------------------------------
def lm_worker(trainingCorpusDir, trainingStem, srcLangExt, tgtLangExt):
		os.system("cat "+trainingCorpusDir+"/"+trainingStem+"."+tgtLangExt+" | perl "+filterOutIllegalChar+" | perl "+perl_sort_uniq+" > training/"+srcLangExt+"-"+tgtLangExt+"/lm/"+trainingStem+"."+tgtLangExt+".lm.trainData")
		os.system("cat training/"+srcLangExt+"-"+tgtLangExt+"/lm/"+trainingStem+"."+tgtLangExt+".lm.trainData | "+ngramCount+" -order 3 -text - -unk -memuse -"+discountMethod+" -"+discountMethod1+" -"+discountMethod2+" -"+discountMethod3+" -"+discountMethod4+" -"+discountMethod5+" -gt5min 1 -gt4min 1 -gt3min 1 -lm "+trainingStem+"."+tgtLangExt+".srilm")
		os.system("mv "+trainingStem+"."+tgtLangExt+".srilm training/"+srcLangExt+"-"+tgtLangExt+"/lm")

def train_lm(trainCorpusDir, trainStem, srcL, tgtL):
	currtime = time()

#	lm_worker(trainCorpusDir, trainStem, srcL, tgtL)
#	lm_worker(trainCorpusDir, trainStem, tgtL, srcL)

	po = Pool(processes=parallel_processes)
	po.apply_async(lm_worker,(trainCorpusDir, trainStem, srcL, tgtL))
	po.apply_async(lm_worker,(trainCorpusDir, trainStem, tgtL, srcL))
	po.close()
	po.join()

	print 'time for LM Training elapsed:', time() - currtime
	return True



#--------------------------- Step 5: training phrase model --------------------------------------
def phrase_worker(workingDirectoryRoot, trainingStem, srcLangExt, tgtLangExt):
	print "perl "+phraseTableExtractionScript+" --root-dir "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+" -score-options '--GoodTuring' --corpus "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/corpus/"+trainingStem+" --f "+srcLangExt+" --e "+tgtLangExt+" --lm 0:3:"+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/lm/"+trainingStem+"."+tgtLangExt+".srilm > "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/phraseExtraction.log"
	os.system("perl "+phraseTableExtractionScript+" --external-bin-dir /home/rottmann/SystemConv/MasterScriptNeeds/ --root-dir "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+" -score-options '--GoodTuring' --corpus "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/corpus/"+trainingStem+" --f "+srcLangExt+" --e "+tgtLangExt+" --lm 0:3:"+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/lm/"+trainingStem+"."+tgtLangExt+".srilm > "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/phraseExtraction.log")

	if opt_filter_unbalanced_moses_phrases==1 :
		os.system("zcat "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/model/phrase-table.gz | perl "+filterUnbalancedMosesPhrases+" > "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/model/phrase-table.filtered")
		os.system("rm "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/model/phrase-table.gz")
		os.system("mv "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/model/phrase-table.filtered "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/model/phrase-table")
		os.system("gzip "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/model/phrase-table")


def train_phrase(trainCorpusDir, trainStem, srcL, tgtL):
	currtime = time()

#	lm_worker(trainCorpusDir, trainStem, srcL, tgtL)
#	lm_worker(trainCorpusDir, trainStem, tgtL, srcL)

	po = Pool(processes=parallel_processes)
	po.apply_async(phrase_worker,(trainCorpusDir, trainStem, srcL, tgtL))
	po.apply_async(phrase_worker,(trainCorpusDir, trainStem, tgtL, srcL))
	po.close()
	po.join()

	print 'time for phrase Training elapsed:', time() - currtime
	return True



#------------------------- Step 6: phrase model weights tuning using moses ----------------------
def findOutLastMertXlatFile(mert_dir):
	i=1
	stillExist = True
	while stillExist and (i<40):
		if not os.path.isfile(mert_dir+"/run"+str(i)+".out"):
			stillExist = False
		else:
			i = i+1

	return i-1



def tune_weight_worker(workingDirectoryRoot, testingDataDir, testingDataStem, referenceStem, srcLangExt, tgtLangExt):
	os.system("cp "+testingDataDir+"/"+testingDataStem+"."+srcLangExt+" "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt)
	os.system("cp "+testingDataDir+"/"+referenceStem+"."+tgtLangExt+"* "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt)

	os.chdir(workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt)
	os.system("perl "+mertScript+" --mertdir=/home/rottmann/SystemConv/mosesdecoder/mert "+testingDataStem+"."+srcLangExt+" "+referenceStem+"."+tgtLangExt+" "+moseBinary+" model/moses.ini")

	os.chdir(workingDirectoryRoot);

	lastMertIteration = findOutLastMertXlatFile(workingDirectoryRoot+"/training/"+tgtLangExt+"-"+srcLangExt+"/mert-work")
	os.system("cat "+workingDirectoryRoot+"/training/"+tgtLangExt+"-"+srcLangExt+"/mert-work/run"+str(lastMertIteration)+".out | perl "+externalEvaluationScript+" "+testingDataDir+"/"+testingDataStem+"."+srcLangExt+" > "+workingDirectoryRoot+"/training/"+tgtLangExt+"-"+srcLangExt+".optimized.externalScore");


def tune_phrase_weights(trainingCorpusDir, testDir, testStem, refStem, srcL, tgtL):
	currtime = time()

	po = Pool(processes=parallel_processes)
	po.apply_async(tune_weight_worker,(trainingCorpusDir, testDir, testStem, refStem, srcL, tgtL))
	po.apply_async(tune_weight_worker,(trainingCorpusDir, testDir, testStem, refStem, tgtL, srcL))
	po.close()
	po.join()

	print 'time for phrase Training elapsed:', time() - currtime
	return True



#--------------------------- Step 7: convert multiscore phrase TD to single score ---------------

def convert_multi_score_td_worker(workingDirectoryRoot, trainingStem, srcLangExt, tgtLangExt):
	#find out the optimized weights

	os.system("grep 'Best point' "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/mert-work/mert.log | tail -1 > "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+".tm.weights")
	weightfile=open(workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+".tm.weights","r")
	ent = weightfile.read().strip().split()
	weightfile.close()
	weightVector=ent[3]+" "+ent[5]+" "+ent[6]+" "+ent[7]+" "+ent[8]+" "+ent[9]+" "+ent[4]
	print weightVector
	command = "zcat "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/model/phrase-table.gz | perl "+combineMultipleScoreMosesTdToSingleScorePanDoRATd+" "+workingDirectoryRoot+"/training/"+srcLangExt+"-"+tgtLangExt+"/lm/"+trainingStem+"."+tgtLangExt+".srilm "+weightVector+" "+str(maxTranslationAlternative)+" | perl "+filterUnbalancedPhraseEntries+" | perl "+filterTdContainingTooLongToken+" > "+workingDirectoryRoot+"/pandora/"+srcLangExt+"-"+tgtLangExt+".single-score.td"
	print command
	os.system(command)



def convert_multi_score_td(trainCorpusDir, trainStem, srcL, tgtL):
	currtime = time()

	po = Pool(processes=parallel_processes)
	po.apply_async(convert_multi_score_td_worker,(trainingCorpusDir, trainStem, srcL, tgtL))
	po.apply_async(convert_multi_score_td_worker,(trainingCorpusDir, trainStem, tgtL, srcL))
	po.close()
	po.join()

	print 'time for multiscore into single score phrasetable elapsed:', time() - currtime
	return True






#--------------------------- Step 8.5: add a phrase book to the model ------------------------------------------
def add_phrase_book(workingDirectoryRoot, trainingStem, srcLangExt, tgtLangExt):	# if there exists a phrase book that needs to be added to the model
	if not os.path.isfile(workingDirectoryRoot+"/"+trainingStem+".phrasebook"):
		print "ERROR: Phrasebook "+workingDirectoryRoot+"/"+trainingStem+".phrasebook does not exist!\n";
		return False
	else:
		# the phrase book has to be named as $trainingStem.phrasebook in the right format
		# The phrase book is of the format:
		# src phrase[_]* <tab> tgt phrase[_]*
		# * A "_" at the end of a sentence indicates that this sentence cannot be a source-sentence, but only a target-sentence
		# * If no "_" the phrase-pair is bi-directional, i.e. it should be appended to both the and JC and CJ phrasetables
		#
		os.system("perl "+extractInfoFromPhrasebook+" "+trainingStem+" "+srcLangExt+" "+tgtLangExt+" < "+workingDirectoryRoot+"/"+trainingStem+".phrasebook")
		# this generates the following files:
		#	nameStem.srcLangId-tgtLangId.phrase.td
		#	nameStem.tgtLangId-srcLangId.phrase.td
		#	nameStem.phrasebook.srcLangId
		#	nameStem.phrasebook.tgtLangId

		# now we need to create new training data and phrase TDs
		os.system("cat "+workingDirectoryRoot+"/training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+srcLangExt+" "+trainingStem+".phrasebook."+srcLangExt+" > "+trainingStem+"."+srcLangExt)
		os.system("cat "+workingDirectoryRoot+"/training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+tgtLangExt+" "+trainingStem+".phrasebook."+tgtLangExt+" > "+trainingStem+"."+tgtLangExt)
		os.system("cat "+trainingStem+"."+srcLangExt+"-"+tgtLangExt+".phrase.td >> "+srcLangExt+"-"+tgtLangExt+".single-score.td")
		os.system("cat "+trainingStem+"."+tgtLangExt+"-"+srcLangExt+".phrase.td >> "+tgtLangExt+"-"+srcLangExt+".single-score.td")




#--------------------------- Step 9: tune the pandora model parameter on dev-set ----------------
def eval_pandora_worker(workingDirectoryRoot, trainingStem, beamSize, lmScale, tmScale, rmScale, reorderWinSize, testingDataDir, testingDataStem, srcLangExt, tgtLangExt, direction):
	os.system(pandoraBin+" "+workingDirectoryRoot+"/pandora/ToBeCopiedToPDA/"+trainingStem+".decoder.sample.cfg "+str(direction)+" -"+vocSize+" -b "+str(beamSize)+" -l "+str(lmScale)+" -t "+str(tmScale)+" -r "+str(rmScale)+" -w "+str(reorderWinSize)+" < "+testingDataDir+"/"+testingDataStem+"."+srcLangExt+" > "+workingDirectoryRoot+"/pandora/Tune-"+srcLangExt+"-"+tgtLangExt+"/xlat/xlat.lm-"+str(lmScale)+"-tm-"+str(tmScale)+"-rm-"+str(rmScale)+"-rw-"+str(reorderWinSize)+"-b-"+str(beamSize))
	print "perl "+externalEvaluationScript+" "+testingDataDir+"/"+testingDataStem+"."+tgtLangExt+" < "+workingDirectoryRoot+"/pandora/Tune-"+srcLangExt+"-"+tgtLangExt+"/xlat/xlat.lm-"+str(lmScale)+"-tm-"+str(tmScale)+"-rm-"+str(rmScale)+"-rw-"+str(reorderWinSize)+"-b-"+str(beamSize)
	output = subprocess.check_output(["perl "+externalEvaluationScript+" "+testingDataDir+"/"+testingDataStem+"."+tgtLangExt+" < "+workingDirectoryRoot+"/pandora/Tune-"+srcLangExt+"-"+tgtLangExt+"/xlat/xlat.lm-"+str(lmScale)+"-tm-"+str(tmScale)+"-rm-"+str(rmScale)+"-rw-"+str(reorderWinSize)+"-b-"+str(beamSize)], shell=True)
	print output
	print ("perl "+externalEvaluationScript+" "+testingDataDir+"/"+testingDataStem+"."+tgtLangExt+" < "+workingDirectoryRoot+"/pandora/Tune-"+srcLangExt+"-"+tgtLangExt+"/xlat/xlat.lm-"+str(lmScale)+"-tm-"+str(tmScale)+"-rm-"+str(rmScale)+"-rw-"+str(reorderWinSize)+"-b-"+str(beamSize))
	os.system("echo 'lm-"+str(lmScale)+"-tm-"+str(tmScale)+"-rm-"+str(rmScale)+"-rw-"+str(reorderWinSize)+"-b-"+str(beamSize)+"\n"+output.strip()+"' >> "+workingDirectoryRoot+"/pandora/Tune-"+srcLangExt+"-"+tgtLangExt+"/tune.scores")

def tune_pandora (workingDirectoryRoot, testingDataDir, srcLangExt, tgtLangExt, trainingStem, testingDataStem):
	currtime = time()
	os.system("mkdir -p "+workingDirectoryRoot+"/pandora/Tune-"+srcLangExt+"-"+tgtLangExt)
	os.system("mkdir -p "+workingDirectoryRoot+"/pandora/Tune-"+srcLangExt+"-"+tgtLangExt+"/xlat")

	os.system("mkdir -p "+workingDirectoryRoot+"/pandora/Tune-"+tgtLangExt+"-"+srcLangExt)
	os.system("mkdir -p "+workingDirectoryRoot+"/pandora/Tune-"+tgtLangExt+"-"+srcLangExt+"/xlat")

	po = Pool(processes=parallel_processes)


#	po.apply_async(convert_multi_score_td_worker,(trainingCorpusDir, trainStem, tgtL, srcL))



	#src->tgt direction tuning
	for lmScale in srcTgtLMScales:
		for tmScale in srcTgtTMScales:
			for rmScale in srcTgtRMScales:
				for reorderWinSize in srcTgtReorderWindows:
					for beamSize in srcTgtBeamSizes:
						po.apply_async(eval_pandora_worker,(workingDirectoryRoot, trainingStem, beamSize, lmScale, tmScale, rmScale, reorderWinSize, testingDataDir, testingDataStem, srcLangExt, tgtLangExt, 1))

	for lmScale in tgtSrcLMScales:
		for tmScale in tgtSrcTMScales:
			for rmScale in tgtSrcRMScales:
				for reorderWinSize in tgtSrcReorderWindows:
					for beamSize in tgtSrcBeamSizes:
						po.apply_async(eval_pandora_worker,(workingDirectoryRoot, trainingStem, beamSize, lmScale, tmScale, rmScale, reorderWinSize, testingDataDir, testingDataStem, tgtLangExt, srcLangExt, -1))




	po.close()
	po.join()




if __name__ == '__main__':
	currtime = time()
	if len(sys.argv) < 6:
		print "--------------------------------------------------------------"
		print "Usage:"
		print "\tperl master-training-script.pl trainingDataDir training-filename-stem srcLang tgtLang testingDataDir testingDataStem referenceStem existingSrcLM existingTgtLM"
		print " Step 1: check if tagger files existent"
		print " Step 2: clean working dir"
		print " Step 2.5: setup working dir"
		print " Step 3: corpus cleaning"
		print " alternative: 3.5 - just copy corpus as is"
		print " Step 4: languagemodel processing"
		print " Step 4.5: train language model (otherwise copy existing)"
		print " Step 5: phrase extraction"
		print " Step 6: moses phrase model weight tuning"
		print " Step 7: phrasetable to single score conversion"
		print " Step 8: model conversion"
		print " Step 9: pandora optimization"
		print " --------------------------------------------------------------\n"
		exit (-1)



	trainingCorpusDir = os.path.abspath(sys.argv[1]);
	trainingStem = sys.argv[2];
	srcLangExt = sys.argv[3];
	tgtLangExt = sys.argv[4];
	testingDataDir = os.path.abspath(sys.argv[5]);
	testingDataStem = sys.argv[6];
	referenceStem = sys.argv[7];

	src_tag_file = trainingCorpusDir+"/"+srcLangExt+".tags"
	tgt_tag_file = trainingCorpusDir+"/"+tgtLangExt+".tags";

	if 1 in steps:
		print "Step1: check if all files needed exist ...\n"
		if not check_if_files_exist(src_tag_file, tgt_tag_file):
			print "ERROR: missing tag files"
			exit(-1)
		print "ok"

	if 2 in steps:
		print "Step2: removing previously generated pandora or training directories ...\n"
		remove_training_directories()

	if 2.5 in steps:
		print "Step2.5: creating directories ...\n"
		create_training_directories(srcLangExt, tgtLangExt)


	if 3 in steps:
		print "Step3: Clean up corpus ...\n"
		clean_up_corpus(trainingCorpusDir, trainingStem, srcLangExt, tgtLangExt)
	elif 3.5 in steps:
		os.system("cp "+trainingCorpusDir+"/"+trainingStem+"."+srcLangExt+" "+trainingCorpusDir+"/"+trainingStem+"."+tgtLangExt+" training/"+tgtLangExt+"-"+srcLangExt+"/corpus")
		os.system("cp "+trainingCorpusDir+"/"+trainingStem+"."+srcLangExt+" "+trainingCorpusDir+"/"+trainingStem+"."+tgtLangExt+" training/"+srcLangExt+"-"+tgtLangExt+"/corpus")

	if 4 in steps:
		print "Step4: training language model ...\n"
		if 4.5 in steps:
			print "Step4.5: computing srilm ...\n"
			train_lm(trainingCorpusDir, trainingStem, srcLangExt, tgtLangExt)
		else:
			existingSrcLangLM = sys.argv[8]
			existingTgtLangLM = sys.argv[9]

			os.system("ln -s "+existingSrcLangLM+" training/"+tgtLangExt+"-"+srcLangExt+"/lm/"+trainingStem+"."+srcLangExt+".srilm")
			os.system("ln -s "+existingTgtLangLM+" training/"+srcLangExt+"-"+tgtLangExt+"/lm/"+trainingStem+"."+tgtLangExt+".srilm")


	if 5 in steps:
		print "Step5: training phrase model ...\n"
		train_phrase(trainingCorpusDir, trainingStem, srcLangExt, tgtLangExt)

	if 6 in steps:
		print "Step6: tuning phrase model weights ...\n";
		tune_phrase_weights(trainingCorpusDir, testingDataDir, testingDataStem, referenceStem, srcLangExt, tgtLangExt)

	if 7 in steps:
		print "Step7: convert multiscore phrase TD to single score TD ...\n"
		convert_multi_score_td(trainingCorpusDir, trainingStem, srcLangExt, tgtLangExt)


	if 8 in steps:
		os.chdir(trainingCorpusDir+"/pandora")
		if 8.5 in steps:
			print "Step8.5: adding phrase book ...\n"
			add_phrase_book(trainingCorpusDir, trainingStem, srcLangExt, tgtLangExt)
			# train SRI lm on augmented corpus
			if 4.5 in steps:
				os.system("cat "+trainingStem+"."+srcLangExt+" | perl "+filterOutIllegalChar+" | perl "+perl_sort_uniq+" | "+ngramCount+" -order 3 -text - -unk -memuse -"+discountMethod+" -"+discountMethod1+" -"+discountMethod2+" -"+discountMethod3+" -"+discountMethod4+" -"+discountMethod5+" -gt5min 1 -gt4min 1 -gt3min 1 -lm "+trainingStem+"."+srcLangExt+".srilm")
				os.system("cat "+trainingStem+"."+tgtLangExt+" | perl "+filterOutIllegalChar+" | perl "+perl_sort_uniq+" | "+ngramCount+" -order 3 -text - -unk -memuse -"+discountMethod+" -"+discountMethod1+" -"+discountMethod2+" -"+discountMethod3+" -"+discountMethod4+" -"+discountMethod5+" -gt5min 1 -gt4min 1 -gt3min 1 -lm "+trainingStem+"."+tgtLangExt+".srilm")
		else:
			os.system("ln -s "+trainingCorpusDir+"/training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+srcLangExt+" "+trainingCorpusDir+"/pandora")
			os.system("ln -s "+trainingCorpusDir+"/training/"+tgtLangExt+"-"+srcLangExt+"/corpus/"+trainingStem+"."+tgtLangExt+" "+trainingCorpusDir+"/pandora")

			if 4.5 in steps:
				os.system("ln -s "+trainingCorpusDir+"/training/"+tgtLangExt+"-"+srcLangExt+"/lm/"+trainingStem+"."+srcLangExt+".lm.trainData "+trainingStem+"."+srcLangExt+".lm.trainData")
				os.system("ln -s "+trainingCorpusDir+"/training/"+srcLangExt+"-"+tgtLangExt+"/lm/"+trainingStem+"."+tgtLangExt+".lm.trainData "+trainingStem+"."+tgtLangExt+".lm.trainData")

				os.system("ln -s "+trainingCorpusDir+"/training/"+tgtLangExt+"-"+srcLangExt+"/lm/"+trainingStem+"."+srcLangExt+".srilm "+trainingStem+"."+srcLangExt+".srilm")
				os.system("ln -s "+trainingCorpusDir+"/training/"+srcLangExt+"-"+tgtLangExt+"/lm/"+trainingStem+"."+tgtLangExt+".srilm "+trainingStem+"."+tgtLangExt+".srilm")


		if not(4.5 in steps):
			os.system("ln -s "+existingSrcLangLM+" "+trainingStem+"."+srcLangExt+".srilm")
			os.system("ln -s "+existingTgtLangLM+" "+trainingStem+"."+tgtLangExt+".srilm")
			os.system("ln -s "+existingSrcLangLMTrainingData+" "+trainingStem+"."+srcLangExt+".lm.trainData")
			os.system("ln -s "+existingTgtLangLMTrainingData+" "+trainingStem+"."+tgtLangExt+".lm.trainData")



		print "Step 8: model conversion ...\n"

		os.system("touch testing."+srcLangExt)
		os.system("touch testing."+tgtLangExt)

		os.system("ln -s "+src_tag_file+" "+trainingStem+"."+srcLangExt+".tags")
		os.system("ln -s "+tgt_tag_file+" "+trainingStem+"."+tgtLangExt+".tags")
		print ("perl "+offline_pandora_model_coversion+" "+srcLangExt+" "+tgtLangExt+" "+trainingStem+" testing "+srcLangExt+"-"+tgtLangExt+".single-score.td "+tgtLangExt+"-"+srcLangExt+".single-score.td "+vocSize+" "+str(maxTranslationAlternative)+" > modelconversion.log")
        os.system("perl "+offline_pandora_model_coversion+" "+srcLangExt+" "+tgtLangExt+" "+trainingStem+" testing "+srcLangExt+"-"+tgtLangExt+".single-score.td "+tgtLangExt+"-"+srcLangExt+".single-score.td "+vocSize+" "+str(maxTranslationAlternative)+" > modelconversion.log")

	if 9 in steps:
		print "Step 9: pandora tuning ...\n"
		tune_pandora (trainingCorpusDir, testingDataDir, srcLangExt, tgtLangExt, trainingStem, testingDataStem)


	print 'time for training into single score phrasetable elapsed:', time() - currtime


