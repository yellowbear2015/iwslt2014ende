#!/usr/bin/perl

open VOC, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
while(<VOC>){
    chomp;
    $dict{$_} = 1;
}
close VOC;
$t = 0;
open TXT, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
while(<TXT>) {
    if($t++ % 10000 == 0) {
      print STDERR "Processing $t phrase pair.. $_\n";
    }
    $words = $_;
    chomp;
    @wds = split "\Q|||\E";
    $wds[0] = " $wds[0]";
    foreach $ent (keys %dict) {
      if($wds[0] =~ / $ent /) {
        print "$ent\t", $words;
        $found{$ent} = 1;
        delete $dict{$ent};
        break;
      }
    }
  }

  foreach $ent (keys %dict) {
    if (not exists $found{$ent}) {
      print "Phrase table not found: $ent\n";
    }
  }
  
close TXT;

