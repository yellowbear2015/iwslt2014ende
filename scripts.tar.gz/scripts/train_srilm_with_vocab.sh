#/bin/bash
/home/feihuang/bin/srilm/bin/i686-m64/ngram-count -order $2 -text $1 -unk -memuse -ukndiscount -ukndiscount1 -ukndiscount2 -ukndiscount3 -ukndiscount4 -ukndiscount5 -gt5min 3 -gt4min 2 -gt3min 1 -lm $1.$2g.srilm -vocab $3
