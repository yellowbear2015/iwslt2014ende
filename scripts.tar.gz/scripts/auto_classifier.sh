
~/bin/auto_post_preprocess.sh $1
~/bin/srilm/bin/i686-m64/ngram -lm /home/feihuang/Work/MBI/Auto/LMs/indomain_300K.lc.2.3g.srilm -ppl $1.proc  -debug 1 > $1.proc.indomain.lmlog
~/bin/srilm/bin/i686-m64/ngram -lm /home/feihuang/Work/MBI/Auto/LMs/general_300K.lc.2.3g.srilm -ppl $1.proc  -debug 1 > $1.proc.general.lmlog

~/bin/lmratio.pl $1.proc.indomain.lmlog $1.proc.general.lmlog /home/feihuang/Work/MBI/Auto/auto_keywords_wdexp2 > $1.lmratio
