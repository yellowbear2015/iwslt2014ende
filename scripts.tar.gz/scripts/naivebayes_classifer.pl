#!/bin/env perl
use strict;

if($#ARGV == -1) {
    print "Usage: mean/var:mean/var... file_with_list_of_features\n";
    exit;
}

my @meanvars= split ":", $ARGV[0];
my @means = ();
my @vars = ();
my ($mv, $i, @datap, $v);
foreach $mv (@meanvars) {
    my ($m, $v) = split "/", $mv;
    push @means, $m;
    push @vars, $v;
}

open FILE, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
while(<FILE>) {
  chomp;
  @datap  =split "\t";
  if($#datap != $#means) {
    print "ERROR! input line has different number of features. $!\n";
    print "$_\n";
    next;
  }
  my $logp = 0;
  for($i = 0; $i <= $#datap; $i++) {
    my $logpi = log(1.0 / $vars[$i]) + ($datap[$i] - $means[$i]) * ($datap[$i] - $means[$i]) / ($vars[$i] * $vars[$i]);
    $logp += $logpi;
    print "$logpi\t";
  }
  print "$logp\n";
}
close FILE;

