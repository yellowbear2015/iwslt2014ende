#!?usr/bin/perl -CSD
while(<>) {
 s/(\p{Arabic})\+ (\p{Arabic})/\1\2/g;
 s/(\p{Arabic})\+ \+(\p{Arabic})/\1\2/g;
 s/(\p{Arabic}) \+(\p{Arabic})/\1\2/g; 
 #s/\p{Arabic}+//g; 
 #s/ +\p{Arabic}//g;
 print;
 }
