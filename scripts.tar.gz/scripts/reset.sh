#!/bin/bash
git reset --soft HEAD^
