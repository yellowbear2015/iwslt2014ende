#!/usr/bin/perl

while(<>) {
    chomp;
    #print;
    s/\s*http(\S+)\s*/ _URL_ /g;
    #print;
    if(!/\@URL/) {
        s/\s*\S*\@\S*\s*/ _EMAIL_ /g;
    }
    #print;
    s/\s[0-9]+\s/ _NUM_ /g;
    #print;
    if(!/www\./) {
        s/([a-zA-Z])(\1+)/\1\1/g;
    }
    print "$_\n";
}
