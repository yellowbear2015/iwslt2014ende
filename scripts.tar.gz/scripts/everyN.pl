#!/usr/bin/perl

if($#ARGV == -1) { 
  print "file item_length everyN maxN\n";
  exit;
}

open FILE, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";

$N = $ARGV[2];

$maxN = $ARGV[3];

$itemLength = $ARGV[1];
$linenum= 0;
$printbeadnum = 0;
while(<FILE>) {
    if($linenum% $itemLength == 0) {
      $itemnum = $linenum / $itemLength;
      if($itemnum % $N == 0) {
	print;
        $pnum = 0;
        while(++$pnum < $itemLength) {
          $dline = <FILE>;
          print $dline;
          $linenum++;
        }
	$printbeadnum++;
      }
    }
    last if($printbeadnum >= $maxN) ;
    $linenum++; 
}


close FILE;
