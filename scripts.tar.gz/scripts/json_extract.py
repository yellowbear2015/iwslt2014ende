# @lint-avoid-pyflakes3
# -*- coding: utf-8 -*-

# Description: This script implements a LR segmenter based on dictionary
#              provided by user.
# Author: Feng Liang
# Email: liangfeng@fb.com
# Date: 2014-10-09 14:51:52

# add code range change for thai

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import json
import sys
import os
import codecs

UTF8Reader = codecs.getreader('utf8')
jsonFile = open(sys.argv[1], 'r')
jsonFile = UTF8Reader(jsonFile)
field=sys.argv[2]
values = json.load(jsonFile)
jsonFile.close()
"""If that json is from a URL, do the following to load it:

import urllib, json
f = urllib.urlopen("http://domain/path/jsonPage")
values = json.load(f)
f.close()
To print ALL of the criteria, you could:
"""
sys.stdout = codecs.getwriter('utf-8')(sys.stdout)
for criteria in values[field]:
    for key, value in criteria.iteritems():
        print(key, '\t', value)

