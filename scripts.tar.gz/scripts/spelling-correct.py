import sys, collections, heapq

"""
def words(text): return re.findall('[a-z]+', text.lower())

def train(features):
    model = collections.defaultdict(lambda: 1)
    for f in features:
        model[f] += 1
    return model
NWORDS = train(words(file('big.txt').read()))
"""


alphabet = 'abcdefghijklmnopqrstuvwxyz'

def edits1(word):
   splits     = [(word[:i], word[i:]) for i in range(len(word) + 1)]
   deletes    = [a + b[1:] for a, b in splits if b]
   transposes = [a + b[1] + b[0] + b[2:] for a, b in splits if len(b)>1]
   replaces   = [a + c + b[1:] for a, b in splits for c in alphabet if b]
   inserts    = [a + c + b     for a, b in splits for c in alphabet]
   return set(deletes + transposes + replaces + inserts)

NWORDS = collections.defaultdict(lambda: 1)

linenum = 0;
file=open(sys.argv[1], 'r')
for line in file:
    fqwd = line.split();
    NWORDS[fqwd[1]] = float(fqwd[0])
    linenum += 1;
    if(linenum % 10000 == 0):
        print "Read %d lines", linenum
print "reading voc done\n";


def known_edits2(word):
    return set(e2 for e1 in edits1(word) for e2 in edits1(e1) if e2 in NWORDS)

def known(words): return set(w for w in words if w in NWORDS)

def correct(word):
    print "edit1:"
    print known(edits1(word))
    print "edit2:"
    print known_edits2(word)
#    candidates = known([word]) | known(edits1(word)) | known_edits2(word) | [word]
    candidates = known([word]).union(known(edits1(word))).union(known_edits2(word)).union([word])
    print "candidates:"
    print candidates
#    return max(candidates, key=NWORDS.get)
#    return heapq.nlargest(5, candidates, key=NWORDS.get)
    po = heapq.nlargest(10, candidates, key=NWORDS.get)
    for w in po:
        print w, ":", NWORDS[w]


wordfile=open(sys.argv[2], 'r')

for line in wordfile:
    print "input spelling:", line
#    print "\n".join(correct(line.strip()))
    correct(line.strip().lower())
    print "=" * 50
