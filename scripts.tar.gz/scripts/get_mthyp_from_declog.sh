grep '^H' $1 | cut -f 3- > $1.h
grep '^A' $1 | cut -f 2- > $1.a
~/fbcode/deeplearning/projects/translation/scripts/unkreplace.py $1.h $1.a $2 > $1.mt
