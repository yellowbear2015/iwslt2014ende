#!/bin/bash
cd /home/feihuang/Download/senna/
cat $1 | /home/feihuang/Download/senna/senna -usrtokens  -pos > $1.pos.senna
cat $1.pos.senna | cut -f 2 | perl -pe 's/^$/UniQueTokEn/g; s/\n//g;' | perl -pe 's/UniQueTokEn/\n/g; s/ +/ /g;' | perl -pe 's/^\s+//g;' > $1.pos
