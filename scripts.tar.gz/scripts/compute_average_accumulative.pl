#!/usr/bin/perl
$sum = 0;
$n = 0;
while(<>) {
  chomp;
  $n ++;
  $sum += $_;
  print $sum/$n, "\n";
}

