#!/usr/bin/perl -CSD
use FileHandle;
#use strict;
if($#ARGV == -1) {
  print "Usage: char_input segment1 segment2 ...\n";
  exit;
}
open CHAR0, $ARGV[0] or die;

while($line0 = <CHAR0>) {
    chomp $line0;
    @minwords = split " ", $line0;

    for($i = 1; $i <= $#ARGV; $i++) {
        $line = <$$FileHanles[$i]>;
        chomp $line;
        @words = split " ", $line;
        my $s = 0;
        my $t = 0;
        my $cword = "";
        for($m = 0; $m <= $#words; $m++) {
            $not_found_flag = 0;
            while($words[$m] != $cword) {
                $cword .= $minwords[$t++];
                if($t > $#minwords) {
                    print "Error! Did not find matching substring.\n";
                    print "$words[$m] <- $cword\n";
                    $not_found_flag = 1;
                    last;
                }
            }
            if(! $not_found_flag) {
                $lattice{$s}{$cword} = $t-$s;
                $s = $t;
            }
        }
        print "(\n";
        foreach $start (sort{$a<=>$b} (keys %lattice)) {
            print "(\n";
            foreach $word (keys %{$lattice{$start}}) {
                print "(\'$word\', 0, $lattice{$start}{$word}),\n";
            }
            print ")\n";
        }
        print ")\n";
    }
    print "\n==============================\n";

}

foreach $fh (@FileHandles) {
    $fh->close();
}
