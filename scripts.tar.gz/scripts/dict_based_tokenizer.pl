#!/usr/bin/perl

my %dict = ();

open DICT, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
while(<DICT>) {
    chomp;
    s/^\s*//g;
    s/\s*$//g;
    $dict{$_} = 1;
}
close DICT;

open TEST, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
while(<TEST>) {
    chomp;
    my $newline = "";
    my @words = split " ";
    foreach $w (@words) {
        if(exists $dict{$w}) {
            $newline .= "$w ";
        }
        else {
            if($w =~ /^(ftp|http|www)/i || $w =~ /(org|net|edu|com)$/i  || $w !~ /[[a-zA-Z]/ || $w =~/\@/) {
                $newline .= "$w ";
            }
            else {
                #print "OOV: $w\n";
                $w =~ s/([a-zA-Z])([^a-zA-Z])/\1 \2/g;
                $w =~ s/([^a-zA-Z])([a-zA-Z])/\1 \2/g;
                #print "New word: $w\n";
                my @nw = split " ", $w;
                my $nl = "";
                foreach $tew (@nw) {
                    if(length($tew) >= 3 && exists $dict{$tew} ) {
                        $nl .= " $tew ";
                    }
                    else {
                        $nl .= $tew;
                    }
                }
                #print "final: $nl \n";
                $newline .= "$nl ";
            }
        }
    }
    print "$newline\n";
}
