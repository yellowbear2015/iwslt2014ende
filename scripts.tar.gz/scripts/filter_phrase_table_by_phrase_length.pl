#!/usr/bin/perl

open FILE, $ARGV[0] or die "can't open file $ARGV[0]. $!\n";
my $max_src_len = $ARGV[1];
my $max_tgt_len = $ARGV[2];

while(<FILE>) {
    @w = split "\Q|||\E"; 
    #next if($#w < 5 );
    $w[0] =~ s/\|/&#124;/g;
   # $w[0] =~ s/^\| /&#124; /g;
   # $w[0] =~ s/^\s+//;
   # $w[0] =~ s/\s*$//;
    next if($w[0] eq "");
    $w[1] =~ s/\|/&#124;/g;
    #$w[1] =~ s/^\| /&#124; /g;
    #$w[1] =~ s/^\s+//;
    #$w[1] =~ s/\s*$//;

    @srcwords = split " ", $w[0];
    @tgtwords = split " ", $w[1];
    next if($#srcwords+1 > $max_src_len || $#tgtwords+1 > $max_tgt_len);

    next if($w[1] eq "");
    for($p = 0; $p < $#w; $p++) {
	    print "$w[$p]|||";
    }
    print "$w[$#w]";
}
