#!/bin/bash

cat $1 | tr "[A-Z]" "[a-z]" | perl -pe's// /g; while(/ \\ u ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) /) {s/ \\ u ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) / <b> \\u\1\2\3\4 <b> /g;} s/  / <b> /g;' > $1.space


~/fbcode/_bin/language_technology/src/jedi/jedi -f /mnt/vol/language_technology_mt/decompounding/decompound_jedi.ini < $1.space

cat /tmp/nbest.txt |  perl -nae 'if(/\Q|||\E(.+?)\Q|||\E/) { print "$1\n"}' | perl -pe 's/ //g; s/<b>/ /g;  s/([a-z]+)/ \1 /g;  s/ +/ /g;' > $1.nbest.seg

~/fbcode/_build/opt/language_technology/src/jedi/lm/query /mnt/vol/language_technology_mt/decompounding/post.20140310.en.13M.unescape.tp_noNE.3g.srilm.bin < $1.nbest.seg | perl -nae 'if(/Total: (.+?) /) { print "$1\n";}' > $1.nbest.seg.ppl

python ~feihuang/bin/select_hyp_by_ppl.py  $1.nbest.seg $1.nbest.seg.ppl | cut -f 2 > $1.seg

#rm $1.space* $1.nbest.seg*
