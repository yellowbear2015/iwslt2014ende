import sys, os, traceback, optparse
import string
import pdb

with open(sys.argv[1], 'r') as filep:
    for line in iter(lambda: filep.readline(), ''):
        #print line
        #pdb.set_trace()
        line2 = line.decode('unicode-escape')
        print line2
