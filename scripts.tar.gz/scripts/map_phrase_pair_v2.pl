#!/usr/bin/perl

use strict;
open TRAORIG, $ARGV[0] or die "Can't open train phrase raw file. $!\n";
open TRASTEM, $ARGV[1] or die "Can't open train phrase stem file. $!\n";

open TSTORIG, $ARGV[2] or die "Can't open test phrase raw file. $!\n";
open TSTSTEM, $ARGV[3] or die "Can't open test phrase stem file. $!\n";


my %traindict = ();
my %trainphr = ();
my $sentid = 0;
my $trainorig;
my $trainstem;
while($trainorig = <TRAORIG>) {
    $trainstem = <TRASTEM>;
    print STDERR "reading $sentid phrase...\n" if ($sentid++ % 100000 == 0);
    chomp $trainorig;
    chomp $trainstem;
    $traindict{$trainstem}{$trainorig} = 1;
    $trainphr{$trainorig} = 1;
}

my $testorig;
my $teststem;

while($testorig = <TSTORIG>) {
    $teststem = <TSTSTEM>;
    chomp $testorig;
    chomp $teststem;
    if(not exists $trainphr{$testorig}) {
        print "Not Found: $testorig\t";
        if(exists $traindict{$teststem}) {
            print "Candidate|";
            foreach my $ent (keys %{$traindict{$teststem}}) {
                print "\t$ent";
            }
        }
        print "\n";
    }
}
close TSTORIG;
close TSTSTEM;
