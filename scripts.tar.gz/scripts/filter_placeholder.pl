#!/usr/bin/perl


my %placeholder ;
$placeholder{'@EMOTICON'} = 1;
$placeholder{'@MULTIPUNCT'} = 1;
$placeholder{'@URL'} = 1;
$placeholder{'@DIGITS'} = 1;
$placeholder{'@USERNAME'} = 1;
$placeholder{'@FBENTITY'} = 1;
$placeholder{'@PERSON'} = 1;
$pp = 0;
while(<>) {

  @phs = split "\Q|||\E";

  @srcwords = split " ", $phs[0];
  @tgtwords = split " ", $phs[1];
  @alignment = split " ", $phs[3];
  my %sphral = ();
  my %tphral = ();
  foreach $al (@alignment) {
    ($spos, $tpos) = split "-", $al;
    $sphral{$spos} ++;
    $tphral{$tpos} ++;
  }
  $srcpnum = 0;
  $tgtpnum = 0;
  $unalign = 0;
  for($i = 0; $i <= $#srcwords; $i++) {
    if(exists $placeholder{$srcwords[$i]}) {
      $srcpnum++;
      if($sphral{$i} != 1) {
        $unalign = 1;
        break;
      }
    }
  }
 for($i = 0; $i <= $#tgtwords; $i++) {
    if(exists $placeholder{$tgtwords[$i]}) {
      $tgtpnum++;
      if($tphral{$i} != 1) {
        $unalign = 1;
        break;
      }
    }
  }


  print if($srcpnum == $tgtpnum and not $unalign);
}
