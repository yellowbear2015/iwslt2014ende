#!/usr/bin/perl

use strict;
if($#ARGV == -1) {
    print "Filter user feedback table based on the following criteria.\n";
    print "1) Only keep the last feedback by the user on the same translation.\n";
    print "2) Filter out users which gave too many feedbacks.\n";
    print "3) Filter out sentences that has too little feedbacks (>=3)\n";
    print "4) Filter out sentences that has high variance in feedbacks. \n";
    print "Assuming the table format: \n";
    print "source feedback target orig_conf userid content_id event_time\n";
    exit;
}



my %total_table;
my %user_table;
my (@fields, @feedbacks);
my ($srclang, $tgtlang, $source, $feedback, $target, $orig_conf, $userid);
my ($content_id, $event_time, $keystr, $sum, $var, $avg, $f);

my $feedback_num_threshold = $ARGV[1];

open FILE, $ARGV[0] or die "Can't open file $ARGV[0]. $!\n";
while(<FILE>) {
    chomp;
    my $row_str = $_;
#    ($source, $target_lang, $text, translation, user_feedback, translation_confidence, userid, content_id, event_time
    ($source, $feedback, $target, $orig_conf, $userid, $content_id, $event_time)
#    ($source, $target, $feedback, $orig_conf, $userid, $content_id, $event_time)
      = split "\t", $row_str;
    $keystr = join ":", $userid, $content_id;
    next if($content_id eq "NULL");
    if(not exists $total_table{$keystr}) {
        $total_table{$keystr} = $row_str;
    }
    else {
        my @tmpary = split "\t", $total_table{$keystr};
        if($tmpary[$#tmpary] < $event_time) { #keep the latest feedback
            $total_table{$keystr} = $row_str;
        }
    }
}
close FILE;

foreach $keystr (keys %total_table) {
    ($userid, $content_id) = split ":", $keystr;
    $user_table{$userid}++;
}

# filter out users who gave too many feedbacks in the given period of time
my %table2=();
foreach $keystr (keys %total_table) {
    ($userid, $content_id) = split ":", $keystr;
    if($user_table{$userid} < 200) {
        ($source, $feedback, $target, $orig_conf, $userid, $content_id, 
          $event_time) = split "\t", $total_table{$keystr};
        $table2{$content_id}{"source"} = $source;
        $table2{$content_id}{"target"} = $target;
        $table2{$content_id}{"orig_conf"} = $orig_conf;
        $table2{$content_id}{"feedbacks"} .= "$feedback:";
    }
    else {
      #      print STDERR "Remove feedbacks from user: $userid\n";
    }
}

print STDERR "after user filtering, ", scalar(keys %table2), " sentences left.\n";

my $feednumfil = 0;
my $varfilnum = 0;
foreach $keystr (keys %table2) {
    $table2{$keystr}{"feedbacks"} =~ s/\:$//g;
    @feedbacks = split ":", $table2{$keystr}{"feedbacks"};
    # filter if there are too little feedback for this sentence;
    if($#feedbacks < $feedback_num_threshold) {
      #    print STDERR "Filter sentence with insufficient feedbacks. $keystr\n";
        $feednumfil ++;
        next;
    }
    # filter if the variance is high
    $sum = $var = $avg = 0;
    foreach $f (@feedbacks) { $sum += $f; }
    $avg = $sum/($#feedbacks+1);
    $sum = 0;
    foreach $f (@feedbacks) {
        $sum += ($f-$avg)*($f-$avg);
    }
    $var = $sum/($#feedbacks+1);
    if($var > 1.0) {
      #     print STDERR "Filter based on variance: $var for ", 
          (join " ", @feedbacks), "\n";
        $varfilnum ++;
        next;
    }
    print "$keystr\t",$table2{$keystr}{"source"}, "\t", 
      $table2{$keystr}{"target"}, "\t", "$avg\t$var\t", 
      $table2{$keystr}{"orig_conf"},"\t[", (join " ", @feedbacks),"]\n";
}
print STDERR "Insufficient feedback filtering: $feednumfil  variance filtering: $varfilnum\n";
