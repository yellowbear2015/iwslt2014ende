#!/usr/bin/perl

if($#ARGV == -1) {
  print "Usage: $0 sorted_reordering_pattern_file corpus POS SVS\n";
    exit;
}

use strict;

my %patdic;

open PATT, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
my $patternnum = 0;
while(<PATT>) {
  #print;
  $patternnum++;
  chomp;
  my @pat = split "\Q|||\E";
  my @wordp = split " ", $pat[0];
  my $freq = shift @wordp;
  next if($freq <= 20 || $#wordp >= 10);
  my $wordpos = join " ", @wordp;
  my $pos = $wordpos;
  $pos =~ s/\S+?://g;
  $pos =~ s/^\s+//g;
  $pos =~ s/\s*$//g;
  $pos =~ s/ +/ /g;
  $wordpos =~ s/^\s+//g;
  $wordpos =~ s/\s*$//g;
  $wordpos =~ s/ +/ /g;
  $pat[1] =~ s/^\s+//g;
  $pat[1] =~ s/\s*$//g;
  $pat[1] =~ s/ +/ /g;
  my $len = scalar(@wordp);
  #print "len = $len\n";
  # no need to collect statics now
  # $patdic{$len}{$pos}{"totalfq"} += $freq;
  $patdic{$len}{$pos}{$pat[1]} += $freq;
  $patdic{$len}{$pos}{"lex"}{$wordpos}{$pat[1]} += $freq;
}

print STDERR "Read $patternnum patterns...\n";

open SRC, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
open POS, $ARGV[2] or die "Can't open $ARGV[2]. $!\n";
my ($srcline, $posline, $len, $k, $pos);
my $sentnum = 0;
while($srcline=<SRC>) {
    $posline = <POS>;
    print STDERR "Read $sentnum sentences...\n" if ($sentnum++ % 1000 == 0);
    my @swords = split " ", $srcline;
    my @spos = split " ", $posline;
    next if($#swords != $#spos);
    my $wordpos = "";
    for($k = 0; $k <= $#swords; $k++) {
       $wordpos .= "$swords[$k]:$spos[$k] "
    }
    print "wdpos sent: $wordpos\n";
    foreach $len (sort  {$b <=> $a} keys %patdic) {
        foreach $pos (keys %{$patdic{$len}}) {
            if($posline =~ /$pos/) {
                print "pos = $pos\n";
                $patdic{$len}{$pos}{"total"} ++;
#                if($pos eq "JJ : NN NNS") {
#                  my $kk = 0;
#                }
                foreach my $wdp (keys %{$patdic{$len}{$pos}{"lex"}}) {
                    print "wdp = $wdp\n";
                    if($wordpos =~ /$wdp/) {
                        $patdic{$len}{$pos}{"lex"}{$wdp}{"total"} ++;
                    }
                }
                last;
            }
        }
    }
}

 foreach $len (sort  {$b <=> $a} keys %patdic) {
   foreach $pos (keys %{$patdic{$len}}) {

     foreach my $rdrp (keys %{$patdic{$len}{$pos}}) {
       next if ($rdrp eq "lex" or $patdic{$len}{$pos}{"total"} == 0);
       printf "$pos ||| $rdrp ||| $patdic{$len}{$pos}{$rdrp} ||| %6.2f\n", $patdic{$len}{$pos}{$rdrp}/$patdic{$len}{$pos}{"total"};
     }

     foreach my $wdp (keys %{$patdic{$len}{$pos}{"lex"}}) {
       foreach my $rdrp (keys %{$patdic{$len}{$pos}{"lex"}{$wdp}}) {
         next if($patdic{$len}{$pos}{"lex"}{$wdp}{"total"} == 0);
       printf "$wdp ||| $rdrp ||| $patdic{$len}{$pos}{\"lex\"}{$wdp}{$rdrp} ||| %6.2f\n", $patdic{$len}{$pos}{"lex"}{$wdp}{$rdrp}/$patdic{$len}{$pos}{"lex"}{$wdp}{"total"};
     }
     }
   }
 }
