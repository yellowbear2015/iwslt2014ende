#!/usr/bin/perl

# extract word/pos pattern, collect their statistics in the corpus

if($#ARGV == -1) {
  print "Usage: $0 rdr_file source_corpus source_pos_corpus\n";
  exit (1);
}

open RDR, $ARGV[0] or die "Can't open reorder file $ARGV[0]. $!\n";
while(<RDR>) {
  chomp;
  ($fq, $pat) = split "\t";
  last if($fq < 5);
  @pats = split "\Q|||\E", $pat;
  $pos = $pats[0];
  $rdr = $pats[1];
  $rdr =~ s/^\s+//g;
  $rdr =~ s/\s*$//g;
  $pos =~ s/^\s+//g;
  $pos =~ s/\s+$//g;
  $rdrmap{$pos}{$rdr} = $fq;
}
close RDR;


open SRC, $ARGV[1] or die "Can't open source corpus $ARGV[1]. $!\n";
open POS, $ARGV[2] or die "Can't open source pos corpus $ARGV[2]. $!\n";

while($srcline = <SRC>) {
  $posline = <POS>;
  chomp $posline;
  $posline =~ s/ +/ /g;
}
