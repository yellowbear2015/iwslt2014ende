#!/usr/bin/perl

open SRC, $ARGV[0] or die "can't open src file. $ARGV[0]. $!\n";
open TGT, $ARGV[1] or die "can't open src file. $ARGV[1]. $!\n";
open ALI, $ARGV[2] or die "can't open src file. $ARGV[2]. $!\n";

while($srcline = <SRC>) {
  $tgtline = <TGT>;
  $aline = <ALI>;
  @srcwords = split " ", $srcline;
  @tgtwords = split " ", $tgtline;
  @alw = split  " ", $aline;
  %srcfertmap = ();
  #foreach $al (@alw) {
  #  ($srcpos, $tgtpos) = split "-", $al;
  #  $srcfertmap{$srcpos} ++; 
  #}
  foreach $al (@alw) {
    ($srcpos, $tgtpos) = split "-", $al;
    if($srcwords[$srcpos] =~ /^[A-Z]+$/) { # all_upper_case
      $tgtwords[$tgtpos] =~ tr/[a-z]/[A-Z]/;
    }
    #if($srcwords[$srcpos] =~ /^[A-Z][a-z]*$/ && $srcfertmap{$srcpos} == 1) { # Camel case
    #  $tgtwords[$tgtpos] = ucfirst($tgtwords[$tgtpos]);
    #}
    if(lc($srcwords[$srcpos]) eq lc($tgtwords[$tgtpos])) {
      $tgtwords[$tgtpos] = $srcwords[$srcpos];
    }
    #$tgtwords[0] = ucfirst($tgtwords[0]);
 }
 print join " ", @tgtwords;
 print "\n";
}
