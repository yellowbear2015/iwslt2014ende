#!/usr/bin/perl

open INX, $ARGV[0] or die "Can't open $ARGV[0]\n";
@X = <INX>;
close INX;

open INY, $ARGV[1] or die "Can't open $ARGV[1]\n";
@Y = <INY>;
close INY;


my $xsize = $#X + 1;
my $ysize = $#Y + 1;

if($xsize != $ysize) {
    print "$ARGV[0] and $ARGV[1] have different sizes. \n";
    exit ;
}

my $sumX = 0;
my $sumY = 0;
my $sumX2 = 0;
my $sumY2 = 0;
my $sumXY = 0;

for($i = 0; $i < $xsize; $i++) {
    $sumX += $X[$i];
    $sumX2 += $X[$i] * $X[$i];
    $sumY += $Y[$i];
    $sumY2 += $Y[$i] * $Y[$i];
    $sumXY += $X[$i] * $Y[$i];
}

my $avgX = $sumX / $xsize;
my $avgY = $sumY / $xsize;


my $rho0 = ( $xsize * $sumXY - $sumX * $sumY );
my $rho1 = sqrt( $xsize * $sumX2 - $sumX * $sumX ) * sqrt( $xsize *
							  $sumY2 -
							  $sumY *
							  $sumY );

my $rho = $rho0 / $rho1;

print "$xsize entries, cor-coeff = $rho\n";

my $errsum=0;
my $squared_errsum=0;
for($i = 0; $i < $xsize; $i++) {
  $errsum += abs($X[$i] - $Y[$i]);
  $squared_errsum += ($X[$i] - $Y[$i]) * ($X[$i] - $Y[$i]);
}
print "Mean Absoluate Error is ", $errsum/$xsize, "\n";
print "Rooted Mean Squared Error is ", sqrt($squared_errsum/$xsize), "\n";

