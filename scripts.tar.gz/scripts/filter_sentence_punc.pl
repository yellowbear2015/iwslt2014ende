#!/usr/bin/perl

while(<>) {
    chomp;
    @words = split " ";

    my $newsent = $words[0];
    for($p = 1; $p <= $#words; $p++) {
        $w = $words[$p];
        if($w eq "?" || $w eq "," || $w eq "." || $w eq "!") {
            $newsent .= '@PUNC';
            $newsent .= $w;
        }
        else {
            $newsent .= " $w";
        }
    }
    print "$newsent\n";
}
