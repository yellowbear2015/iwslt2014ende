#! /usr/bin/perl -CSD


# Insert whitespace around any char that is in the Chinese and
# Japanese scripts.  All others are left untouched.

while (<>) {
    @ch = split //;
#    s/(\p{Han}|\p{Katakana}|\p{Hiragana}|\p{Bopomofo})/ $1 /g;
#    print STDERR "NOW $_\n";
    $s = "";
    foreach $c (@ch) {
#        print "|$c| \n";
	if ($c=~/\p{Han}|\p{Katakana}|\p{Hiragana}|\p{Bopomofo}/) { 
	    $s .= " $c ";  
	}
#	elsif($c =~ '、') {
#	    $s .= " $c ";  
#	}
	else { $s .= $c; }
    }
    $s =~ s/ +/ /g;
    print "$s";
}
