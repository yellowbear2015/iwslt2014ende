#!/usr/bin/perl
#
while(<>){
  $line = $_;
  @w = split "\t";
  $src = $w[0];
  $src=~ s/^\s+\d+\s+//;
  $src=~ s/_[A-Z][A-Z]//g;
  if($w[5] =~ $src) {
    print $line;
  }
}
