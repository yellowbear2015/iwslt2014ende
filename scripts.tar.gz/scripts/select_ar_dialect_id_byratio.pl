#!/usr/bin/perl

open FILE, "$ARGV[0]" or die;
$ratio = $ARGV[1];

while(<FILE>) {
    #print;
    $inline = $_;
    @data = split " ";
    if($data[0] == 0) {
        print "-1\n";
    }
    else {
        %datamap = ();
        for($i = 1; $i <= $#data; $i++) {
            $data[$i]/=$data[0];
            $datamap{$data[$i]} .= $i;
        }
        shift @data;
        @sortdata = sort {$b<=>$a} @data;
=for comment
        print join  " ", @data;
        print "\n";
        print "XXX ";
        print join " ", @sortdata;
        print "\n";
=cut
        if($sortdata[0] <= -5.5) {
            print "5\n";
        }
        elsif($sortdata[0]/$sortdata[1] < $ratio) {
            print $datamap{$sortdata[0]}-1, "\n";
        }
        else {
            print "-1\n";
        }
    }
}
