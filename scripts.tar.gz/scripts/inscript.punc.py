import yoda
import re
from subprocess import Popen, PIPE

pat = re.compile(r'\s+')

splits = [re.compile(r'(@MULTIPUNCT \{ [^ ]* # [^ ]* })'),
    re.compile(r'( \. )'),
    re.compile(r'( \? )'),
    re.compile(r'( \! )')]


def init(tb):
    yoda.load_replacements(tb, "/mnt/vol/language_technology_mt/models/tp-gen-en-051214/Replacements.txt")
    yoda.load_regextagger(tb, "/mnt/vol/language_technology_mt/models/tp-gen-en-051214/RuleTagging.txt")
    puncP = Popen(['/home/feihuang/Download/crf++/bin/crf_test',
                      '-m',
                   '/home/feihuang/Work/Punc/train.en.punc.85p.train.label.model'],
                  stdin=PIPE, stdout=PIPE, stderr=PIPE, close_fds=True)

def process(tb, inputstring):
    string = pat.sub(' ', inputstring.rstrip(' \t\n\r').lstrip(' \t\n\r'))
    string = yoda.normalizeunicodedecomposed(tb, string)
    string = yoda.apply_regextagger(tb, string)
    string = yoda.case(tb, string)
    string = yoda.apply_replacements(tb, string)
    return pat.sub(' ', string.rstrip(' \t\n\r').lstrip(' \t\n\r'))

def split(tb, inputstring):
    string = inputstring
    rest = ''

    for splitter in splits:
        mps = splitter.split(string, maxsplit=1)
        if len(mps) == 3:
#            print 'found split:', mps
            string = mps[0] + mps[1]
            rest = mps[2] + rest
    return (string, rest)
