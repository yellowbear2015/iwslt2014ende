#!/bin/bash

outdir=$1

mkdir -p $outdir

while [ 1 ]
do
    SAMPLE_TIME=`date --rfc-3339=ns`
    ps -eo pid,user,args,pmem,rss,vsz | awk '$2 == "9049"' > $outdir"/mem_sample-$SAMPLE_TIME"
    sleep 10
done
