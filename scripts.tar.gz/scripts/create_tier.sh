#!/bin/sh
[ -z "$SMCC_OPTS" ] && SMCC_OPTS=""

if [ $# -eq 0 ] ; then
  echo "usage: servicename cluster_name"
  exit 1
fi

cluster_name=$1
service_name=$2

parent_tiername=language_technology.translation.$service_name
tiername=language_technology.translation.$cluster_name.$service_name


if smcc $SMCC_OPTS ls $parent_tiername 2>&1 > /dev/null ; then
  echo "tier $parent_tiername appears to exist"
else
  smcc $SMCC_OPTS configure $parent_tiername - <<EOF

TIER_TYPE "thrift";

classname                         ::S = FacebookServiceClient;
cluster_name                      ::S = $cluster_name;
db_init_load_wait_time            ::I = 300;
disable_versioned_table           ::B = 1;
fb303_filter_regexp               ::S = ;
fbagent_enable_fb303_collection   ::S = 1;
fbagent_enable_multiple_services  ::S = 0;
ods_detectors                     ::S = "[]";
smc_owner                         ::S = "feihuang";
sock_recvtimeout                  ::I = 1000;
sock_sendtimeout                  ::I = 250;
thrift_transport                  ::S = header;
thrift_security                   ::S = permitted;
EOF

fi


if smcc $SMCC_OPTS ls $tiername 2>&1 > /dev/null ; then
  echo "tier $tiername appears to exist"
  echo " run with 'env ALLOW_UPDATES=true' to modify"
  if [ "$ALLOW_UPDATES" != "true" ]; then
    exit 1
  fi
fi

smcc $SMCC_OPTS configure $tiername - <<EOF

TIER_TYPE "thrift";

PARENTS {
  language_technology.translation.$service_name;
}

classname                         ::S = FacebookServiceClient;
cluster_name                      ::S = $cluster_name;
db_init_load_wait_time            ::I = 300;
disable_versioned_table           ::B = 1;
fb303_filter_regexp               ::S = ;
fbagent_enable_fb303_collection   ::S = 1;
fbagent_enable_multiple_services  ::S = 0;
fbagent_fb303_parent_tier         ::S = language_technology.translation.$service_name;
ods_detectors                     ::S = "[]";
ods_rollup_name                   ::S = language_technology.translation.$service_name;
smc_owner                         ::S = "feihuang";
sock_recvtimeout                  ::I = 1000;
sock_sendtimeout                  ::I = 250;
thrift_transport                  ::S = header;
thrift_security                   ::S = permitted;
EOF
smcc $SMCC_OPTS update-smc-dependent -si $tiername $parent_tiername
