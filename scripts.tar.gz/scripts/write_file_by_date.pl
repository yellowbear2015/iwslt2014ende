#!/usr/bin/perl -CSD

use FileHandle;

my %filehandle = ();
my $sentid = 0;
my $date;
my $sent;
while(<>) {
	print "Processing sentence $sentid...\n" if($sentid ++ % 10000 ==0);
	($date, $sent) = split "\t";
	if(not exists $filehandle{$date}) {
		$fh = FileHandle->new;
		$fh->open(">$date") or die "Can't open to write $date. $!";
		$filehandle{$date}=$fh;
	}
	else {
    print {$filehandle{$date}} $sent;
	}
}

foreach $f (keys %filehandle) {
	$filehandle{$f}->close;
}
