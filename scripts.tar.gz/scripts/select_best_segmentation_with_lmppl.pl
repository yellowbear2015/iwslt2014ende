#!/usr/bin/perl

open NBEST, $ARGV[0] or die "Can't open Nbest file $ARGV[0]. $!\n";
open LMPPL, $ARGV[1] or die "Can't open lm perplexity file, $ARGV[1] $!\n";

my $curbest = "";
my $curbestscore = -9999;

while($nb=<NBEST>) {
    if($nb =~ /^NBEST_0/ && $curbest ne "") {
        #out current best
        print "$curbestscore\t$curbest";
        $curbest = "";
        $curbestscore = -9999;
    }
    $sent = <LMPPL>;
    $sentstat = <LMPPL>;
    $logline= <LMPPL>;
    $emptyline = <LMPPL>;
    #@words = split " ", $sent;
    if($logline =~ /logprob= (.+?) ppl=/) {
        $ppl = $1;
        if($ppl > $curbestscore) {
            $curbestscore = $ppl;
            $curbest = $sent;
        }
    }

}

print "$curbestscore\t$curbest";

close NBEST;
close LMPPL;
