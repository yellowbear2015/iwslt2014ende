#!/usr/bin/perl

if($#ARGV == -1) {
    print "Usage: $0  pattern_fq_file prob_threshold[=0.75] frequency_threshold[=5]\n";
    exit;
}



my $mono_order = " 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 ";
open FILE, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
my $prob_threshold = $ARGV[1];
my $freq_threshold = $ARGV[2];

if($prob_threshold == "") {
    $prob_threshold = 0.75;
}


if($freq_threshold == "") {
    $freq_threshold = 5;
}

while(<FILE>) {
    chomp;
    my @f = split "\Q|||\E";
    next if ($f[2] =~ / total /);
    next if ($f[3] < $freq_threshold);
    next if ($f[0] < $prob_threshold);
    $f[2] =~ s/ +/ /g;
    #next if ($mono_order =~ /$f[2]/);
    print "$_\n";
 }
