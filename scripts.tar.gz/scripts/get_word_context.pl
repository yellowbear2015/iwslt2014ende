#!/usr/bin/perl

sub max {
    my ($max, @vars) = @_;
    for (@vars) {
        $max = $_ if $_ > $max;
    }
    return $max;
}

sub min {
    my ($min, @vars) = @_;
    for (@vars) {
        $min = $_ if $_ < $min;
    }
    return $min;
}

open FILE, $ARGV[0];
$word = $ARGV[1];
$context_len = $ARGV[2];
while(<FILE>) {
  next if(not /$word/);
#  print;
  @w = split " ";
  for($i=0; $i <= $#w; $i++) {
    if($w[$i] eq $word) {
      $start = max(0, $i-$context_len);
      $end = min($#w, $i+$context_len);
#      print "$start -- $end\n";
      for($j = $start; $j <= $end; $j++) {
        print "$w[$j] ";
      }
      print "\n";
    }
  }
}

close FILE;
