#!/usr/bin/perl
open FILE0, $ARGV[0] or die "Can't open source file. $!\n";
open FILE1, $ARGV[1] or die "Can't open target file. $!\n";
open FILE2, $ARGV[2] or die "Cna't open alignment file. $!\n";

while($src=<FILE0>) {
  $tgt = <FILE1>;
  $al = <FILE2>;
  @swords = split " ", $src;
  @twords = split " ", $tgt;
  @align = split " ", $al;
  %alignmap = {};
  print "=====================================================\n";
  print "$src$tgt$al";
  foreach $e (@align) {
    ($spos, $tpos) = split "-", $e;
    $alignmap{$spos} .= "$tpos ";
#    print "$swords[$spos] <==> $twords[$tpos]\n";
  }
  for($i = 0; $i <= $#swords; $i++) {
    @tals = split " ", $alignmap{$i};
    next if($#tals == -1);
    print "$swords[$i] <==> ";
    foreach $t (sort @tals) {
      print "$twords[$t] ";
    }
    print "\n";
  }
  print "=====================================================\n";
}
