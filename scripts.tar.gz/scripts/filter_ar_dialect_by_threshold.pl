#/usr/bin/perl

my %score;
open FILE, $ARGV[0];
$threshold = $ARGV[1];
while(<FILE>) {
    $line = $_;
  chomp;
  @w = split " ";
  $maxratio = 0;
  for($i = 0; $i <=2; $i++) {
      $ratio = $w[3] / $w[$i];
      if($ratio > $maxratio) {
          $maxratio = $ratio;
      }
  }
    print "$maxratio\n";
}
=for comment
  $score{"egy"} = $w[1];
  $score{$w[1]} = "gul";
  $score{$w[2]} = "lev";
  $score{$w[3]} = "msa";
  $maxscore = -9999;
  $maxid = "msa";
  $foundmax = 0;
  foreach $s (sort {$b <=> $a} keys %score) {
      if($maxscore == -9999) {
          $maxscore = $s;
          $maxid = $score{$s};
          next;
      }
      $ratio = $maxscore / $s;
      if($ratio <= $threshold) {
          print "$maxid\n";
          $foundmax = 1;
          last;
      }
  }
  if (not $foundmax) {
      print "msa\n";
  }
}
=cut
close FILE;
