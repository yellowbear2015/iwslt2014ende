#!/usr/bin/perl

my %atbmap = ();
while(<>) {
    chomp;
    ($ar, $seg, $fq) = split "\t";
    $atbmap{$ar}{$seg} += $fq;
}

foreach $ar (keys %atbmap) {
    foreach $atb (sort { $atbmap{$ar}{$b} <=> $atbmap{$ar}{$a}} keys %{$atbmap{$ar}}) {
        print "$ar\t$atb\t$atbmap{$ar}{$atb}\n";
        last;
    }
}
