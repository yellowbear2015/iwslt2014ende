#!/bin/bash
python ~feihuang/bin/unescape-unicode.py $1 $1.utf8
cat $1.utf8 | perl -pe 's/\\n/ /g; s/\\\//\//g;' > $1.utf8.proc2
python ~feihuang/bin/unescape-unicode.py $1.utf8.proc2 $1.utf8.proc3
~feihuang/bin/japanese_segmenter.sh $1.utf8.proc3 > $1.tok
rm $1.utf8 $1.utf8.proc2 $1.utf8.proc3
