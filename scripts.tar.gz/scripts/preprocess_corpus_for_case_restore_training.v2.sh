#!/bin/bash
python ~/bin/unescape-unicode.py $1 $1.utf8
cat $1.utf8 |  perl -nae 'next if (!/[a-z]/); print;' | perl -nae 'next if (!/[A-Z]/); print;' > $1.utf8.camel
~/fbcode/_bin/language_technology/textprocessor ~/Work/MT/ddinf/inscript.caser.lua $1.utf8.camel preprocess |  perl -pe 's/([a-zA-Z])\1{2,}/\1\1/g; s/\[(.+)\]/[ \1 ]/g; while(/\{\{/) {s/\{\{/{/g;}; while(/\}\}/) {s/\}\}/}/g;}'
