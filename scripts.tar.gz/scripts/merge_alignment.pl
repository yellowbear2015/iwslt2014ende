#!/usr/bin/perl
open AL0, $ARGV[0] or die;
open AL1, $ARGV[1] or die;
$option = $ARGV[2];
if($option eq "") {
  $option = "inter";
}
while($line0 = <AL0>) {
  $line1 = <AL1>;
  #print $line0;
  #print $line1;
  @al0 = split " ", $line0;
  @al1 = split " ", $line1;
  my %almap = {};
  foreach $al (@al0, @al1) {
    $almap{$al} ++;
  }
  #print "merged:";
  for $a (sort {$a <=> $b} keys %almap) {
    if($option eq "inter" and $almap{$a} == 2) {
      print "$a ";
    }
    if($option eq "union" and $almap{$a} >= 1) {
      print "$a ";
    }
  }
  print "\n";
}
close AL0;
close AL1;

