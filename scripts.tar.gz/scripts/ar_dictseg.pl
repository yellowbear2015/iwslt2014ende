#!/usr/bin/perl

open DICT, $ARGV[0] or die;
while(<DICT>) {
    chomp;
    @w = split "\t";
    $segdict{$w[0]} = $w[1];
}
close DICT;

open FILE, $ARGV[1] or die;
my $sentid = 0;
while(<FILE>) {
    print STDERR "processing $sentid...\n" if ($sentid++ % 100000 == 0);
    chomp;
    @w = split " ";
    $newline = "";
    foreach $cw (@w) {
        if(exists $segdict{$cw}) {
            $newline .= "$segdict{$cw} ";
        }
        else {
            $newline .= "$cw ";
        }
    }
    print "$newline\n";
}
close FILE;
