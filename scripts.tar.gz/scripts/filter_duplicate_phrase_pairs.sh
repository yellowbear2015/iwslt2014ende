#!/bin/bash

cat $1 | perl -nae ' @w = split "\Q|||\E"; $w[0] =~ s/^\s+//g; $w[1] =~ s/^\s+//g; $w[0] =~ s/\s+$//; $w[1] =~ s/\s+$//; print if($w[0] ne $w[1]);'
