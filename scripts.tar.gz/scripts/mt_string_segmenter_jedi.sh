#!/bin/bash

cat $1 | tr "[A-Z]" "[a-z]" | perl -pe's// /g; while(/ \\ u ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) /) {s/ \\ u ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) / <b> \\u\1\2\3\4 <b> /g;} s/  / <b> /g;' > $1.space
#moses -f ~/Work/Textnorm/decompound/string_split.ini < $1.space  

/home/feihuang/fbcode/_bin/language_technology/src/jedi/jedi -f ~/Work/Textnorm/decompound/string_split.jedi.giga.ini < $1.space
cat /tmp/nbest.txt |  perl -nae 'if(/\Q|||\E(.+?)\Q|||\E/) { print "$1\n"}' | perl -pe 's/ //g; s/<b>/ /g;  s/([a-z]+)/ \1 /g;  s/ +/ /g;' > $1.nbest.seg

/home/feihuang/fbcode/_build/opt/language_technology/src/jedi/lm/query /home/feihuang/Work/LMs/post.20140310.en.13M.unescape.tp_noNE.3g.srilm.bin < $1.nbest.seg | perl -nae 'if(/Total: (.+?) /) { print "$1\n";}' > $1.nbest.seg.ppl
#~feihuang/bin/srilm/bin/i686-m64/ngram -lm /home/feihuang/Work/LMs/post.20140310.en.13M.unescape.tp_noNE.3g.srilm -ppl $1.nbest.seg -debug 1  > $1.nbest.seg.ppl
perl ~feihuang/bin/select_best_segmentation_with_kenlmppl.pl  $1.nbest.seg $1.nbest.seg.ppl | cut -f 2 > $1.seg
#rm $1.space* $1.nbest.seg*
