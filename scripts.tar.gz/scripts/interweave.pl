#!/usr/bin/env perl

$t = 0;
foreach $filename (@ARGV) {
  $filene2 = FILE."$t";
  open $filene2, "$filename" or die "Can't open $filename. $!\n";
  push @FileAry, $filene2;
  $t ++;
}
shift @FileAry;
$linenum = 0;
while($line1 = <FILE0>) {
  print "$linenum-----\n";
  print $line1;
  foreach $file (@FileAry) {
    $line2 = <$file>;
    print $line2;
  }
  $linenum ++;
}

foreach $file (@FileAry) {
    close $file;
}

exit;



