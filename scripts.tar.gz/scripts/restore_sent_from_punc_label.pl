#!/usr/bin/perl

while(<>) {
    if(/^\s*$/) {
        $newsent = "";
        for($i = 0; $i <= $#words; $i++) {
            $newsent .= "$words[$i] ";
            if($words[$i] !~ /[,\.\?!]/ && $tags[$i] ne "O") { # current word is not a punctuation
                if($i >= 1 && $i < $#words && $words[$i-1]=~ /^\w+$/ && $words[$i+1]=~ /^\w+$/) {
                    $newsent .= "$tags[$i] ";
                }
                elsif($i == $#words && $words[$i-1]=~ /^\w+$/) {
                    $newsent .= "$tags[$i] ";
                }
                elsif($i == 0 && $words[$i+1]=~ /^\w+$/) {
                    $newsent .= "$tags[$i] ";
                }
            }
        }
        print "$newsent\n";
        @words = ();
        @tags = ();
        next;
    }
    chomp;
    @ws = split "\t";
    push @words, $ws[0];
    push @tags, $ws[$#ws];

}
