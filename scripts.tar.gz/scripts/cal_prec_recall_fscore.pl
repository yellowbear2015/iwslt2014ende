#!/usr/bin/perl
$corr = $ARGV[0];
$total_retrieved = $ARGV[1];
$total_truth = $ARGV[2];

printf "precision=%6.2f\trecall=%6.2f\tfscore=%6.2f\n", $corr/$total_retrieved, $corr/$total_truth, 2*$corr/($total_retrieved+$total_truth);
