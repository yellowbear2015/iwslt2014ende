# @lint-avoid-pyflakes3
# -*- coding: utf-8 -*-

# Description: This script implements a LR segmenter based on dictionary
#              provided by user.
# Author: Feng Liang
# Email: liangfeng@fb.com
# Date: 2014-10-09 14:51:52

# add code range change for thai

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from optparse import OptionParser
import os
import sys
import codecs
import re

def create_options():
    """
    Config and parse options
    """
    parser = OptionParser()

    parser.add_option(
        '-d', '--dict_file',
        dest='dict_file',
        metavar='FILE',
        help='specify the path of dict file')
    parser.add_option(
        '-i', '--input_file',
        dest='input_file',
        metavar='FILE',
        help='specify the path of input file')
    parser.add_option(
        '-o', '--output_file',
        dest='output_file',
        metavar='FILE',
        help='specify the path of output file')
    parser.add_option(
        '-m', '--max_char',
        dest='max_char',
        type='int',
        help='specify the max number of character to match')

    option, args = parser.parse_args()
    return option

def validate_options(options):
    """
    Validate all the options
    """
    if not options.dict_file:
        raise RuntimeError('Please specify the dictionary file!')
    if not os.path.isfile(options.dict_file):
        raise RuntimeError('File not found: {0}!'.format(options.dict_file))

    if not options.input_file or not options.output_file:
        raise RuntimeError('Please specify the path of input/output file!')
    if not os.path.isfile(options.input_file):
        raise RuntimeError('File not found: {0}!'.format(options.input_file))

def load_dict(dict_path):
    """
    Load the dictionary of term: frequency
    """
    max_length = -1
    res_dict = {}
    with codecs.open(dict_path, 'r', 'utf-8') as dict_file:
        for line in dict_file:
            try:
                term, frequency = line.strip().split('\t')
                res_dict[term] = max(float(frequency), res_dict.get(term, 0.0))
                if len(term) > max_length:
                    max_length = len(term)
            except:
                continue
                print(line)
                raise RuntimeError("Incorrect dict format:"
                        " Each line should follow: term\tfrequency\n")

    return res_dict, max_length

def left_to_right_seg(line, word_dict, limit):
    """
    Scane post from left to right and segment
    """
    score = 0.0
    seg_res = []

    start_point = 0
    post_size = len(line)
    while start_point < post_size:
        max_step = min(limit, post_size - start_point)
        for i in range(max_step):
            end_point = start_point + max_step - i
            term = line[start_point: end_point]
            if term in word_dict:
                score += word_dict[term]
                seg_res.append(term)
                start_point = end_point
                break
        else:
            single_char = line[start_point: start_point + 1]
            if single_char != ' ':
                seg_res.append(single_char)
            start_point += 1

    return seg_res, score

def right_to_left_seg(line, word_dict, limit):
    """
    Scane post from right to left and segment
    """
    score = 0.0
    seg_res = []

    post_size = len(line)
    end_point = post_size
    while end_point > 0:
        max_step = min(limit, end_point)
        for i in range(max_step):
            start_point = end_point - max_step + i
            term = line[start_point: end_point]
            if term in word_dict:
                score += word_dict[term]
                seg_res.append(term)
                end_point = start_point
                break
        else:
            single_char = line[end_point - 1: end_point]
            if single_char != ' ':
                seg_res.append(single_char)
            end_point -= 1

    seg_res.reverse()
    return seg_res, score

def do_lr_segmentation(input_file_name, output_file_name, word_dict, max_char):
    """
    LR segmentation algorithm
    """
    chinese_pat = re.compile(ur'([\u0E01-\u0E59]+)')
    with codecs.open(output_file_name, 'w', 'utf-8') as out_file:
        with codecs.open(input_file_name, 'r', 'utf-8') as in_file:
            counter = 0
            for line in in_file:
                line = line.strip()
                chinese_sub_sentences = chinese_pat.findall(line)
                sub_sententces = chinese_pat.split(line)
                new_line = []
                for item in sub_sententces:
                    if len(item.strip()) == 0:
                        continue
                    # don't split non-chinese unit
                    if item not in chinese_sub_sentences:
                        new_line.append(item)
                        continue
                    l2r_list, l2r_score = left_to_right_seg(item, word_dict,
                            max_char)
                    r2l_list, r2l_score = right_to_left_seg(item, word_dict,
                            max_char)
                    result = l2r_list if l2r_score > r2l_score else r2l_list
                    new_line.extend(result)
                out_file.write('{0}\n'.format(' '.join(new_line)))
                counter += 1
                if counter > 0 and counter % 100000 == 0:
                    sys.stderr.write('{0} lines finished...\n'.format(counter))

def main():
    options = create_options()
    validate_options(options)
    word_dict, max_length = load_dict(options.dict_file)
    # if max_char is not set, use the length of the longest word in dictionary
    if not options.max_char:
        options.max_char = max_length
    do_lr_segmentation(options.input_file, options.output_file, word_dict,
            options.max_char)

if __name__ == '__main__':
    main()
