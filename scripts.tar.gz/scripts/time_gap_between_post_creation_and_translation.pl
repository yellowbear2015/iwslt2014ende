#!/usr/bin/perl

my %amap = ();
my %clickfq = ();
while(<>) {
    chomp;
    ($id, $src, $tgt, $trans, $create) = split ;
    $gap = $trans-$create;
    next if($gap < 0);
    if(not exists $amap{$id} or $amap{$id} > $gap) {
        $amap{$id} = $gap;
    }
    $clickfq{$id} ++;
}

foreach $id (keys %amap) {
    print "$id\t$amap{$id}\t$clickfq{$id}\n";
}
