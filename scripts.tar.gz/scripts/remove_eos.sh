#!/bin/bash
cat $1 | perl -nae 's/^\s*<s> //g; s/<\/s>\s*$//; print "$_\n";'
