#!/usr/bin/perl
#
use Encode qw(decode encode);
while(<>) {
  my $octets    = decode('UTF-8', $_, Encode::FB_DEFAULT);
  my $good_utf8 = encode('UTF-8', $octets, Encode::FB_CROAK);
  print $good_utf8;
}
