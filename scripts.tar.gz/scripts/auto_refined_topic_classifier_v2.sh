#!/bin/bash
for f in 1 2 3 4 5 6 7 
do
~/Download/srilm/bin/i686-m64/ngram -lm /home/feihuang/Work/MBI/Auto/intent_classify/$f.txt.proc.train.3g.srilm  -ppl $1 -debug 1 | /home/feihuang/bin/compute_avg_logprob_from_srilm_perp.pl  > $1.$f
done


paste -d ' ' $1.[1-7] | perl -nae '@data = split " "; $idxMax=0; $data[$idxMax] > $data[$_] or $idxMax = $_ for 1 ..$#data;  print $idxMax+1,"\n";' > $1.$2
