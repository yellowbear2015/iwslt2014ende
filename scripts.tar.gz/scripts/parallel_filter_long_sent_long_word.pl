#!/usr/bin/perl
my $skipnum = 0;
open SRC, $ARGV[0] or die  "Can't open $ARGV[0]. $!\n";
open TGT, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
my $maxsentlen = $ARGV[2];

$maxsentlen = 80 if ($maxsentlen eq "");

open NEWSRC, ">$ARGV[0].$maxsentlen" or die "Can't open $ARGV[0].$maxsentlen to write. $!\n";
open NEWTGT, ">$ARGV[1].$maxsentlen" or die "Can't open $ARGV[1].$maxsentlen to write. $!\n";


while($srcline=<SRC>) {
    $tgtline = <TGT>;
    @srcwords = split " ", $srcline;
    @tgtwords = split " ", $tgtline;
    my $ratio = ($#srcwords+1)/($#tgtwords+1);
    if($#srcwords > $maxsentlen || $#tgtwords > $maxsentlen) {
        $skipnum++;
        next;
    }

    my $newsrcsent = "";
    for($i = 0; $i <= $#srcwords; $i++) {
        if(length($srcwords[$i]) > 128) {
            $srcwords[$i] = substr($srcwords[$i], 0, 128);
        }
    }
    $newsrcsent = join " ", @srcwords;
    my $newtgtsent = "";
    for($i = 0; $i <= $#tgtwords; $i++) {
        if(length($tgtwords[$i]) > 128) {
            $tgtwords[$i] = substr($tgtwords[$i], 0, 128);
        }
    }
    $newtgtsent = join " ", @tgtwords;
    print NEWSRC "$newsrcsent\n";
    print NEWTGT "$newtgtsent\n";
}
print STDERR "Skipped $skipnum sentences. \n";
