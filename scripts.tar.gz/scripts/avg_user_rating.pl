#!/usr/bin/perl
my %mapscore;
while(<>){
  chomp;
  ($user, $rating) = split "\t";
  $mapscore{$user} .= "$rating ";
}
foreach $user (keys %mapscore) {
  @userscores = split " ", $mapscore{$user};
  $sum = 0;
  foreach $s (@userscores) {
    $sum += $s;
  }
  print "$user\t$mapscore{$user}\t", $sum/($#userscores+1),"\n";
}
