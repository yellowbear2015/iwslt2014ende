#!/usr/bin/perl

open FILE, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
$line = <FILE>;
print $line;
chomp $line;
@words = split " ", $line;
while(<FILE>) {
  $sent = $_;
  chomp;
  @words2= split " ";
  if(scalar(@words2) == 0) {
    print "DUPLICATE\t0\t $sent";
    next;
  }
  my %words = map{$_=>1} @words;
  my %words2 = map{$_=>1} @words2;
  my @inter = grep($words{$_}, @words2);
  my $interlen = scalar(@inter);
  if($interlen/scalar(@words2) > 0.5) {
    $ratio=$interlen/scalar(@words2);
    print "DUPLICATE\t$ratio\t $sent";
    next;
  }
  else {
    print $sent;
    @words = @words2;
  }
}
