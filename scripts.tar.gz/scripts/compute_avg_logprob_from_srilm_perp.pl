#!/usr/bin/perl

$sent = "";

while(<>) {
    next if(/^\s*$/);
    if($sent eq "") {
     $sent = $_;
    }
    if(/(\d+) sentences, (\d+) words, (\d+) OOVs/) {
        $sentnum = $1;
        $wordnum = $2;
        $oovnum  = $3;
    }
    if(/(\d+) zeroprobs, logprob= (.+?) ppl=/) {
        $logprob = $2;
        #print "logprob = $logprob, wordnum = $wordnum\n";
        #print "$sent";
        printf "%6.5f\t", $logprob/($wordnum+0.0000001);
        print "\n";
        #print $sent;
        $sent = "";
    }

}
