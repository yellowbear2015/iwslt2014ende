#!/usr/bin/perl -w

open DATA, $ARGV[0] or die;
while(<DATA>) {
    ($rating, $srcsent, $tgtsent) = split "\t";
    @words = split " ", $srcsent;
    foreach $w (@words) {
        $dict{$w} = 1;
    }
    @twords = split " ", $tgtsent;
    foreach $w (@twords) {
        $tdict{$w} = 1;
    }
}
close DATA;


open LEX, $ARGV[1] or die;
while(<LEX>) {
    ($twd, $swd, $sco) = split " ";
    if(exists $dict{$swd} && exists $tdict{$twd}) {
        print;
    }
}

close LEX;
