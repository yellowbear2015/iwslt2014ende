#!/bin/bash

train_src=$1
train_tgt=$2
lexe2f=$3
lexf2e=$4
outdir=$5
filebase=`basename $train_src`
~/fbcode/_bin/language_technology/parallel_corpora_mining/python/prepare_data.par $train_src $train_tgt > $outdir/$filebase.src_tgt

shuf -n 30000 $outdir/$filebase.src_tgt > $outdir/$filebase.src_tgt.sample-30000

~/fbcode/_bin/language_technology/parallel_corpora_mining/python/train.par --train=$outdir/$filebase.src_tgt.sample-30000 \
 --ibm=$lexe2f  --ibm_reverse=$lexf2e
cp $outdir/$filebase.src_tgt.sample-30000.png ~/public_html/
~/fbcode/_bin/language_technology/parallel_corpora_mining/python/classify.par  --ibm=$lexe2f --ibm_reverse=$lexf2e --scale_factor=$outdir/$filebase.src_tgt.sample-30000.scale-factor --model=$outdir/$filebase.src_tgt.sample-30000.svmmodel --threshold=0.5 < $6 > $6.classify_0.5
