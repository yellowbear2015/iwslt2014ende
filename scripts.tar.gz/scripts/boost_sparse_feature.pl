#!/usr/bin/perl
use strict;
my $discount_min = 0.8;
my $discount_max = 0.9;

my $min_scale = 4.0;
my $max_scale = 5.0;
my @w;
my %phrdict;
my $keystr;

open PHR, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
while(<PHR>) {
  chomp;
  @w = split "\t";
  if($w[0] >= $min_scale) {
#      print;
     my $discount_score = ($discount_min - $discount_max) * $w[0] - $min_scale * $discount_min + $max_scale * $discount_max;
     $phrdict{$w[3]."\t".$w[4]} = $discount_score;
#     print "\n".$w[3]."|\t|".$w[4], "|\t", $discount_score, "\n";
  }
}
close PHR;


open PHRASE, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
while(<PHRASE>) {
    @w = split "\Q|||\E";
    my $pw = $w[0];
    $pw =~ s/\s+$//;
    my $qw = $w[1];
    $qw =~ s/^\s+//;
    $qw =~ s/\s+$//;
    $keystr = $pw."\t".$qw;
    if(exists $phrdict{$keystr}) {
       # print;
        my @weights = split " ", $w[2];
        $weights[0] *= $phrdict{$keystr};
        $weights[1] *= $phrdict{$keystr};
        $w[2] = " $weights[0] $weights[1] $weights[2] $weights[3] ";
#        print join "|||", @w;
    }
    print join "|||", @w;
}
close PHRASE;
