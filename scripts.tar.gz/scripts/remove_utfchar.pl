#!/usr/bin/perl
while(<>) {
  next if(/u[0-9a-f]{4}/);
  @w = split "\t";
  next if($w[0] !~ /\w/);
  print;
}
