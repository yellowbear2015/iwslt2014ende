#!/usr/bin/perl

use strict;

open TSTORIG, $ARGV[0] or die "Can't open test phrase raw file. $!\n";
open TSTSTEM, $ARGV[1] or die "Can't open test phrase stem file. $!\n";
open TRAORIG, $ARGV[2] or die "Can't open train phrase raw file. $!\n";
open TRASTEM, $ARGV[3] or die "Can't open train phrase stem file. $!\n";

my @testorig = <TSTORIG>;
my @teststem = <TSTSTEM>;

chomp @testorig;
chomp @teststem;

if($#testorig != $#teststem) {
    print "Test original and stem files have different number of lines. \n";
    exit;
}

my %testphr = ();

my ($i,$j ,$k);
for($i = 0; $i <= $#testorig; $i++) {
    $testphr{$teststem[$i]}{$testorig[$i]} = 1;
}

my $trainorig;
my $trainstem;
my $sentid = 0;
while($trainorig = <TRAORIG>) {
    print STDERR "reading $sentid phrase...\n" if ($sentid++ % 100000 == 0);
    $trainstem = <TRASTEM>;
    chomp $trainorig;
    chomp $trainstem;
    if(exists $testphr{$trainstem}) {
        print "$trainstem\t$trainorig";
        foreach my $ent (keys %{$testphr{$trainstem}}) {
            print "\t$ent";
            print "[Diff]" if($trainorig ne $ent);
        }
        print "\n";
    }
}

close TSTORIG;
close TSTSTEM;
