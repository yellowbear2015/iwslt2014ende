#!/bin/bash
userid=$1
query=`echo "select fbid,languages,model from dim_detected_user_languages where ds='2015-08-24' and fbid="$userid` 
echo $query 
presto --execute "$query" --output-format=TSV_HEADER  search
query=`echo "select fbid,dialects,action from user_content_dialect_histogram where ds='2015-08-24' and fbid="$userid` 
echo $query
presto --execute "$query" --output-format=TSV_HEADER  search
