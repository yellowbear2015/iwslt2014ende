#!/bin/bash
cat $1 | perl -pe 's/\\n/ /g;' > $1.p1
python /home/feihuang/bin/unescape-unicode.py $1.p1 $1.utf8
cat $1.utf8 | perl -pe 's/\\n/ /g; s/\\\//\//g;' | perl -nae '@words = split " "; foreach $a (@words) { if(length($a)<=200) { print "$a ";} else { print substr($a, 0, 200)," ";} } print "\n"' | perl -nae 'next if(/^\s+$/);print;' > $1.utf8.proc2
/home/feihuang/Download/ark-tweet-nlp-0.3.2/twokenize.sh --just-tokenize $1.utf8.proc2 | cut -f 1 > $1.twtok
rm $1.utf8 $1.utf8.proc2 $1.p1
