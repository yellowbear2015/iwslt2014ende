import sys
import random

def read_data(path):
  null_state = 'O'
  X = []
  Y = []
  with open(path) as f:
    for line in f:
      line = line.strip()
      current_state = null_state

      tokens = line.split()
      x = []
      y = []
      for i in xrange(len(tokens)):
        token = tokens[i]
        if (token[0] == '@') and (i < len(tokens) - 1) and (tokens[i+1] == '{'):
          current_state = token[1:]
        elif token == '{':
          continue
        elif token == '}':
          current_state = null_state
        else:
          x.append(token)
          y.append(current_state)

      X.append(x)
      Y.append(y)
  return X, Y

def get_spans(seq):
  spans = []
  null_state = 'O'
  prev_state = null_state
  start = -1

  for i, state in enumerate(seq):

    # check for transition
    if state != prev_state:
      if prev_state != null_state:
        spans.append((start, i))
      start = i

    prev_state = state      

  if prev_state != null_state:
    spans.append((start, len(seq)))

  return spans

def matches(y_gold, y_pred, span):
  lo, hi = span

  # assumes that the given span actually matches a span of y_gold or y_pred
  for i in xrange(lo, hi):
    gold = y_gold[i]
    pred = y_pred[i]
    if gold != pred:
      if gold == 'O':
        err = 'halluc'
      elif pred == 'O':
        err = 'miss'
      else:
        err = 'mislabel'
      return False, err

  # check if there's stuff hanging off the end
  if hi < len(y_gold):
    state = y_gold[lo]
    if (y_gold[hi] == state) and (y_pred[hi] != state):
      return False, 'span'
    if (y_gold[hi] != state) and (y_pred[hi] == state):
      return False, 'span'

  return True, None

def evaluate_performance(X, Y_gold, Y_pred):
  tp, fp, fn = 0.0, 0.0, 0.0
  class_tps, class_fps, class_fns, class_gold_counts = dict(), dict(), dict(), dict()
  
  # errors
  errs = dict()
  errs['halluc'] = []
  errs['miss'] = []
  errs['mislabel'] = []
  errs['span'] = []

  num_gold_spans = 0
  num_pred_spans = 0

  for x, y_gold, y_pred in zip(X, Y_gold, Y_pred):

    # hack: applying replacements in yoda may split tokens such as "'s",
    # leading to a mismatch in the length of y_gold and y_pred.
    if len(y_gold) != len(y_pred):
      y_pred_new = []
      i = 0
      for token in enumerate(x):
        if len(token) > 1 and (token[0] == "'" or token[0] == '#' or token[0] == '@'):
          i += 1
        y_pred_new.append(y_pred[i])
        i += 1
      y_pred = y_pred_new

    gold_spans = get_spans(y_gold)
    pred_spans = get_spans(y_pred)
    num_gold_spans += len(gold_spans)
    num_pred_spans += len(pred_spans)

    for span in pred_spans:
      for c in y_pred[span[0] : span[1]]:
        if not c in class_tps:
          class_tps[c] = 0.0
        if not c in class_fps:
          class_fps[c] = 0.0
        if not c in class_fns:
          class_fns[c] = 0.0

      match, err = matches(y_gold, y_pred, span)
      if match:
        tp += 1
        class_tps[c] += 1
      else:
        fp += 1
        class_fps[c] += 1
        errs[err].append((x, y_gold, y_pred))

    for span in gold_spans:
      for c in y_gold[span[0] : span[1]]:
        if not c in class_tps:
          class_tps[c] = 0.0
        if not c in class_fps:
          class_fps[c] = 0.0
        if not c in class_fns:
          class_fns[c] = 0.0
        if not c in class_gold_counts:
          class_gold_counts[c] = 0

      match, err = matches(y_gold, y_pred, span)
      class_gold_counts[c] += 1
      if not match:
        fn += 1
        class_fns[c] += 1
        errs[err].append((x, y_gold, y_pred))

  print "%d gold phrases" % num_gold_spans
  print "%d pred phrases" % num_pred_spans
  print "%d pred correct" % int(tp)

  class_prf1 = dict()
  for c in class_tps:
    class_prf1[c] = compute_prf1(class_tps[c], class_fps[c], class_fns[c])

  precision, recall, F1 = compute_prf1(tp, fp, fn)
  return precision, recall, F1, class_prf1, errs, class_gold_counts


def compute_prf1(tp, fp, fn):
  precision = tp / (tp + fp) if (tp + fp > 0) else 0.0
  recall = tp / (tp + fn) if (tp + fn > 0) else 0.0
  if precision == 0.0 or recall == 0.0:
    F1 = float('nan')
  else:
    F1 = 2. / (1./precision + 1./recall)
  return precision, recall, F1


if __name__ == '__main__':
  if not len(sys.argv) == 3:
    print "usage: python %s <gold> <prediction>" % sys.argv[0]
    sys.exit(1)
  gold_file = sys.argv[1]
  pred_file = sys.argv[2]

  X, Y_pred = read_data(pred_file)
  X, Y_gold = read_data(gold_file)

  precision, recall, F1, class_perf, errs, counts = evaluate_performance(X, Y_gold, Y_pred)

  print "=" * 80
  print "Classtagger evaluation"
  print "=" * 80
  print "precision = %.4f" % precision
  print "recall = %.4f" % recall
  print "F1 = %.4f" % F1

  print "-" * 80
  print "%-20s\t%s\t%s\t%s\t%s" % ("class", "P", "R", "F1", "# gold occurrences")
  print "-" * 80
  for c, prf1 in sorted(class_perf.items(), key=lambda x: x[0]):
    p, r, f1 = prf1
    print "%-20s\t%.4f\t%.4f\t%.4f\t%d" % (c, p, r, f1, counts[c])

  print "=" * 80
  print ""

  print "Randomly sampled errors:"
  for err, examples in errs.items():
    print "\n%s" % err
    print "%d instances" % len(examples)
    random.shuffle(examples)
    for xseq, y_gold, y_pred in examples[:5]:
      print xseq
      print "gold: " + str(y_gold)
      print "pred: " + str(y_pred)
      print ""
