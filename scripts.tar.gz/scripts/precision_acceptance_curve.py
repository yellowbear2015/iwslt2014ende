from __future__ import absolute_import
from __future__ import division

import argparse
import os
from sklearn.datasets import load_svmlight_file
import numpy as np
import cPickle as pickle
from libfb import parutil
os.environ['MATPLOTLIBDATA'] = parutil.get_dir_path("matplotlib/mpl-data")
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
from math import sqrt
import language_technology.confidence_estimation.feature_generator as featgen
import codecs

def draw_precision_acceptance_graph(truth, predictions, path, steps=500,
                                    truth_threshold=4.0):
    print "Start building graph", path
    assert(len(truth) == len(predictions))
    thresholds = np.linspace(0, 5, steps)
    precisions = []
    acceptance = []
    data_size = len(predictions)
    for threshold in thresholds:
        positive_count = 0
        truth_count = 0
        for k in range(data_size):
            if predictions[k] >= threshold:
                positive_count += 1
            if predictions[k] >= threshold and truth[k] >= truth_threshold:
                truth_count += 1
        if positive_count > 0:
            precision = float(truth_count / positive_count)
        else:
            precision = 1.0

        accept = float(positive_count / data_size)
        precisions.append(precision)
        acceptance.append(accept)

    fig, ax = plt.subplots()
    ax.set_xlabel("Threshold")
    ax.set_ylabel("Percent")
    ax.set_title("Precision/Acceptance over Thresholds")
    ax.set_xticks(np.linspace(0, 5, 26))
    ax.set_yticks(np.linspace(0, 1, 21))
    ax.grid(True)
    precision_plot, = ax.plot(thresholds, precisions, 'r')
    accept_plot, = ax.plot(thresholds, acceptance, 'b')
    ax.legend(
        [precision_plot, accept_plot],
        ['Precision', 'Acceptance'],
        'lower left'
    )
    fig.savefig(path)


if __name__ == '__main__':
    with open(sys.argv[1]) as f:
        y_test = f.readlines()
    with open(sys.argv[2]) as f:
        y_pred = f.readlines()
    mse = sqrt(mean_squared_error(y_test, y_pred))
    draw_precision_acceptance_graph(y_test, y_pred, sys.argv[3] + ".png")
