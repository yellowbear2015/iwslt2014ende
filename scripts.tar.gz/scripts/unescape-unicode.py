'''
Created on Feb 24, 2014

@author: eck
'''

import sys
import re

file_handle=open(sys.argv[1])
outfile_handle=open(sys.argv[2], "w")

line=file_handle.readline()

while(line):
    line=re.sub('\\\\n', ' ', line)
    line=line.decode('unicode_escape')
    line=line.encode('utf-8')
    outfile_handle.write(line)
    line=file_handle.readline()

