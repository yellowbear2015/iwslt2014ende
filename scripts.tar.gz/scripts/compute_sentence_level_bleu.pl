#!/usr/bin/perl

open REF, $ARGV[0] or die;
open HYP, $ARGV[1] or die;

my @refs = <REF>;
my @hyps = <HYP>;

close REF;
close HYP;

die "Ref and Hyp have different number of lines. $#refs vs. $#hyps.\n" if ($#refs != $#hyps);

for($i = 0; $i <= $#refs; $i++) {
    open SREF, ">/tmp/$i.ref" or die "Can't open to write ref file for sentence $i. $!\n";
    open SHYP, ">/tmp/$i.hyp" or die "Can't open to write hyp file for sentence $i. $!\n";
    print SREF $refs[$i];
    print SHYP $hyps[$i];
    close SREF;
    close SHYP;
    system("~/bin/multi-bleu.perl -lc /tmp/$i.ref < /tmp/$i.hyp | grep BLEU >> $ARGV[1].sentbleu");
    system("rm /tmp/*ref /tmp/*hyp");
}
