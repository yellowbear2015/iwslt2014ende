import sys

src_freq_words = {}
tgt_freq_words = {}
top_N = 200
if len(sys.argv) > 4:
    top_N = int(sys.argv[4])
sys.stderr.write(str(top_N))
for f in open(sys.argv[1]).readlines():
  words = f.rstrip().split('\t')
  src_freq_words[words[1]] = int(words[2])
  if int(words[0]) > top_N:
      break

for f in open(sys.argv[2]).readlines():
    words = f.rstrip().split('\t')
    tgt_freq_words[words[1]] = int(words[2])
    if int(words[0]) > top_N:
        break

for f in open(sys.argv[3]).readlines():
    words = f.rstrip().split('|||')
    src_words = words[0].lstrip().rstrip().split(' ')
    tgt_words = words[1].lstrip().rstrip().split(' ')
    align = words[3].split(' ')
    # print(align)
    for i_j in align:
        if i_j != '':
            # print(i_j)
            (i, j) = i_j.split('-')
            src_words[int(i)] = ''
            tgt_words[int(j)] = ''
    # print(src_words)
    # print(tgt_words)
    src_unaligned = 0
    tgt_unaligned = 0
    for word in src_words:
      if word != '' and  word not in src_freq_words:
        # print(word)
        # print(f)
        src_unaligned = 1
        break
    if src_unaligned == 0:
        for word in tgt_words:
          if word != '' and  word not in tgt_freq_words:
            # print(word)
            # print(f)
            tgt_unaligned = 1
            break
    if src_unaligned == 0 and tgt_unaligned == 0 :
        sys.stdout.write(f)
