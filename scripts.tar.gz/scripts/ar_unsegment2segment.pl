#!/usr/bin/perl -CSD

open SEG, $ARGV[0] or die "Can't open $ARGV[1]. $!\n";
my $sentid = 0;
while(<SEG>) {
	#print ;
  print STDERR "process $sentid sentence \n" if ($sentid++ % 100000 == 0);
	s/(\p{Arabic}\+) /\1_pre/g; 
  s/_pre(\+\p{Arabic})/_pre_suf\1/g;
	s/ (\+\p{Arabic})/_suf\1/g; 
	chomp ;
	@segwords = split " ";
	foreach $w (@segwords) {
		$segmap{$w}++;
	}
}

foreach $segw (keys %segmap) {
	$unsegw = $segw;
	$unsegw =~ s/\+_pre//g;
	$unsegw =~ s/_suf\+//g;
	$unseg2seg{$unsegw}{$segw} = $segmap{$segw};
}

foreach $unsegw (keys %unseg2seg) {
	next if($unsegw !~ /\p{Arabic}/);
	foreach $segw  ( sort {$unseg2seg{$unsegw}{$b} <=> $unseg2seg{$unsegw}{$a}} keys %{$unseg2seg{$unsegw}}) {
		$newseg = $segw;
		$newseg =~ s/\+_pre/+ /g;
		$newseg =~ s/_suf\+/ +/g;
		if($unsegw ne $newseg) {
			print "$unsegw\t$newseg\t$unseg2seg{$unsegw}{$segw}\n";
		}
    #last;
	}
}
