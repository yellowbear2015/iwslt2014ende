#!/bin/bash
cat $1 | perl -nae 's/\@(MULTIPUNCT|hashtag|HASHTAG|DIGITS|EMOTICON|URL) \{ (.+?) # (.+?) \}/ \3 /g;s/\@(person|hashtag)\s*\.\s*(first|middle|last)name/\@\1.\2name/gi;print'
