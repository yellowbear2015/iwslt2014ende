#!/bin/bash

cat $1 | tr "[A-Z]" "[a-z]" 
