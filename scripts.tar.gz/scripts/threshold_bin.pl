#!/bin/perl
@thres = split ",", $ARGV[0];
unshift @thres, -9999;
push @thres, 9999;
open FILE, $ARGV[1] or die "can't open $ARGV[1]. $!\n";
while(<FILE>) {
  $value = $_;
  for($i = 1; $i <= $#thres; $i++) {
    if($thres[$i-1] <= $value && $thres[$i] > $value) {
      print "$i\n";
    }
  }
}
