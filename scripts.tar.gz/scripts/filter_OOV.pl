#!/usr/bin/perl

open VOC, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
while(<VOC>){
    chomp;
    #($wd, $fq) = split " ";
    ($fq, $wd) = split " ";
    $dict{$wd} = $fq;
}
close VOC;

my $oovtokenum=0;
my $oovtypenum=0;
my $toknum=0;
my $raretoknum = 0;
my $dbg = $ARGV[2];
open TXT, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
while(<TXT>) {
    $_=lc($_);
    @wds = split " ";

    if($dict{$wds[0]} > 20) {
        print;
    }
}

close TXT;
