#!/bin/bash
cat $1 | tr "[A-Z]" "[a-z]" > $1.lc
~feihuang/mosesdecoder/bin/moses -f /home/feihuang/Work/Case_Restore/En/Giga.en.2010/training/lc-tc/model/moses.ini < $1.lc > $1.tc
