#!/bin/bash
cat $1 | perl -pe 's/\n/ NEWLINE123\n/; ' | perl -pe 's/<wall \/>/<wall_\/>/g; s/<ne translation="(.+?)" entity=/<ne_translation="\1"_entity=/g; s/<\/ne>/<\/ne> BREAK123\n/' > $1.glue
~/bin/EnPOSTagger.sh $1.glue
cat $1.glue.pos.senna | perl -pe 's/^ +//g; s/[\t ]+/_/g;' | tr '\n' '\t' | perl -pe 's/\tBREAK123_(.+?)\t\t/\t/g; s/NEWLINE123_(.+?)\t/\n/g; s/\t/ /g; s/<wall_\/>/<wall \/>/g; s/<ne_translation="(.+?)"_entity=/<ne translation="\1" entity=/g; s/(<zone>|<\/ne>|<\/zone>|<wall \/>)_[A-Z]+ /\1 /g; s/ne>_(.+?)$/ne>/g; s/ne> _(.+?)$/ne>/g;' > $1.wd_pos
#rm $1.glue*
