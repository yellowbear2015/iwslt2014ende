import sys

if __name__ == '__main__':
    with open(sys.argv[1]) as f:
        for line in f:
            line = '<s> '+line.strip()+' </s>'
            tokens = line.split()
            for i in range(1, len(tokens)-1):
                print "%s %s %s" % (tokens[i], tokens[i-1], tokens[i+1])
            print ""
