import os
import sys
from math import log
#from __future__ import absolute_import
#from __future__ import division
#from __future__ import print_function
#from __future__ import unicode_literals

import codecs
import string
from collections import OrderedDict
from collections import defaultdict

def compute_word_tfidf(input_file):
    word_tf = defaultdict(int)
    word_df = defaultdict(int)
    word_tfidf = defaultdict(float)
    word_rank = OrderedDict()
    docnum = 1
    with codecs.open(input_file, 'r', 'utf-8') as in_file:
        for line in in_file:
            docnum += 1
            words = line.strip().lower().split()
            for w in words:
                print (w, " ")
                word_tf[w] += 1.0
            for w in set(words):
                word_df[w] += 1
    for w in word_tf:
        word_tfidf[w] = (1+word_tf[w]) * log (float(docnum/word_df[w]))
    rank = 0;
    for w in sorted(word_tfidf, key=word_tfidf.get, reverse=True):
#        sorted_tfidf.append(w+"\t"+str(word_tfidf[w])+"\t"+str(word_tf[w])+"\t"+str(word_df[w]))
        word_rank[w] = rank
        rank += 1
    return word_rank, word_tf, word_df


def compute_topic_words(rank1, rank2):
    common_top_N = 250
    set_top_N = 500
    gap_threshold = 100
    common = OrderedDict()
    topicword1 = OrderedDict()
    topicword2 = OrderedDict()
    words1 = set(rank1.keys())
    words2 = set(rank2.keys())
    for w in words1 & words2 :
        if (rank1[w] <= common_top_N and rank2[w] <= common_top_N):
            common[w] = rank1[w] + rank2[w]
        elif (rank1[w] - rank2[w]) > gap_threshold:
            topicword2[w] = rank1[w] - rank2[w]
        elif (rank2[w] - rank1[w]) > gap_threshold:
            topicword1[w] = rank2[w] - rank1[w]
    for w in words1 - words2 and rank1[w] <= set_top_N:
        topicword1[w] = set_top_N-rank1[w]
    for w in words2 - words1 and rank2[w] <= set_top_N:
        topicword2[w] = set_top_N-rank2[w]

    return common, topicword1, topicword2




def compute_keyword_analysis_func(input1, bgwordlist, stopwordfile, keyword):
    """
    compute topical words for file input1
    """
    sys.stderr.write("read input1 from %s\n" % input1)

    rank1, tf1, df1 = compute_word_tfidf(input1.path)
    crank = 0
    with codecs.open(bgwordlist, 'r', 'utf-8') as background:
        for line in bgwordlist:
            word, tf, df = line.strip.split('\t')
            rank2[word] = crank
            crank += 1
            tf2[word] = tf
            df2[word] = df

    common, topicwd1, topicwd2 = compute_topic_words(rank1, rank2)

    stopwords = set(line.strip() for line in open(stopwordfile))
    result_path = "/home/feihuang/temp/keyword_analysis1"

    sys.stderr.write("write result to %s\n" % result_path)

    p = re.compile('[a-zA-Z]')
    with codecs.open(result_path.path, 'w', 'utf-8') as outfile:

        outfile.write("=" * 29 + "Word List for keyword: " + keyword  + "=" * 29 + "\n")
        outfile.write("Word".ljust(25) + "Rank_Diff".ljust(20) +
                      "rank1:tf1\trank2:tf2\n")
        outfile.write("=" * 80 + "\n")
        wordnum = 0
        for w, v in sorted(topicwd1.items(),
                      key=operator.itemgetter(1), reverse=True):
            w = re.sub('\x02', '_', w)
            if rank1[w] <= MAX_RANK and tf1[w] >= FREQUENCY_THRESHOLD:
                if p.match(w) and w not in stopwords:
                    r2 = ctf = -1
                    if rank2.get(w, -1) > -1:
                        r2 = rank2[w]
                        ctf = tf2[w]
                outfile.write(w.ljust(25) + str(v).ljust(20) +
                      "%d:%d\t\t%d:%d\n" % (rank1[w], tf1[w], r2, ctf))
                wordnum += 1
                if wordnum > TOP_N_WORDNUM:
                    break
        outfile.write("=" * 80 + "\n\n\n")

    return result_path

compute_keyword_analysis_func(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])

"""

(rank1, tf1, df1)= compute_word_tfidf(sys.argv[1])
print ('\n'.join(rank1))
(rank2, tf2, df2) = compute_word_tfidf(sys.argv[2])
print ('\n'.join(rank2))
(common, topicwd1, topicwd2) = compute_topic_words(rank1, rank2)
print "==========Common Word List===========\n"
for w in common:
    print "%s\t%6.2f\t%6.2f%6.2f\n"%(w,common[w],rank1[w],rank2[w])
print "=========================\n";

print "==========Word List from Group1===========\n"
for w in topicwd1:
    print "%s\t%6.2f\t%6.2f%6.2f\n"%(w,topicwd1[w],rank1[w],rank2[w])
print "=========================\n";

print "==========CWord List from Group2===========\n"
for w in topicwd2:
    print "%s\t%6.2f\t%6.2f%6.2f\n"%(w, topicwd2[w],rank1[w],rank2[w])
print "=========================\n";
"""
