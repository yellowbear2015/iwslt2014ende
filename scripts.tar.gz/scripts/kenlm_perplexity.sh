#!/bin/bash
~/bin/query $1 < $2 | perl -nae 'if(/^(.+?)Total: (.+?) OOV:/) {@w = split "=", $1; $val = $2; printf "%6.4f\n", $val/($#w-1);}' > $2.perp
