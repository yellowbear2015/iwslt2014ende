#!/usr/bin/perl

use strict;

if($#ARGV == -1) {
    print "$0 reorder_pattern input_word input_pos\n";
    exit;
}
my %rdrpat = ();

open RDR, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
while(<RDR>) {
    chomp;
    my @f = split "\Q|||\E";
    $f[1] =~ s/^\s+//g;
    $f[2] =~ s/^\s+//g;
    $f[1] =~ s/\s+$//g;
    $f[2] =~ s/\s+$//g;
#    $rdrpat{$f[1]}{$f[2]} = $f[0] * log($f[3]);
    $rdrpat{$f[1]}{$f[2]} = -log($f[0]);
}
close RDR;

open WORD, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
open POS, $ARGV[2] or die "Can't open $ARGV[2]. $!\n";

my ($wordline, $posline, $i, $j, $k);
my $sentid = 0;
while($wordline = <WORD>) {
    $posline = <POS>;
    chomp $wordline;
    chomp $posline;
    print STDERR "processing $sentid sentence...\n" if ($sentid++ % 100 == 0);
    my %rdredgeweight = ();
    my $rdr;
    my @swords = split " ", $wordline;
    my @spos = split " ", $posline;
    next if($#swords != $#spos);
    my @wordpos = ();
    for($k = 0; $k <= $#swords; $k++) {
        push @wordpos, "$swords[$k]:$spos[$k]";
    }

    $posline = " $posline ";
    foreach my $pos (keys %rdrpat) {
        my $startpos = 0;
        my $foundp = index($posline, " $pos ", $startpos);
        while($foundp != -1) {

            my $prevstr = "";
            if($foundp > 0) {
                $prevstr = substr($posline, 0, $foundp-1);
            }
            my @prevwds = split " ", $prevstr;
            my $stp = $#prevwds+1;
            print "Matched: $stp [ $pos ] <in> $posline\n";
            my @cpos = split " ", $pos;
            my $endp = $stp+$#cpos;

            foreach $rdr (keys %{$rdrpat{$pos}}) {
                my $matchedwdpos = join " ", @wordpos[$stp..$endp];
                print "rdr pattern: $matchedwdpos  $rdr $rdrpat{$pos}{$rdr}\n";
                $rdredgeweight{$stp}{$rdr} += $rdrpat{$pos}{$rdr};
            }

            my @cwdpos = @wordpos[$stp..$stp+$#cpos];
            my $cwdposstr = join " ", @cwdpos;

            if(exists $rdrpat{$cwdposstr}) {
                foreach $rdr (keys %{$rdrpat{$cwdposstr}}) {
                    print "rdr pattern: $rdr $rdrpat{$cwdposstr}{$rdr}\n";
                    $rdredgeweight{$stp}{$rdr} += $rdrpat{$cwdposstr}{$rdr};
                }
            }
            else {
                my @cwd = @swords[$stp..$stp+$#cpos];
                print "Match WITHOUT wdpos: ", join " ", @cwd, "\n";
            }
            $startpos = $foundp+length($pos);
            $foundp = index($posline, $pos, $startpos);
        }
    }

    # print lattice
    print "PLF\t(";
    for($j = 0; $j <= $#swords; $j++) {
        print "(";
        my $word = $swords[$j];
        $word =~ s/\'/\\'/g;
        print "('$word', 1.0, 1),";
        if(exists $rdredgeweight{$j})  {
            foreach $rdr (keys %{$rdredgeweight{$j}}) {
                my @rdrw = split " ", $rdr;
                my @origw = @swords[$j..$j+$#rdrw];
                my $newphrase = "";
                for($i = 0; $i <= $#rdrw; $i++) {
                    $newphrase .= "$origw[$rdrw[$i]] ";
                }
                $newphrase =~ s/ $//g;
                $newphrase =~ s/\'/\\'/g;
                my $len = $#rdrw+1;
                printf "('$newphrase', %5.2f, $len),", $rdredgeweight{$j}{$rdr};
            }
        }
        print "),";
    }
    print ")\n";

    print "BEING_OF_FSM\n============================\n";
    my $node = 0;
    for($j = 0; $j <= $#swords; $j++) {
        print "$j\t",$j+1,"\t$swords[$j]\t1.0\n";
        if(exists $rdredgeweight{$j}) {
            foreach $rdr (keys %{$rdredgeweight{$j}}) {
                my @rdrw = split " ", $rdr;
                my @origw = @swords[$j..$j+$#rdrw];
                my $newphrase = "";
                for($i = 0; $i <= $#rdrw; $i++) {
                    $newphrase .= "$origw[$rdrw[$i]] ";
                }
                $newphrase =~ s/ $//g;
                #$newphrase =~ s/\'/\\'/g;
                my $len = $#rdrw+1;
                printf "$j\t%d\t$newphrase\t%5.2f\n",$j+$len, $rdredgeweight{$j}{$rdr};
            }
        }
    }
    print "$j\t1.0\n";
    print "END_OF_FSM\n";

}
