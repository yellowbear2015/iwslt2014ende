#!/bin/bash
~/fbcode/_bin/language_technology/yoda /mnt/vol/language_technology_mt/models/tp-gen-en-051214/ inscript $1 |  ~/bin/remove_tp_tag.sh 
