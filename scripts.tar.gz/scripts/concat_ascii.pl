#! /usr/bin/perl -CSD


while (<>) {
    @ch = split / /;
    $s = "";
    foreach $c (@ch) {
#        print "|$c| \n";
	if ($c=~/\p{Han}|\p{Katakana}|\p{Hiragana}|\p{Bopomofo}/) {
	    $s .= " $c ";
	}
	else { $s .= $c; }
    }
    $s =~ s/_SPACE_/ /g;
    $s =~ s/ +/ /g;
    print "$s";
}
