#!/usr/bin/perl

if($#ARGV == -1) {
    print "Add dummy sgml markup in plain text file.\n";
    print "Usage: $0 plaintext [sysname]\n";
    exit;
}

my $beadid = 0;
my $sysname = "dummy";
$sysname = $ARGV[1] if($ARGV[1] ne "");


print "<tstset setid=\"sample_set\" srclang=\"Arabic\" trglang=\"English\" sysid=\"NIST\">\n";

print "<DOC tstset=\"dummy_0\" docid=\"dummy_0\" sysid=\"",$sysname, "\">\n";


open TXT, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
while(<TXT>) {
    chomp;
    print "<seg id=\"",$beadid++,"\"> $_ </seg>\n";
}
print "</DOC>\n";
print "</tstset>\n";
close TXT;
