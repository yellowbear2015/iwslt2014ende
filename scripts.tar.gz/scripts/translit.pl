#!/usr/bin/perl -CSD

# Insert whitespace around any char that is in the source language scripts. All others are left untouched.

use strict;


if($#ARGV == -1) {
 print "Usage: $0 transliteration-direction (ar2en|ru2en) input_file\n";
 exit;
}


my $srclang = "";
my $tgtlang = "en";

if($ARGV[0] eq "ar2en") {
 $srclang = "ar";
}
elsif($ARGV[0] eq "ru2en") {
 $srclang = "ru"
}

open INP, $ARGV[1] or die "Can't open $ARGV[0]. $!\n";
open SP1, ">/tmp/$$.sp1" or die "Can't open /tmp/$$.sp1. $!\n";

my @words;
my @ch;
my ($s, $c, $w, $oov, $oovtrl);
my %trldict;

while (<INP>) {
 @words = split " ";
 foreach $w (@words) {
 if ( ($w !~ /\p{Arabic}/ && $srclang eq "ar") ||
 ($w !~ /\p{Cyrillic}/ && $srclang eq "ru")) {
 next;
 }
 @ch = split //, $w;
 $s = "";
 foreach $c (@ch) {
 if (($c=~/\p{Arabic}/ && $srclang eq "ar") ||
 ($c=~/\p{Cyrillic}/ && $srclang eq "ru")) {
 $s .= " $c ";
 }
 else { $s .= $c; }
 }
 $s =~ s/ +/ /g;
 print SP1 "$s\n";
 }
}
close INP;
close SP1;

if($srclang eq "ar" && $tgtlang eq "en") {

 system("cat /tmp/$$.sp1 | sort -u > /tmp/$$.sp1.uniq; ~/fbcode/_bin/language_technology/src/jedi/jedi -f /mnt/vol/language_technology_mt/transliterate/ar2en/moses.ini < /tmp/$$.sp1.uniq > /tmp/$$.sp2.uniq");
}
elsif($srclang eq "ru" && $tgtlang eq "en") {
 system("cat /tmp/$$.sp1 | sort -u > /tmp/$$.sp1.uniq; ~/fbcode/_bin/language_technology/src/jedi/jedi -f /mnt/vol/language_technology_mt/transliterate/ru2en/moses.ini < /tmp/$$.sp1.uniq > /tmp/$$.sp2.uniq");
}





open OOV, "/tmp/$$.sp1.uniq" or die;
open OOVTRL, "/tmp/$$.sp2.uniq" or die;
while($oov = <OOV>) {
 chomp $oov;
 $oov =~ s/ //g;
 $oovtrl = <OOVTRL>;
 chomp $oovtrl;
 $oovtrl =~ s/ //g;
 $trldict{$oov} = $oovtrl;
}

open INP, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
while (<INP>) {
 @words = split " ";
 my $newsent = "";
 foreach $w (@words) {
 if (($w !~ /\p{Arabic}/ && $srclang eq "ar") ||
 ($w !~ /\p{Cyrillic}/ && $srclang eq "ru")) {
 $newsent .= "$w ";
 }
 else {
 $newsent .= "$trldict{$w} ";
 }
 }
 print "$newsent\n";
}

close INP;

system("rm /tmp/$$.*");
