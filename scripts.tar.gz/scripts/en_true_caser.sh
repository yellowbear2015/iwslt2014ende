#!/bin/bash

cat $1 | perl -nae '@words = split " "; print "<s> "; foreach $a (@words) { print "$a " if(length($a)<=200); } print " </s> \n"'  > $1.case.in
/home/feihuang/bin/pandora /home/feihuang/Work/Case_Restore/En/1M.clean/pandora/ToBeCopiedToPDA/train.1M.decoder.sample.cfg 1 -4G -b 15 -l 100 -t 40 -r 1400 -w 5 < $1.case.in > $1.case.out
cat $1.case.out | perl -pe 's/^<s> //g; s/<\/s>\n/\n/;' > $1.tc
