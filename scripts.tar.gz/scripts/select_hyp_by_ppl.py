import sys, re
import pdb

hyp = open(sys.argv[1], 'r')
sco = open(sys.argv[2], 'r')

besthyp = ""
prevsigline = ""
bestscore = -9999


for chyp in open(sys.argv[1], 'r'):
    chyp = chyp.rstrip();
    sigline = re.sub(' ', '', chyp);
    if(sigline != prevsigline and besthyp != ""):
       print bestscore, "\t", besthyp
       besthyp = ""
       bestscore = -9999
    csco = float(sco.readline())
    if(csco > bestscore) :
       bestscore = csco
       besthyp = chyp
    prevsigline = sigline

print bestscore, "\t", besthyp
