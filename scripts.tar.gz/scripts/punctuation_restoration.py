import sys, re
import pdb
import subprocess

def sent2wdperline(sent):
    return re.sub(" ", "\n", sent)

def wdperline2sent(word_labels, num_words):
    wl_lists = word_labels.split("\n")
    newsent = "";
    words = [];
    labels = [];

    for index in range(num_words):
        print wl_lists[index]
        (word, label) = wl_lists[index].split('\t');
        words.append(word);
        labels.append(label);


    for index in range(num_words):
       newsent += words[index] + ' '
       print words[index]
       if(labels[index] != 'O' and re.match('[,\.\?!]', words[index]) == None) :
           if(index == 0 and re.match('^\w+$', words[index+1]) != None):
              newsent += labels[index] + ' ';
           elif(index == num_words-1 and re.match('^\w+$', words[index-1]) != None):
              newsent += labels[index] + ' ';
           elif(index >= 1 and index < num_words and \
                re.match('^\w+$', words[index-1]) != None and \
                re.match('^\w+$', words[index+1]) != None) :
              newsent += labels[index] + ' ';
    return newsent


puncP = subprocess.Popen(['/home/feihuang/Download/crf++/bin/crf_test',
                      '-m',
                   '/home/feihuang/Work/Punc/train.en.punc.85p.train.label.model'],
                  stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True)



while True:
    line = sys.stdin.readline()
    if not line:
        break
#line = 'this is a test ibm'
    line=re.sub('^\s+', '', line);
    line=re.sub('\s+$', '', line);
    print line
    pdb.set_trace()
    num_words = len(line.split(' '))
    print 'num_words = ', num_words;
    label_line = sent2wdperline(line)
    word_labels, _ = puncP.communicate(label_line)
    punc_sent = wdperline2sent(word_labels, num_words)
    print punc_sent
