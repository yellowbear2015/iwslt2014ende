#!/usr/bin/perl
open WORDW, $ARGV[0] or die;

while(<WORDW>) {
    chomp;
    ($word, $weight) = split "\t";
    next if($weight < 0);
    $wordweight{$word} = $weight;
}

close WORDW;

open FILE, $ARGV[1] or die;
while(<FILE>) {
    print STDERR "processing $t sentence \n" if (++$t % 100000 == 0);
    chomp;
    tr/[A-Z]/[a-z]/;
    @words = split " ";
    my %wdmap ;
    foreach $w (@words) {
      $wdmap{$w} = 1;
    }
    $val = 0;
    foreach $w (keys %wdmap) {
        if(exists $wordweight{$w}) {
          #print "$words[$i]\t$wordweight{$words[$i]}\n";
            $val += $wordweight{$w};
        }
    }
    $val /= (scalar keys %wdmap);
    print "$val\n";
}
