#!/usr/bin/perl

open LOG, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
open RATING, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";

$avgrating = $ARGV[2];
my %allworddict = ();
my %allphrdict = ();
while(<LOG>) {
    if(/TRANSLATION HYPOTHESIS DETAILS:/) {
        my %cworddict = {};
        my %cphrdict = ();
        my $sourcephr = "";
        my $targetphr = "";
        my @srcwords = ();
        my @tgtwords = ();
        while($line = <LOG>) {
            if($line =~ /SOURCE: \[\d+..\d+] (.+?)$/) {
                $sourcephr = $1;
                $sourcephr =~ s/^\s+//g;
                $sourcephr =~ s/\s+$//g;
                @srcwords = split " ", $sourcephr;
            }
            if($line =~ /TRANSLATED AS: (.+?)$/) {
                $targetphr = $1;
                $targetphr =~ s/^\s+//g;
                $targetphr =~ s/\s+$//g;
                @tgtwords = split " ", $targetphr;
                $cphrdict{$sourcephr}{$targetphr} = 1;
            }
            if($line =~ /WORD ALIGNED: (.+?)/) {
                @wordal = split " ", $1;
                foreach $wa (@wordal) {
                    ($spos, $tpos) = split "-", $wa;
                    $cworddict{$srcwords[$spos]}{$tgtwords[$tpos]} = 1;
                }
            }
            if($line =~ /SCORES \(UNWEIGHTED/) {
                $crate = <RATING>;
                chomp $crate;
#                $weight = $crate/$avgrating;
                $weight = $crate;
                last if($weight == 0);
                foreach $sphr (keys %cphrdict) {
                    foreach $tphr (keys %{$cphrdict{$sphr}}) {
#                        print "$sphr<>$tphr\t$crate\t$weight\n";
                        if(not exists $allphrdict{$sphr}{$tphr}) {
                            $allphrdict{$sphr}{$tphr} = $weight;
                        }
                        else {
                            $allphrdict{$sphr}{$tphr} .= " $weight";
                        }
                    }
                }
=for comment
                foreach $swd (keys %cworddict) {
                    foreach $twd (keys %{$cworddict{$swd}}) {
                        if(not exists $allworddict{$swd}{$twd}) {
                            $allworddict{$swd}{$twd} = $weight;
                        }
                        else {
                            $allworddict{$swd}{$twd} *= $weight;
                        }
                    }
                }
=cut
                last;
            }
        }
    }
}


foreach $sphr (keys %allphrdict) {
    foreach $tphr (keys %{$allphrdict{$sphr}}) {
        @tsco = split " ", $allphrdict{$sphr}{$tphr};
        $var = 0;
        $avg = 0;
        foreach $p (@tsco) {
            $avg += $p;
        }
        $avg /= ($#tsco+1);
        foreach $p (@tsco) {
            $var += ($p-$avg)* ($p-$avg);
        }
        $var /= ($#tsco+1);
        print "$avg\t$var\t$allphrdict{$sphr}{$tphr}\t$sphr\t$tphr\n";
    }
}
=for comment
foreach $sphr (keys %allworddict) {
    foreach $tphr (keys %{$allworddict{$sphr}}) {
        print "WordLex\t$allworddict{$sphr}{$tphr}\t$sphr\t$tphr\n";
    }
}
=cut
