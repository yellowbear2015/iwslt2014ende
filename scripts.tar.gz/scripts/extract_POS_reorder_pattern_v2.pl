#!/usr/bin/perl
# read src, tgt ali and src_pos, find reordering phrases and their POS
# then extract word_POS pair with reordering patterns
# example: red_JJ car_NN -> car_NN red JJ given alignment 0-1 1-0
use List::Util qw(first min max);
use strict;
if($#ARGV == -1) {
    print "Usage: src tgt al src_pos \n";
    exit;
}

open SRCFILE,   $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
open TGTFILE,   $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
open ALFILE,    $ARGV[2] or die "Can't open $ARGV[2]. $!\n";
open SRCPOSFILE,$ARGV[3] or die "Can't open $ARGV[3]. $!\n";

my ($srcline,$tgtline, $alline, $srcposline);
my ($i, $j, $k, $kt);

while($srcline=<SRCFILE>) {
    $tgtline=<TGTFILE>;
    $alline=<ALFILE>;
    $srcposline=<SRCPOSFILE>;
    chomp $srcline;
    chomp $tgtline;
    my @srcwords = split " ", $srcline;
    my @tgtwords = split " ", $tgtline;
    my @align;
    my @svs;
    my @t2s;
    for($i = 0; $i <= $#tgtwords; $i++) {
        push @t2s, "";
    }
    chomp $tgtline;
    my @tgtwords = split " ", $tgtline;
    chomp $alline;
    my @al = split " ", $alline;
    chomp $srcposline;
    my @srcposes = split " ", $srcposline;
    next if($#srcposes != $#srcwords);

    for($i = 0; $i <= $#al; $i++) {
        my ($s, $t) = split "-", $al[$i];
        $t2s[$t].= "$s ";
    }

    for($i = 0; $i <= $#tgtwords; $i++) {
        push @svs, split " ", $t2s[$i];
    }
    print $srcline, "\n";
    print $srcposline, "\n";
    print $tgtline, "\n";
    print $alline, "\n";
    print join " ", @svs, "\n";
    for($i = 0; $i < $#svs; $i++){
        # find reordered phrase
        for(my $j = $#svs; $j > $i; $j--) {
            if($svs[$i] > $svs[$j] && $svs[$j] != -1) {  #[$i, $t]
            # reordering start at $svs[$i] and end at $svs[$j]
            my @rdrsvs = @svs[$i..$j];
            my $start = min(@rdrsvs);
            my $end = max(@rdrsvs);
            my $rdrwdpos = "";
            my $rdrsvsstr = " ".(join " ", @rdrsvs)." "; 
            for($k = $start; $k <= $end; $k++) {
              #if @rdrsvs  does not contain $k #then attach $k after $k-1 in rdrsvs; #make sure rdrsvs size == $end-$start+1;
              if($rdrsvsstr !~ / $k /) {
                my $p = $k-1;
                $rdrsvsstr =~ s/ $p / $p $k /;
              }
            }
            $rdrsvsstr =~ s/^ //;
            $rdrsvsstr =~ s/ $//;
            my @rdrsvs2 = split " ", $rdrsvsstr;
            my @rdrsvssort = sort {$a <=> $b} @rdrsvs2;
            my $alorder = "";
            for($k = $start; $k <= $end; $k++) {
                $rdrwdpos .= "$srcwords[$k]:$srcposes[$k] ";
                my $idx = first { $rdrsvssort[$_] eq $rdrsvs2[$k-$start] } 0..$#rdrsvssort;
                $alorder .= "$idx ";
            }
            
            my $left = "";
            my $right = "";
            my $leftpos = $start;
            my $rightpos = $end;
            if($leftpos == 0) {
                $left = "<s>";
            }
            else {
                $left = "$srcwords[$leftpos-1]:$srcposes[$leftpos-1]";
            }
            if($rightpos == $#srcwords) {
                 $right = "</s>";
            }
            else {
                 $right = "$srcwords[$rightpos+1]:$srcposes[$rightpos+1]";
            }

            print "$left ||| $rdrwdpos ||| $right ||| $alorder\n";
            # find the max reordeing span, then move to the next span, does not allow overlap within span
            # last;
            $i = $j+1;
            }
        }
    }
    my $end_sentence = 1;
}
