#!/usr/bin/perl
# read src, tgt ali and src_pos, find reordering phrases and their POS
# then extract word_POS pair with reordering patterns
# example: red_JJ car_NN -> car_NN red JJ given alignment 0-1 1-0
use List::Util qw(first min max);
use strict;
if($#ARGV == -1) {
    print "Usage: src tgt al src_pos \n";
    exit;
}

open SRCFILE,   $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
open TGTFILE,   $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
open ALFILE,    $ARGV[2] or die "Can't open $ARGV[2]. $!\n";
open SRCPOSFILE,$ARGV[3] or die "Can't open $ARGV[3]. $!\n";

my ($srcline,$tgtline, $alline, $srcposline);
my ($i, $j, $k, $kt);

while($srcline=<SRCFILE>) {
    $tgtline=<TGTFILE>;
    $alline=<ALFILE>;
    $srcposline=<SRCPOSFILE>;
    chomp $srcline;
    chomp $tgtline;
    my @srcwords = split " ", $srcline;
    my @tgtwords = split " ", $tgtline;
    my @align;
    my @svs;
    my @t2s;
    for($i = 0; $i <= $#tgtwords; $i++) {
        push @t2s, "";
    }
    chomp $tgtline;
    my @tgtwords = split " ", $tgtline;
    chomp $alline;
    my @al = split " ", $alline;
    chomp $srcposline;
    my @srcposes = split " ", $srcposline;
    next if($#srcposes != $#srcwords);

    for($i = 0; $i <= $#al; $i++) {
        my ($s, $t) = split "-", $al[$i];
        $t2s[$t].= "$s ";
    }

    for($i = 0; $i <= $#tgtwords; $i++) {
        push @svs, split " ", $t2s[$i];
    }
    my $swdpos = "";
    for(my $u = 0; $u <= $#srcwords; $u++) {
      $swdpos .= "$srcwords[$u]:$srcposes[$u] ";
    }
    print $srcline, "\n";
    print $srcposline, "\n";
    print $tgtline, "\n";
    print $alline, "\n";
    print "swdpos: $swdpos\n";
    my $svsstr = " ".(join " ", @svs)." ";
    my %unalignedsrc = ();
    #if @svs  does not contain $k then attach $k after $k-1 in svs;
    for($k = 0; $k <= $#srcwords; $k++) {
      if($svsstr !~ / $k /) {
        my $p = $k-1;
        $unalignedsrc{$k} = 1;
        $svsstr =~ s/ $p / $p $k /;
      }
    }
    for($k = $#srcwords; $k >= 0; $k--) {
        if($svsstr !~ / $k /) {
            my $p = $k+1;
            $unalignedsrc{$k} = 1;
            $svsstr =~ s/ $p / $k $p /;
        }
    }

    $svsstr =~ s/^ //;
    $svsstr =~ s/ $//;
    my @augsvs = split " ", $svsstr;
    if($#augsvs != $#srcwords) {
      print "ERROR:  duplicate src words in svs...\n";
    }
    print "svsstr:$svsstr\n";
    print "unaligned: ", join " ", (sort {$a <=> $b} keys %unalignedsrc), "\n";
    my $j;
    for($i = 0; $i < $#augsvs; $i++){
        # find reordered phrase
        for($j = $#augsvs; $j > $i; $j--) {
            my $rdrwdpos = "";
            if($augsvs[$i] > $augsvs[$j]) { 
            # reordering start at $augsvs[$i] and end at $augsvs[$j]
            my @rdrsvs = @augsvs[$i..$j];
            my @rdrsvssort = sort {$a <=> $b} @rdrsvs;
            my $alorder = "";
            for($k = $i; $k <= $j; $k++) {
                $rdrwdpos .= "$srcwords[$k]:$srcposes[$k] ";
                my $idx = first { $rdrsvssort[$_] eq $rdrsvs[$k-$i] } 0..$#rdrsvssort;
                $alorder .= "$idx ";
            }

            my $left = "";
            my $right = "";
            my $leftpos = $i;
            my $rightpos = $j;
            if($leftpos == 0) {
                $left = "<s>";
            }
            else {
                $left = "$srcwords[$leftpos-1]:$srcposes[$leftpos-1]";
            }
            if($rightpos == $#srcwords) {
                 $right = "</s>";
            }
            else {
                 $right = "$srcwords[$rightpos+1]:$srcposes[$rightpos+1]";
            }

            print "$left ||| $rdrwdpos ||| $right ||| $alorder\n";
            # find the max reordeing span, then move to the next span, does not allow overlap within span
            #last;
            #}
            $i = $j;
          } 
        }
    }
    my $end_sentence = 1;
}
