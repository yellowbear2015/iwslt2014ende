#!/usr/bin/perl
use strict;

open LOG, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
open PHR, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
open VOC, $ARGV[2] or die "Can't open $ARGV[2]. $!\n";

my %dict=  ();
my $phrnum = 0;
my %vocab = ();


while(<VOC>) {
    chomp;
    s/\s+$//g;
    $vocab{$_} = 1;
}

while(<PHR>) {
    my $inphr = $_;
    my @w = split "\Q|||\E";
    next if($#w != 5 );
    $dict{$w[0]}{$inphr} = 1;
    print STDERR "Reading $phrnum phrase...\n" if ($phrnum++ % 10000 == 0);
}

while(<LOG>) {
    if(/Candidate\|/) {
        chomp;
        s/^Not Found: //g;
        s/Candidate\|//g;
        s/ +/ /g;
        my @phr = split "\t";
        my @swords =split " ", $phr[0];
        my $oovflag = 0;
        foreach my $sw (@swords) {
            if(not exists $vocab{$sw}) {
                $oovflag = 1;
                last;
            }
        }
        next if($oovflag == 0);
        for(my $i = 1; $i <= $#phr; $i++) {
            if(exists $dict{$phr[$i]}) {
                foreach my $entline (keys %{$dict{$phr[$i]}}) {
                    my $newline = $entline;
                    #$newline =~ s/^(.+?)\Q|||\E//;
                    my @nwp = split "\Q|||\E", $newline;
                    my @val = split " ", $nwp[2];
                    my $newval = " ";
                    for(my $k = 0; $k <= $#val; $k++) {
                        $newval .= 0.05 * $val[$k];
                        $newval .= " ";
                    }
                    $nwp[2] = $newval;
                    $nwp[0] = $phr[0];
                    print join "|||", @nwp;
                }
            }
        }
    }
}

close PHR;
close LOG;
