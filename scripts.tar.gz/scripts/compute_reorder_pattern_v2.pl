#!/usr/bin/perl
use List::Util qw(first min max);
use strict;

if($#ARGV == -1) {
  print "Usage: $0 sorted_reordering_pattern_file corpus POS SVS\n";
    exit;
}




sub get_rank() {
    my @rdrsvs = @_;
    my @rdrsvssort = sort {$a <=> $b} @rdrsvs;
    my $alorder = "";
    for(my $k = 0; $k <= $#rdrsvs; $k++) {
        my $idx = first { $rdrsvssort[$_] eq $rdrsvs[$k] } 0..$#rdrsvssort;
        $alorder .= "$idx ";
    }
    return $alorder;
}


my %patdic;
my %patorderfq;
my $pattern_frequency_threshold = 10;
my $pattern_length_threshold = 15;
open PATT, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
my $patternnum = 0;
while(<PATT>) {
  #print;
  $patternnum++;
  chomp;
  my @pat = split "\Q|||\E";
  my @wordp = split " ", $pat[0];
  my $freq = shift @wordp;
  next if($freq <= $pattern_frequency_threshold || $#wordp >= $pattern_length_threshold);
  my $wordpos = join " ", @wordp;
  my $pos = $wordpos;
  $pos =~ s/\S+?://g;
  $pos =~ s/^\s+//g;
  $pos =~ s/\s*$//g;
  $pos =~ s/ +/ /g;
  $wordpos =~ s/^\s+//g;
  $wordpos =~ s/\s*$//g;
  $wordpos =~ s/ +/ /g;
  $pat[1] =~ s/^\s+//g;
  $pat[1] =~ s/\s*$//g;
  $pat[1] =~ s/ +/ /g;
  #print "len = $len\n";
  # no need to collect statics now
  # $patdic{$len}{$pos}{"totalfq"} += $freq;
  $patdic{$pos}{$pat[1]} += $freq;
  $patdic{$pos}{"lex"}{$wordpos}{$pat[1]} += $freq;
}

print STDERR "Read $patternnum patterns...\n";

open SRC, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
open POS, $ARGV[2] or die "Can't open $ARGV[2]. $!\n";
open SVS, $ARGV[3] or die "Can't open $ARGV[2]. $!\n";
my ($srcline, $posline, $svsline, $unalsrcline, $k, $pos);
my $sentnum = 0;
while($srcline=<SRC>) {
    $posline = <POS>;
    $posline = " $posline ";
    #last if($sentnum > 5000);
    print STDERR "Read $sentnum sentences...\n" if ($sentnum++ % 1000 == 0);
    $svsline = <SVS>;
    $unalsrcline = <SVS>;
    $svsline =~ s/^svsstr://g;
    my @svs = split " ", $svsline;
    $unalsrcline =~ s/^unaligned://;
    my %unaligned = ();
    foreach my $usrc (split " ", $unalsrcline) {
        $unaligned{$usrc} = 1;
    }
    my @swords = split " ", $srcline;
    my @spos = split " ", $posline;

    next if($#swords != $#spos or $#swords != $#svs);
    my @wordpos = ();
    for($k = 0; $k <= $#swords; $k++) {
        push @wordpos, "$swords[$k]:$spos[$k]";
    }
    #print "wdpos sent: ", join " ", @wordpos, "\n";
    foreach $pos (keys %patdic) {
        my $startpos = 0;
        my $foundp = index($posline, " $pos ", $startpos);
        while($foundp != -1) {
          #  print "matched pos: $pos\n";
          # find matched POS pattern
          my $prevstr = "";
          if($foundp > 0) {
              $prevstr = substr($posline, 0, $foundp-1);
          }
          my @prevwds = split " ", $prevstr;
          my $stp = $#prevwds+1;
          my @cpos = split " ", $pos;
          my $endp = $stp+$#cpos;
          my @cpossvs = ();

          my $srcwd_unaligned = 0;
          for(my $j=0; $j <= $#svs; $j++) {
              if($svs[$j] >= $stp && $svs[$j] <= $endp) {
                  if(exists $unaligned{$svs[$j]}) {
                      $srcwd_unaligned = 1;
                      last;
                  }
                  else {
                      push @cpossvs, $svs[$j];
                  }
              }
          }

          if(!$srcwd_unaligned) {
              my $cpossvsorder = &get_rank(@cpossvs);
              $patorderfq{$pos}{$cpossvsorder}++;
              $patorderfq{$pos}{"total"}++;
              my @cwdpos = @wordpos[$stp..$stp+$#cpos];
              my $cwdposstr = join " ", @cwdpos;

              # look for matched word:pos pattern
              if(exists $patdic{$pos}{"lex"}{$cwdposstr}) {
#                  if($cwdposstr eq "social:JJ field:NN" and $cpossvsorder eq "0 1 ") {
#                      my $dbg = 1;
#                  }
                  $patorderfq{$pos}{"lex"}{$cwdposstr}{$cpossvsorder}++;
                  $patorderfq{$pos}{"lex"}{$cwdposstr}{"total"}++;
              }
          }
          $startpos = $foundp+length($pos);
          $foundp = index($posline, $pos, $startpos);
        }

    }
}

foreach $pos (keys %patorderfq) {
    foreach my $rdrp (keys %{$patorderfq{$pos}}) {
        next if ($rdrp eq "lex");
        printf "%6.2f ||| $pos ||| $rdrp ||| $patorderfq{$pos}{$rdrp}\n",$patorderfq{$pos}{$rdrp}/$patorderfq{$pos}{"total"};
    }

    foreach my $wdp (keys %{$patorderfq{$pos}{"lex"}}) {
        foreach my $rdrp (keys %{$patorderfq{$pos}{"lex"}{$wdp}}) {
            printf "%6.2f ||| $wdp ||| $rdrp ||| $patorderfq{$pos}{\"lex\"}{$wdp}{$rdrp}\n", $patorderfq{$pos}{"lex"}{$wdp}{$rdrp}/$patorderfq{$pos}{"lex"}{$wdp}{"total"};
        }
    }
}
