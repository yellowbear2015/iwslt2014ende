#!/usr/bin/perl
while(<>) {
  if(/^\n$/) {
    print "\n";
    next;
  }
  s/\n/ /;
  print;
}
