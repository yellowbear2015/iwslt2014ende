#!/bin/bash

config=$1
data=$2
srclang=`cat $config |  grep lang_fingerprint | cut -f 2 -d '='  | cut -f 1 -d '-'`
tgtlang=`cat $config |  grep lang_fingerprint | cut -f 2 -d '='  | cut -f 2 -d '-'`
cat $data | cut -f 1 | ~/fbcode/_bin/language_technology/yoda_src/yoda_batch_runner --language_id=$srclang --key=base --usage=training >  $data.$srclang
cat $data | cut -f 2 | ~/fbcode/_bin/language_technology/yoda_src/yoda_batch_runner --language_id=$tgtlang --key=base --usage=training >  $data.$tgtlang
cat $data | cut -f 3 > $data.rating
paste $data.$srclang $data.$tgtlang > $data.$srclang-$tgtlang
~/fbcode/_build/opt/language_technology/confidence_estimation/FeatureGeneratorConsole $config $data.$srclang-$tgtlang  > $data.$srclang-$tgtlang.feat
paste -d " " $data.rating $data.$srclang-$tgtlang.feat > $data.$srclang-$tgtlang.rating_feat
