#!/bin/bash

working_dir=$1
tune_source=$2
tune_target=$3
moses_ini=$4

#perl ~/bin/FBinary/jedi/scripts/training/filter-model-given-input.pl $working_dir/model   $moses_ini $tune_source


perl ~/bin/FBinary/jedi/scripts/training/mert-moses.pl --working-dir $working_dir  --mertdir=/home/feihuang/bin/FBinary/jedi/mert --no-filter-phrase-table --decoder-flags="-threads 19" $tune_source $tune_target /home/feihuang/bin/FBinary/jedi/bin/jedi $moses_ini   --threads 19 --maximum-iterations 10 --nbest 300 --return-best-dev --batch-mira --batch-mira-args '-J 300 -C 0.001'


