#!/usr/bin/perl

#use strict;

open FILE, $ARGV[0] or die "can't open $ARGV[0]. $!";
while (<FILE>) {
	# body...
	chomp;
	my ($str, $pp) = split " ";
        $str =~ s/\./ /g;
	my @tokens = split " ",$str;
	$distance{$tokens[0]}{$tokens[8]} = $pp;
	$revdistance{$pp} .= "$tokens[0]:$tokens[8] "
}

close FILE;

my @seed = ('EG','SA','JO','IQ','MS','DZ');
#my $seed_cls_string = join " ", @seed;
my $cls_string = join " ", @seed;


my %merged = map {$_ => 1} @seed;
for $pp (sort {$a <=> $b} keys %revdistance) {
	@cpairs = split " ", $revdistance{$pp};
	foreach $cp (@cpairs) {
		print "$pp  <=> $cp\n";
		($f, $t) = split ":", $cp;
        next if ($f eq $t );
        if(exists $merged{$f} && exists $merged{$t}) {
        	next;
        }
        elsif(exists $merged{$f} && (not exists $merged{$t})) {
        	print "Merge $t into $f....\n";
        	$merged{$t} = 1;
			$cls_string =~ s/$f/$f:$t/;
		}
		elsif((not exists $merged{$f}) && exists $merged{$t}) {
        	print "Merge $f into $t....\n";
        	$merged{$f} = 1;
			$cls_string =~ s/$t/$t:$f/;
		}
		else {
			print "Generate new cluster $f-$t\n";
			$cls_string .= " $f:$t ";
		}
		print "new-class: $cls_string\n";
	}
}

my $obj = &compute_intra_dist($cls_string, %distance);
print "Initial clustering:\n";
print "$cls_string\n";
print "dist=$obj\n";

my $current_dist = $obj;
my $new_obj = $current_dist;

while($new_obj <= $current_dist) {
	my @eclus = split " ", $cls_string;
	my @new_class = ();
	foreach $cl (keys %distance) {
		for($i = 0; $i <= $#eclus; $i++) {
			my @local_c = split ":", $eclus[$i];
			$l_dist = 0;
			$min_dist = 9999999;
			$min_cls = -1;
			foreach $lc (@local_c) {
				next if($cl eq $lc);
				$l_dist += $distance{$cl}{$lc}+$distance{$lc}{$cl};
			}
			$l_dist /= ($#local_c+1);
			if($l_dist < $min_dist) {
				$min_dist = $l_dist;
				$mind_cls = $i;
			}
		}
		$new_class[$mind_cls] .= "$cl:"
	}
	$new_class_string = join " ", @new_class;
	$new_class_string =~ s/\: / /g;
	$new_obj = &compute_intra_dist($new_class_string, %distance);
	if($new_obj < $current_dist) {
		$current_dist = $new_obj;
		$cls_string = $new_class_string;
	}
	print "cls_string = $cls_string\n";
	print "dist = $obj\n";
}



sub compute_intra_dist() {
	($cls_string, %distance) = @_;
	local @clusters = split " ", $cls_string;

	my $intra_dist = 0;
	for($i = 0; $i <= $#clusters; $i++) {
		my @tempcluster = split ":", $clusters[$i];
		for($m=0; $m<= $#tempcluster; $m++) {
			for($n=$m+1; $n<=$#tempcluster; $n++){
                $a = $tempcluster[$m];
                $b = $tempcluster[$n];
				$intra_dist += $distance{$a}{$b}+$distance{$b}{$a};
			}
		}
	}
	
	return $intra_dist;
}