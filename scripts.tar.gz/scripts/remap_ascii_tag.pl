#!/usr/bin/perl

my $pretag = $ARGV[0];
my $postseg = $ARGV[1];

open PRET, $pretag or die "Can't open $pretag. $!\n";
open POST, $postseg or die "Can't open $postseg. $!\n";


while($preline = <PRET>) {
    $postline = <POST>;
    $preline =~ s/END_OF_LINE//g;
    $preline =~ s/\@ASCII\{ \}/ /g;
    $postline =~ s/\@ A S C I I \{\s+\}/ /g;
    print "$preline\n";
    print "$postline\n";
    $p0 = $preline;
    $p0 =~ s/ //g;
    $p1 = $postline;
    $p1 =~ s/ //g;
    %dict = ();
    if($p0 ne $p1) {
        print "Warning: pretag and postseg different.\n";
        print "$preline\n";
        print "$postline\n";
        next;
    }
    while($preline =~ /\@ASCII\{([\x00-\x7f]+)\}/g) {
        print "astring0 = $astring0\n";
        $astring0 = $1;
        $astring1 = $astring0;
        $astring1 =~ s/ //g;
        $dict{$astring1} = $astring0;
    }
    while($postline =~ /\@ A S C I I \{ ([\x00-\x7f]+) \} [^\x00-\x7f]/g) {
        print "ASTRING0 = $astring0\n";
        $astring0 = $1;
        $astring1 = $astring0;
        $astring1 =~ s/ //g;
        if(exists $dict{$astring1}) {
            $astring2 = $dict{$astring1};
            print "$astring0 || $astring2\n";
            $postline =~ s/@ A S C I I { \Q$astring0\E }/$astring2/g;
        }
        else {
            $postline =~ s/@ A S C I I { \Q$astring0\E }/$astring0/g;
        }
    }
    print "FINAL\t$postline";
}
