#!/usr/bin/perl

while(<>) {
  chomp;
  if(not /[\.\?!:]\s*$/) {
    print "$_ .\n";
  }
  else {
    print "$_\n";
  }
}
