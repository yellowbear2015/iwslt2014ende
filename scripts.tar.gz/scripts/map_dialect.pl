#!/usr/bin/perl

my %langmap = ();

while(<>){
#    print;
    chomp;
    s/\[//g;
    s/\]//g;
    @fields = split "\t";
    $fbid = $fields[0];
    @detected_languages = split ",", $fields[2];
    @added_languages = split ",", $fields[5];
    @removed_languages = split ",", $fields[6];
    foreach $lang ( @detected_languages ) {
        $langmap{$fbid}{$lang} = 1;
    }
    foreach $lang  ( @added_languages ) {
        $langmap{$fbid}{$lang} = 1;
    }
    foreach $lang ( @removed_languages ) {
        if($lang ne "" and exists $langmap{$fbid}{$lang}) {
            delete $langmap{$fbid}{$lang};
        }
    }
}

foreach $fbid (keys %langmap) {
    @langs = keys %{$langmap{$fbid}};
    if(scalar (@langs)) {
        print "$fbid\t", join ",", @langs, "\n";
    }
}
