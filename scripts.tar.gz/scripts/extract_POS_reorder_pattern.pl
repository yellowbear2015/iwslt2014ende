#!/usr/bin/perl
# read src, tgt ali and src_pos, find reordering phrases and their POS
# then extract word_POS pair with reordering patterns
# example: red_JJ car_NN -> car_NN red JJ given alignment 0-1 1-0

use strict;
if($#ARGV == -1) {
    print "Usage: src tgt al src_pos \n";
    exit;
}

open SRCFILE,   $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
open TGTFILE,   $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
open ALFILE,    $ARGV[2] or die "Can't open $ARGV[2]. $!\n";
open SRCPOSFILE,$ARGV[3] or die "Can't open $ARGV[3]. $!\n";

my ($srcline,$tgtline, $alline, $srcposline);
my ($i, $j, $k, $kt);

while($srcline=<SRCFILE>) {
    $tgtline=<TGTFILE>;
    $alline=<ALFILE>;
    $srcposline=<SRCPOSFILE>;
    chomp $srcline;
    my @srcwords = split " ", $srcline;
    my @align;
    my @svs;
    for($i = 0; $i <= $#srcwords; $i++) {
        push @align, [];
        push @svs, -1;
    }
    chomp $tgtline;
    my @tgtwords = split " ", $tgtline;
    chomp $alline;
    my @al = split " ", $alline;
    chomp $srcposline;
    my @srcposes = split " ", $srcposline;
    next if($#srcposes != $#srcwords);

    for($i = 0; $i <= $#al; $i++) {
        my ($s, $t) = split "-", $al[$i];
        push  $align[$s] , $t;
    }

    for($i = 0; $i <= $#srcwords; $i++) {
        my $sum = 0;
        my $talnum = $#{$align[$i]}+1;
        for(my $ii = 0; $ii < $talnum; $ii++) {
            $sum += $align[$i][$ii];
        }
        if($talnum > 0) {
            $svs[$i] = $sum / $talnum;
        }
        # more strict: only consider continuous alignment
        my $algap = $align[$i][$talnum-1]-$align[$i][0];
        if($algap > $talnum-1) {
            $svs[$i] = -1; # not sure what's the right position for $i
        }
    }
    print $srcline, "\n";
    print $tgtline, "\n";
    print $alline, "\n";
    print join " ", @svs, "\n";
    for($i = 0; $i < $#svs; $i++){
        # find reordered phrase
        for(my $j = $#svs; $j > $i; $j--) {
            if($svs[$i] > $svs[$j] && $svs[$j] != -1) {  #[$i, $t]
            # reordering start at $i and end at $j
            my %tmpmap = ();
            my $rdrwdpos = "";
            for($k = $i; $k <= $j; $k++) {
                $rdrwdpos .= "$srcwords[$k]:$srcposes[$k] ";
                $tmpmap{$k} = $svs[$k];
                if($svs[$i] == -1) {
                    $tmpmap{$i} = $tmpmap{$i-1}+0.005;
                }
            }
            my $alorder = "";
            my $nsrc;
            foreach $nsrc (sort {$tmpmap{$a} <=> $tmpmap{$b}} keys %tmpmap) {
                $alorder .= $nsrc-$i." ";
            }
            my $left = "";
            my $right = "";
            if($i == 0) {
                $left = "<s>";
            }
            else {
                $left = "$srcwords[$i-1]:$srcposes[$i-1]";
            }
            if($j == $#svs) {
                 $right = "</s>";
            }
            else {
                 $right = "$srcwords[$j+1]:$srcposes[$j+1]";
            }

            print "$left ||| $rdrwdpos ||| $right ||| $alorder\n";
            # find the max reordeing span, then move to the next span, does not allow overlap within span
            # last;
            $i = $j+1;
            }
        }
    }
    my $end_sentence = 1;
}
