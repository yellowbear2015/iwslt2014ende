#!/bin/bash

model_file = $1;
test_file  = $2;

/home/feihuang/bin/create_punc_crf_labeled_data.pl $test_file > $test_file.label
/home/feihuang/Download/crf++/bin/crf_test -m $model_file < /home/feihuang/bin/create_punc_crf_labeled_data.pl
