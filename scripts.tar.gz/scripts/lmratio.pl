#!/usr/bin/perl
open FILE1, $ARGV[0] or die;
open FILE2, $ARGV[1] or die;
open WORDLIST, $ARGV[2] or die;


my %keywords = ();

while(<WORDLIST>) {
  chomp;
  s/^\s*//;
  s/\s*$//;
  $keywords{$_} = 1;

}
while($sent=<FILE1>) {
    $sent2=<FILE2>;
    $foo=<FILE1>;
    $foo=<FILE2>;
    $lprob=<FILE1>;
    if($lprob =~ /logprob= (.+?) /) {
        $lprob1 = $1;
    }
#    print "$lprob\n$lprob1\n";
    $lprob=<FILE2>;
    if($lprob =~ /logprob= (.+?) /) {
        $lprob2 = $1;
    }
#    print "$lprob\$lprob1\n";
    $ratio = $lprob1/$lprob2;

    next if($sent =~ /file (.+?): \d+ sentences, \d+ words, \d+ OOVs/);

    @sentwords = split " ", $sent;
    $found = 0;
    foreach $sw (@sentwords) {
      if(exists $keywords{$sw}) {
        $found = 1;
        last;
      }
    }
    if($found == 0) {
      $ratio += 1.0;
    }
    print "$ratio\t$sent";
    <FILE1>; <FILE2>;
}
close FILE1;
close FILE2;
