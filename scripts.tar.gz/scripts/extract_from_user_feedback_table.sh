#!/bin/bash

cat - | perl -nae '@w = split "\t"; print "$w[7]\t$w[8]\t$w[10]\t$w[11]\t$w[14]\t$w[12]\t$w[2]\t$w[3]\t$w[0]\n";'
