#!/usr/bin/perl

while(<>) {
=for comment
    if(/^Translating: (.+?)$/) {
	print "SRC:\t$1\n";
    }
=cut
    if(/^BEST TRANSLATION: (.+?)\[/) {
	$tgttrans = $1;
#	print "TGT:\t$1\n";
    }

    if(/^Source and Target Units:(.+?)\[\[(.+?)$/) {
#	print;

	$srcsent = $1;

	print "SRC:\t$srcsent\n";
	print "TGT:\t$tgttrans\n";

	@srcwords = split " ", $srcsent;
	$featvec = "[[".$2;
	while($featvec =~ /\[\[(\d+)\.\.(\d+)\]:(.+?) :: (.+?)\]/g) {
	    $srcstart = $1;
	    $srcend = $2;
	    $tgtphr = $3;
	    $sco = $4;
	    print "[$srcstart:$srcend] ";
	    for($p = $srcstart; $p <= $srcend; $p++) {
		print "$srcwords[$p] ";
	    }
	    print "\t", $tgtphr, "\t", $sco, "\n";
	}
	print "=========================\n";
    }
}


