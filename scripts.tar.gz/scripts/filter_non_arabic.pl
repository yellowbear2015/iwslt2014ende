#!/usr/bin/perl -CSD

while(<>) {
    chomp;
    @words = split " ";
    $line = "";
    foreach $w (@words) {
        if($w =~ /\p{Arabic}/) {
            $line .= "$w ";
        }
    }
    print "$line\n";
}
