#!/usr/bin/perl

open VOC, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
while(<VOC>){
    chomp;
    #($wd, $fq) = split " ";
    s/\t/ /g;
    ($wd, $fq) = split " ";
#    ($fq, $wd) = split " ";
    $dict{$wd} = $fq;
}
close VOC;

my $oovtokenum=0;
my $oovtypenum=0;
my $toknum=0;
my $raretoknum = 0;
my $dbg = $ARGV[2];
open TXT, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
while(<TXT>) {
#    $_=lc($_);
    chomp;
    @wds = split " ";

    $toknum = scalar(@wds)+0.00000001;
    $raretoknum = 0;
    $oovtokenum = 0;
    foreach $k (@wds) {
      $txtvocab{$k} = 1;
      if(exists $dict{$k} and $dict{$k} <= 5) {
        $raretoknum++;
      }
      if(not exists $dict{$k} ) {
        $oovtokenum++;
      }
    }
    printf "$raretoknum\t$oovtokenum\t%6.2f\t%6.2f\n", $raretoknum/$toknum, $oovtokenum/$toknum;
}

close TXT;

