#!/usr/bin/perl

open BASE, $ARGV[0] or die;
while(<BASE>){
  chomp;
  ($sys, $sco) = split " ";
  $sys_scores{$sys} = $sco;
}
close BASE;

open NEW, $ARGV[1] or die;
while(<NEW>){
  ($sys, $sco) = split " ";
  print "$sys $sys_scores{$sys} $sco ", $sco-$sys_scores{$sys}, "\n";
}
close NEW;
