#!/usr/bin/perl
my %madp = ();
while(<>) {
  @w = split "\t";
  $entry = $w[0]."\t".$w[1]."\t".$w[2];
  $madp{$entry} = $w[3];
}
foreach $p (keys %madp) {
  print "$p\t$madp{$p}";
}
