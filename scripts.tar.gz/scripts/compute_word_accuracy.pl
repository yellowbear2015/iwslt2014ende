#!/usr/bin/perl

open FILE1, $ARGV[0] or die "Can't open $ARGV[0] $!\n";
open FILE2, $ARGV[1] or die "Can't open $ARGV[1] $!\n";

$correctnum = 0;
$totalnum = 0;
while($line=<FILE1>) {
    $line1 = <FILE2>;
    chomp $line;
    chomp $line1;
    @word0 = split " ", $line;
    @word1 = split " ", $line1;
    if($#word0 != $#word1) {
	print "Mismatch\n";
	print "$line0\n$line1\n";
    }
    $totalnum += $#word0+1;
    for($i = 0; $i <= $#word0; $i++) {
	if($word0[$i] eq $word1[$i]) {
	    $correctnum++;
	}
    }
}

print "Accuracy = ", $correctnum/$totalnum, "\n";
