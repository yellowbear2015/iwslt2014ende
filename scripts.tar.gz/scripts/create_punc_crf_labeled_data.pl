#!/usr/bin/perl

while(<>) {
    chomp;
    @words = split " ";
    foreach $w (@words) {
        if($w =~ /\@PUNC([,?.!])$/) {
            $tag = $1;
            $w =~ s/\@PUNC([,?.!])//;
        }
        else {
            $tag = "O";
        }
        print "$w\t$tag\n";
    }
    print "\n";
}
