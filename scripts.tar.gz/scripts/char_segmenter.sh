#!/bin/bash

cat $1 | perl -pe's// /g; while(/ \\ u ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) /) {s/ \\ u ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) / <s> \\u\1\2\3\4 <s> /g;}  s/  / <s> /g;' > $1.space
~/bin/srilm/bin/i686-m64/segment -order 20 -lm /home/feihuang/Work/Textnorm/5xvoc+top100K.train.20g.lm -text $1.space > $1.space.seg
cat $1.space.seg | perl -pe 's/ //g; s/<s>/ /g; ' > $1.seg
