#!/usr/bin/perl

open VOC, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
while(<VOC>){
    chomp;
    #($wd, $fq) = split " ";
    ($fq, $wd) = split " ";
    $dict{$wd} = $fq;
}
close VOC;

open TXT, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
while(<TXT>) {
    $_=lc($_);
    chomp;
    @wds = split " ";
    $newsent = "";
    foreach $k (@wds) {
      if(exists $dict{$k}) {
          $newsent .= "$k "
      }
      else {
          $newsent .= "<unk> ";
      }
    }
    $newsent =~ s/ $//;
    print $newsent, "\n";
}

close TXT;
