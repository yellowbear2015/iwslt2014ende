#!/bin/env perl

my $sum = 0;
my $count  = 0;
my @eles;
my $outrageous = 0;

while(<>) {
    chomp;
    push @eles, $_;
    $sum += $_;
    $count ++;
}

my $avg = $sum / $count;

my $sumvar = 0;

foreach $el (@eles) {
    $sumvar += ($el - $avg) * ($el - $avg);
}

my $var = sqrt($sumvar / $count);
my $ci95 = 1.96 * $var / sqrt($count);

print "$sum\t$avg", "+/-", $ci95, "\t$var\t\n";
