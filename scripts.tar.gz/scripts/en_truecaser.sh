#!/bin/bash
/home/feihuang/bin/FBinary/jedi/bin/jedi -f /mnt/vol/language_technology_mt/caserestore/en/moses.kenlm.ini -threads 8 < $1 > $2
