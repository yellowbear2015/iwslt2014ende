#!/usr/bin/perl

open RATING, $ARGV[0] or die;
open SAMPLE, $ARGV[1] or die;
my %rating_map={};
while(<RATING>){
  #print;
  chomp;
  ($fbid, $src, $tgt, $sl, $tl, $rating, $type) = split "\t";
  if($rating > 5) {
    $rating /= 20.0;
  }
  $rating_map{$fbid}{$sl}{$tl}{$type}  += $rating;
  $rating_counter{$fbid}{$sl}{$tl}{$type}  += 1;
#  print "$fbid\t$type\t$rating_map{$fbid}{$sl}{$tl}{$type}\t$rating_counter{$fbid}{$sl}{$tl}{$type}\n";
}
close RATING;
#print "start adding...\n";
while(<SAMPLE>){
  chomp;
  $line = $_;
  chomp $line;
  @fd = split "\t";
  # print "$fd[0]\t$fd[1]\t$fd[3]\n";
  if(exists $rating_map{$fd[0]} and
    exists $rating_map{$fd[0]}{$fd[1]} and
    exists $rating_map{$fd[0]}{$fd[1]}{$fd[3]}) {
      foreach $type (keys %{$rating_map{$fd[0]}{$fd[1]}{$fd[3]}}) {
        $fbid=$fd[0];
        $sl=$fd[1];
        $tl=$fd[3];
        #        print "$rating_map{$fbid}{$sl}{$tl}{$type}\n";
        #  print "$rating_counter{$fbid}{$sl}{$tl}{$type}\n";
          $avg_rating = $rating_map{$fbid}{$sl}{$tl}{$type}/$rating_counter{$fbid}{$sl}{$tl}{$type};
          print $line;
          print "\t$type\t$avg_rating\n";
        }
  }
}
close SAMPLE;
