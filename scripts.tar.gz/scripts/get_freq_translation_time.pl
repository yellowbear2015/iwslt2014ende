#!/usr/bin/perl

open FILE, $ARGV[0] or die;
while(<FILE>) {
    chomp;
    ($fq, $fbid) = split ;
    $freq{$fbid} = $fq;
}

close FILE;

open FILE1, $ARGV[1] or die;
while(<FILE1>) {
    my @w = split ;
    $gap = $w[3]-$w[4];
    if($gap > 0 && $freq{$w[0]} < 100) {
        print $gap, "\n";
    }
}
close FILE1;
