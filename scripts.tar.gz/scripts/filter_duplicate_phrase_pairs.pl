#!/usr/bin/perl

use strict;

my $line = <>;
my $delnum = 0;
my $oldsrc = "";
my $newline;
while($newline=<>) {
  my @w = split "\Q|||\E", $line; 
  $w[0] =~ s/^\s+//g; 
  $w[1] =~ s/^\s+//g; 
  $w[0] =~ s/\s+$//; 
  $w[1] =~ s/\s+$//; 
  my @nw = split "\Q|||\E", $newline;
  $nw[0] =~ s/^\s+//g;
  $nw[0] =~ s/\s+$//;
  if(($w[0] eq $w[1]) && ($nw[0] ne $w[0]) && ($oldsrc ne $w[0])) {
    #print STDERR "del\t", $line;
    $delnum ++;
  }
  else {
    print $line;
  }
  $line = $newline;
  $oldsrc = $w[0];
}
print $line;

print STDERR "remove $delnum phrase pairs...\n";
