#!/usr/bin/perl

open VOC, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
$rank = 0;
while(<VOC>){
    chomp;
    #($wd, $fq) = split " ";
    s/\t/ /g;
    ($wd, $fq) = split " ";
#    ($fq, $wd) = split " ";
    $dict{$wd} = $fq;
    $Rank{$wd} = $rank++;
}
close VOC;

$cutoff = $ARGV[2];

open TXT, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
open POS, $ARGV[3] or die "Can't open $ARGV[3]. $!\n";
while(<TXT>) {
#    print;
#    $_=lc($_);
    $sent = $_;
    chomp;
    @wds = split " ";
    $pos_sent=<POS>;
    chomp $pos_sent;
#    print "$sent\n$pos_sent\n";
    @pos = split " ", $pos_sent;
    if($#wds ne $#pos) {
      print STDERR $sent;
      print STDERR join " ", @pos;
      print STDERR "Mismatch Sentence and POS. $!\n";
      next;
    }
    $sent = "";
    for($i = 0; $i <= $#wds; $i++) {
      $k = $wds[$i];
      if(exists $dict{$k} and $Rank{$k} <= $cutoff) {
          $sent .= "$k ";
      }
      else {
        $sent .= "$pos[$i] ";
      }
    }
    print "$sent\n";
}


