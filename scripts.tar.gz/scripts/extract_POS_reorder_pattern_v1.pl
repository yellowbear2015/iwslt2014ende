#!/usr/bin/perl
# read src, tgt ali and src_pos, find reordering phrases and their POS
# then extract word_POS pair with reordering patterns
# example: red_JJ car_NN -> car_NN red JJ given alignment 0-1 1-0
use List::Util qw(first);
use strict;
if($#ARGV == -1) {
    print "Usage: src tgt al src_pos \n";
    exit;
}

open SRCFILE,   $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
open TGTFILE,   $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
open ALFILE,    $ARGV[2] or die "Can't open $ARGV[2]. $!\n";
open SRCPOSFILE,$ARGV[3] or die "Can't open $ARGV[3]. $!\n";

my ($srcline,$tgtline, $alline, $srcposline);
my ($i, $j, $k, $kt);

while($srcline=<SRCFILE>) {
    $tgtline=<TGTFILE>;
    $alline=<ALFILE>;
    $srcposline=<SRCPOSFILE>;
    chomp $srcline;
    chomp $tgtline;
    my @srcwords = split " ", $srcline;
    my @tgtwords = split " ", $tgtline;
    my @align;
    my @svs;
    my @t2s;
    for($i = 0; $i <= $#tgtwords; $i++) {
        push @t2s, "";
    }
    chomp $tgtline;
    my @tgtwords = split " ", $tgtline;
    chomp $alline;
    my @al = split " ", $alline;
    chomp $srcposline;
    my @srcposes = split " ", $srcposline;
    next if($#srcposes != $#srcwords);

    for($i = 0; $i <= $#al; $i++) {
        my ($s, $t) = split "-", $al[$i];
        $t2s[$t].= "$s ";
    }

    for($i = 0; $i <= $#tgtwords; $i++) {
        push @svs, split " ", $t2s[$i];
    }
    print $srcline, "\n";
    print $srcposline, "\n";
    print $tgtline, "\n";
    print $alline, "\n";
    print join " ", @svs, "\n";
    for($i = 0; $i < $#svs; $i++){
        # find reordered phrase
        for(my $j = $#svs; $j > $i; $j--) {
            if($svs[$i] > $svs[$j] && $svs[$j] != -1) {  #[$i, $t]
            # reordering start at $svs[$i] and end at $svs[$j]
            my @rdrsvs = @svs[$i..$j];
            my @rdrsvssort = sort @rdrsvs;
            my %tmpmap = ();
            my $start = $rdrsvssort[0];
            my $end = $rdrsvssort[$#rdrsvssort];
            my $rdrwdpos = "";
            my @alorder = ();
            for($k = $start; $k <= $end; $k++) {
                $rdrwdpos .= "$srcwords[$kk]:$srcposes[$kk] ";
                my $idx = first { $rdrsvssort[$_] eq $rdrsvs[$k] } 0..$#rdrsvssort;
                push @alorder, $idx;
            }
            
            
            for($k=0; $k <= $#alorder; $k++) {
              if($alorder[$k] eq undef) {
                $alorder[$k] = $alorder[$k-1];
              }
            }
            
            my $alodrpat = join " ", @alorder;

            print $alorder, "\n";
            my $left = "";
            my $right = "";
            my $leftpos = $rdrsvssort[0];
            my $rightpos = $rdrsvssort[$#rdrsvssort];
            if($leftpos == 0) {
                $left = "<s>";
            }
            else {
                $left = "$srcwords[$leftpos-1]:$srcposes[$leftpos-1]";
            }
            if($rightpos == $#srcwords) {
                 $right = "</s>";
            }
            else {
                 $right = "$srcwords[$rightpos+1]:$srcposes[$rightpos+1]";
            }

            print "$left ||| $rdrwdpos ||| $right ||| $alorderpat\n";
            # find the max reordeing span, then move to the next span, does not allow overlap within span
            # last;
            $i = $j+1;
            }
        }
    }
    my $end_sentence = 1;
}
