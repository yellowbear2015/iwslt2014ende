#!/usr/bin/python                                                                                                                                                                

import nltk
import string

from nltk.corpus import stopwords
from nltk.stem.porter import *
from nltk.stem.snowball import SnowballStemmer

stemmer = SnowballStemmer("english")
    
    
with open(sys.argv[1], 'r') as file:
    for line in iter(lambda: file.readline(), ''):
       #print "Orig: ", line
       words = line.decode('utf-8').split();
       #filtered = [w for w in words if not w in stopwords.words('english')]
       #print " ".join(filtered)
       stemmed = ""
       for word in words:
          stemmed += stemmer.stem(word)+" "
       print stemmed.encode('utf-8')
