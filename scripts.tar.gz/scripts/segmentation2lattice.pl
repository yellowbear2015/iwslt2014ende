#!/usr/bin/perl -CSD
use FileHandle;
use Encode;


#$content = decode('UTF-8', $content);

binmode *STDOUT, ':encoding(UTF-8)';

#use strict;
if($#ARGV == -1) {
  print "Usage: char_input segment1 segment2 ...\n";
  exit;
}


my @FileHandles;
for($i = 0; $i <= $#ARGV; $i++) {
  my $fh = FileHandle->new;
  if($fh->open($ARGV[$i])) {
      push @FileHandles, $fh;
  }
}

while($line0 = $FileHandles[0]->getline) {
    $line0 = decode('UTF-8', $line0);
    print $line0;
    chomp $line0;
    @minwords = split " ", $line0;
    %lattice = ();
=for comment
    for($i = 0; $i < $#minwords; $i++) {
        $lattice{$i}{$minwords[$i]} = 1;
    }
=cut
    for($i = 1; $i <= $#ARGV; $i++) {
        $line = $FileHandles[$i]->getline;
        $line = decode('UTF-8', $line);
        print $line;
        chomp $line;
        @words = split " ", $line;
        my $s = 0;
        my $t = 1;
        my $cword = $minwords[$s];
        for($m = 0; $m <= $#words; $m++) {
            $not_found_flag = 0;
            while($words[$m] ne $cword) {
                $cword .= $minwords[$t];
                if($t > $#minwords) {
                    print "Error! Did not find matching substring.\n";
                    print "$words[$m] <- $cword\n";
                    print "$line0\n$line\n";
                    $not_found_flag = 1;
                    last;
                }
                else {
                    $t++;
                }
            }
            if($not_found_flag) {
                last;
            }
#            $cword = decode('UTF-8', $cword);
            if(! $not_found_flag) {
#                print "$cword $t $s\n";
                $lattice{$s}{$cword} = $t-$s;
                $s = $t;
                $cword = "";
            }
        }
    }
    print "LATTICE:(\n";
    foreach $start (sort{$a<=>$b} (keys %lattice)) {
        print "(\n";
        foreach $word (keys %{$lattice{$start}}) {
#                print "$word\n";
            print "(\'$word\',1.0,$lattice{$start}{$word}),\n";
        }
        print "),\n";
    }
    print ")\n";
    print "\n==============================\n";
}

foreach $fh (@FileHandles) {
    $fh->close();
}
