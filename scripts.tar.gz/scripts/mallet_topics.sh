#!/bin/bash
dir=`pwd`
cd /home/feihuang/Download/Mallet/mallet-2.0.6/
cat $1 | perl -nae 'print "facebook post "; print;' > $1.mallet_input
./bin/mallet import-file --input $1.mallet_input --output $1.mallet_output --keep-sequence --remove-stopwords
./bin/mallet train-topics --input $1.mallet_output  --num-topics 20 --output-topic-keys $1.mallet_topics
cd $dir
