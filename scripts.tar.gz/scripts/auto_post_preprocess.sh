#!/bin/bash

~feihuang/bin/preprocess_fbpost_twokenize.sh $1 
cat $1.twtok | ~/bin/lc.sh | ~/bin/remove_qoutmark_wrapper.pl | ~feihuang/bin/text_normalizer_step1.pl  | perl -pe 's/^\s*\#/\\#/g;' > $1.proc
