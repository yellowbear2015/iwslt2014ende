#!/usr/bin/perl

open WORD, $ARGV[0];
open POS, $ARGV[1];
$sentid = 0;
while($wordline=<WORD>) {
  $posline = <POS>;
  $sentid++;
  chomp $wordline;
  chomp $posline;
  @wds = split " ", $wordline;
  @poses = split " ", $posline;
  if($#wds != $#poses) {
    print "Mismatch $sentid\n";
    print "$wordline\n";
    print "$posline\n";
  }
}
close WORD;
close POS;
