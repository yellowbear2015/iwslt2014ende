#!/usr/bin/perl -w

open DATA, $ARGV[0] or die;
while(<DATA>) {
    ($rating, $srcsent, $tgtsent) = split "\t";
    @words = split " ", $srcsent;
    foreach $w (@words) {
        $dict{$w} = 1;
    }
}
close DATA;

open VOCAB, $ARGV[1] or die;
while(<VOCAB>) {
    ($wd, $freq) = split "\t";
    if(exists $dict{$wd}) {
        print;
    }
}

close VOCAB;
