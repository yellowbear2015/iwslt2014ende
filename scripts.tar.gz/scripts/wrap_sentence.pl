#!/usr/bin/perl
#
my $file = $ARGV[0];

my $maxlen = $ARGV[1];

$maxlen = 250 if($maxlen eq "");

open FILE, $file or die "Can't open $file. $!\n";
while(<FILE>) {
    chomp;
    @words = split " ";
    for($u = 1; $u*$maxlen < $#words; $u++) {
        $words[$u*$maxlen] .= "\n";
    }
    print join " ", @words;
    print "\n";
}
