#!/usr/bin/perl

#@feihuang
#2013/03/26
#


use strict;

my $readphrnum = 0;
my $writephrnum = 0;
my $p;
while(<>) {
    $readphrnum ++;
    my @w = split "\Q|||\E"; 
    next if($#w < 4 );
    $w[0] =~ s/\|/&#124;/g;
   # $w[0] =~ s/^\| /&#124; /g;
   # $w[0] =~ s/^\s+//;
   # $w[0] =~ s/\s*$//;
    next if($w[0] eq "" || $w[0] =~ /\[(.*?)\]/);
    $w[1] =~ s/\|/&#124;/g;
    #$w[1] =~ s/^\| /&#124; /g;
    #$w[1] =~ s/^\s+//;
    #$w[1] =~ s/\s*$//;

    next if($w[1] eq "" || $w[1] =~ /\[(.*?)\]/);
    for($p = 0; $p < $#w; $p++) {
	    print "$w[$p]|||";
    }
    print "$w[$#w]";
    $writephrnum ++;
}

print STDERR "read phrase pairs = $readphrnum\nwrite phrase pairs = $writephrnum\nthrow-away phrase pairs=",$readphrnum-$writephrnum, "\n";
