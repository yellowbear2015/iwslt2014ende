#!/bin/sh

cat $1 | perl -pe 's/\|//g;' 
