#!/usr/bin/perl

#use strict;

open FILE, $ARGV[0] or die "can't open $ARGV[0]. $!";
while (<FILE>) {
	# body...
	chomp;
	my ($str, $pp) = split " ";
        $str =~ s/\./ /g;
	my @tokens = split " ",$str;
	$distance{$tokens[0]}{$tokens[5]} = $pp;
	$revdistance{$pp} .= "$tokens[0]:$tokens[5] "
}

close FILE;

my @seed = ['EG','SA','JO','IQ'];

my $cls_string = join " ", (keys %distance);
my $obj = &compute_dist($cls_string, %distance);
print "$cls_string\n";
print "dist=$obj\n";

my %merged = ();
for $pp (sort {$a <=> $b} keys %revdistance) {
	@cpairs = split " ", $revdistance{$pp};
	foreach $cp (@cpairs) {
		($f, $t) = split ":", $cp;
                next if ($f eq $t);
                if (exists $merged{$t} ){
                    next;
                }
		$new_cls_str = $cls_string;
		$new_cls_str =~ s/$f/$f:$t/;
		$new_cls_str =~ s/ $t / /;
		print "new-class: $new_cls_str\n";
		$new_obj = &compute_dist($new_cls_str, %distance);
		print "dist=$new_obj\n";
#		if($new_obj > $obj){
			$obj = $new_obj;
			$cls_string = $new_cls_str;
                $merged{$t} = 1;
#		}
	}
}

print "cls_string = $cls_string\n";
print "dist = $obj\n";




sub compute_dist() {
	($cls_string, %distance) = @_;
	local @clusters = split " ", $cls_string;
	my $inter_num = 0;
	my $inter_dist = 0;
	for($i = 0; $i <= $#clusters; $i++) {
		for($j = $i+1;$ j <= $#clusters; $j++){
			foreach $a (split ":", $clusters[$i]) {
				foreach $b (split ":", $clusters[$j]) {
					$inter_dist += $distance{$a}{$b}+$distance{$b}{$a};
					$inter_num++;
				}
			}
		}
	}
	$inter_dist /= $inter_num;

	my $intra_dist = 0;
	my $intra_num = 0;
	for($i = 0; $i <= $#clusters; $i++) {
		my @tempcluster = split ":", $clusters[$i];
		for($m=0; $m<= $#tempcluster; $m++) {
			for($n=$m+1; $n<=$#tempcluster; $n++){
                            $a = $tempcluster[$m];
                            $b = $tempcluster[$n];
				$intra_dist += $distance{$a}{$b}+$distance{$b}{$a};
				$intra_num++;
			}
		}
	}
	$intra_dist /= $intra_num if ($intra_num > 0);
	my $obj = $inter_dist-$intra_dist;
	return $obj;
}
