#!/bin/bash
cat $1 | perl -nae 's/\@(MULTIPUNCT|hashtag|HASHTAG|DIGITS|EMOTICON|URL) \{ (.+?) # (.+?) \)/ \@\1 /g; print'
