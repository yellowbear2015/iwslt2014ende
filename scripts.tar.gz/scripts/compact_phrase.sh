#/bin/bash

phrasetable=$1
reordertable=$2
outdir=$3

phrasename=`basename $phrasetable`
reordername=`basename $reordertable`

zcat -f $phrasetable | LC_ALL=C sort > $outdir/f00.$$

~/bin/FBinary/jedi/misc/processPhraseTableMin \
    -in $outdir/f00.$$ \
    -out $outdir/$phrasename.sorted \
    -nscores 4 -threads 8

~/bin/FBinary/jedi/misc/processLexicalTableMin \
    -in $reordertable \
    -out $outdir/$reordername \
    -threads 8
