#!/usr/bin/perl

use strict;

open FILE, $ARGV[0] or die;



my %dict = ();
my $fsm_flag = 0;
my $sentid = -1;
while(<FILE>) {

    if(/END_OF_FSM/) {
        $fsm_flag = 0;
        close NFSM;
        my $t = 1;
        open DICT, ">$ARGV[0].$sentid.sym" or die;
        foreach my $d (keys %dict) {
            next if($d eq "");
            print DICT "$d $t\n";
            $t++;
        }
        close DICT;
        system("/home/feihuang/bin/make_fsm_ps_nbest.sh $ARGV[0].$sentid.sym $ARGV[0].$sentid.st >> $ARGV[0].rdrgraph.1best");
        system("rm $ARGV[0].$sentid.*");
    }
    if(/BEING_OF_FSM/){
        print STDERR "processing $sentid sentence...\n" if($sentid++ % 100 == 0);
        <FILE>;
        $fsm_flag =1;
        $sentid++;
        open NFSM, ">$ARGV[0].$sentid.st" or die;
        %dict = ();
        next;
    }
    if($fsm_flag == 1) {
        my @w = split "\t";
        if($#w == 3 ) {
            $w[2] =~ s/ /ReplaceWhiteSpaceToMakeFSMHappy/g;
            #$w[2] =~ s/ /_/g;
            $dict{$w[2]} = 1;
        }
        print NFSM join "\t", @w;
    }

}


close DICT;
