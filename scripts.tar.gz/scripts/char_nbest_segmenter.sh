#!/bin/bash

cat $1 | tr "[A-Z]" "[a-z]" | perl -pe's// /g; while(/ \\ u ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) /) {s/ \\ u ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) ([0-9a-f]) / <s> \\u\1\2\3\4 <s> /g;}  s/  / <s> /g;' > $1.space
~feihuang/bin/srilm/bin/i686-m64/hidden-ngram -order 10 -lm /home/feihuang/Work/Textnorm/5xvoc+top100K.train.20g.lm -text $1.space -hidden-vocab /home/feihuang/Work/Textnorm/wordseg/seg_vocab -nbest 50 > $1.space.seg.nblog
cat $1.space.seg.nblog | cut -f 3- -d ' ' | perl -pe 's/ //g; s/<s>/ /g; s/<\/s>/ /g;' > $1.nbest.seg
~feihuang/bin/srilm/bin/i686-m64/ngram -lm /home/feihuang/Work/LMs/post.20140310.en.13M.unescape.tp_noNE.3g.srilm -ppl $1.nbest.seg -debug 1  > $1.nbest.seg.ppl
perl ~feihuang/bin/select_best_segmentation_with_lmppl.pl  $1.space.seg.nblog $1.nbest.seg.ppl | cut -f 2 > $1.seg
rm $1.space* $1.nbest.seg*
