#!/usr/bin/perl

while(<>) {
 chomp;
 @words = split " ";
 for($i = 0; $i <= $#words; $i++) {
   print "$i-$i ";
 }
 print "\n";
}
