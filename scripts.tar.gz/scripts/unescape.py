#!/usr/bin/python

# Converts Unicode-escaped text to UTF-8

import sys

input=open(sys.argv[1])
output=open(sys.argv[2], "w")

# Byte order mark (needed by Excel to correctly recognize the encoding)
output.write('\xEF\xBB\xBF')

for line in input:
    unescaped = line.strip().decode('unicode_escape').replace('\n', ' ').encode('utf-8')
    output.write(unescaped + '\n')
