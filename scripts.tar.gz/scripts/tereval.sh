#!/bin/tcsh

echo "Evaluate TER.."
echo "ref is $1"
echo "hyp is $2"


head -n `wc -l $2 | cut -f 1 -d " "` /home/feihuang/bin/sentid_60k > $2.sentid

paste -d " " $1 $2.sentid > $1.4scr
paste -d " " $2 $2.sentid > $2.4scr

/home/feihuang/bin/tercom_v6b.pl -s -r $1.4scr -h $2.4scr
tail -n 2 $2.4scr.*sum
