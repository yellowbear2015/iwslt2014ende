#!/usr/bin/perl

while(<>) {
  s/^\s*\"{1,}//g;
  s/\"{1,}\s*$/\n/g;
  print $_;
}
