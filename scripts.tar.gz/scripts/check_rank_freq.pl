#!/usr/bin/perl

open VOC, $ARGV[0] or die "Can't open $ARGV[0]. $!\n";
while(<VOC>){
    chomp;
    #($wd, $fq) = split " ";
    s/\t/ /g;
    ($rank, $wd, $fq) = split " ";
#    ($fq, $wd) = split " ";
    $dict{$wd} = $fq;
    $rankdict{$wd} = $rank;
}
close VOC;

$dbg = $ARGV[2];
open TXT, $ARGV[1] or die "Can't open $ARGV[1]. $!\n";
while(<TXT>) {
#    $_=lc($_);
    $words = $_;
    chomp;
    @wds = split " ";
    $max_rank = 999999;
    $sum_rank = 0;
    $total_k = 0;
    foreach $k (@wds) {
      if(exists $dict{$k}) {
        $sum_rank += $rankdict{$k};
        $total_k ++;
      }
    }
    $average_rank = $sum_rank / $total_k;
    
        #    print "$k $dict{$k} $rankdict{$k}\n"; 
        #     if($rankdict{$k} < $max_rank) {
        #  $max_rank = $rankdict{$k};
        #  $max_word = $k;
#        }
#      }
#    }
#    print "$max_rank\t$max_word\t$words"; 
    print "$average_rank\t$words";
}

close TXT;

