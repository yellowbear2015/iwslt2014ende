#!/bin/bash
python ~/bin/unescape-unicode.py $1 $1.utf8
cat $1.utf8 |  perl -nae 'next if (!/[a-z]/); print;' | perl -nae 'next if (!/[A-Z]/); print;' > $1.utf8.camel
~/fbcode/_bin/language_technology/yoda ~/Work/Case_Restore/ddinf/tp-gen-es-033114.case/ inscript $1.utf8.camel |  perl -pe 's/([a-zA-Z])\1{2,}/\1\1/g; s/\[(.+)\]/[ \1 ]/g; while(/\{\{/) {s/\{\{/{/g;}; while(/\}\}/) {s/\}\}/}/g;}' | perl -nae 'chomp; print "<s> $_ </s>\n";'
