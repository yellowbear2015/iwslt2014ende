#!/usr/bin/perl
$sentid = 0;
while(<>) {
  print STDERR "reading $sentid sentences\n" if ($sentid++ % 10000 == 0);
  chomp;
  @wds = split " ";
  foreach $w (@wds) {
    $voc{$w}++;
  }
}
my $totalwords = 0;
foreach $w (sort {$voc{$b} <=> $voc{$a}} keys %voc) {
  print "$w\t$voc{$w}\n";
  $totalwords += $voc{$w};
}

print STDERR "Total sentences read: $sentid\n";
print STDERR "Total word types: ", scalar (keys %voc), "\n";
print STDERR "Total word tokens: $totalwords\n";
