#!?usr/bin/perl

use FileHandle;
use strict;

open FILE, $ARGV[0] or die;
my %langdict = {};
while(<FILE>) {
    my @df = split "\t";
    my $src = shift @df;
    my $tgt = shift @df;
    my $newstr = join "\t", @df;
    my $langid = $src."_".$tgt;
    my $outfile = $ARGV[0].".".$langid;
    if(not exists $langdict{$langid}) {
        my $fh = FileHandle->new("> $outfile");
        $langdict{$langid} = $fh;
        print $fh $newstr;
    }
    else {
        print {$langdict{$langid}} $newstr;
    }
}

my $fh;
foreach $fh (keys %langdict) {
    undef $fh
}
