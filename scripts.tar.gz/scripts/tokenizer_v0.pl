#!/usr/bin/perl
use strict;

my $w;

while(<>) {
  #print;
  chomp;
  my @words = split " ";
  foreach $w (@words) {
    if($w =~ /(http|https|ftp)/i) {
      print "$w ";
    }
    elsif ($w =~ /\w+@\w+.(com|edu|gov|org|net)/) {
      print "$w ";
    }
    else {
      $w = &tokenize($w);
      print "$w ";
    }
   }
    print "\n";
 }

sub tagging() {
  my $inline = shift @_;
  $inline =~ s#(https|http):(.+?) #\@URL #g;
  $inline =~ s#(www).(.+?) #\@URL #gi;
  return $inline;
}

sub tokenize() {
  my $inline = shift @_;
#  $inline =~ s/^\"\"\"/ /;
#  $inline =~ s/\"\"\"$/ /;
  $inline =~ s/\\n/\n/g;
#  $inline =~ s/\\u([0-9a-fA-F]{4})//g;  
  $inline =~ s#\\/#/#g;
  $inline =~ s/\\""/"/g;
#  s/[,\?\!]/ \1 /g;
#  s/\. / \. /g;
  $inline =~ s/([a-zA-Z]+)/ \1 /g;
  $inline =~ s/ +/ /g;
#  $inline =~ s/ \\ u([0-9a-fA-F]{4}) / \\u\1 /g;  
  $inline =~ s/ ' (s|ve|ll|re|d) / '\1 /g;
  $inline =~ s/n ' t /n't /g; 
  $inline =~ s/I ' m /I 'm /g; 
  $inline =~ s/\@ URL /\@URL /g;
  $inline =~ s/^\s*//;
  #print;
  return $inline;
}
