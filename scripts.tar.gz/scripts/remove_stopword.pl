#!/usr/bin/perl

open STOPWORD, $ARGV[0];
while(<STOPWORD>) {
    chomp;
    $dict{$_} = 1;
}

close STOPWORD;

open FILE, $ARGV[1];
while(<FILE>) {
    @w = split " ";
    print if(not exists $dict{$w[0]});
}
close FILE;
