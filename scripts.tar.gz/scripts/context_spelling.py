import sys

def insert_dict(context, word, grams):
    if context in grams:
        if word in grams[context]:
            grams[context][word] += 1
        else:
            grams[context][word] = 1
    else:
        grams[context] = {}
        grams[context][word] = 1

def print_dict(grams, file):
    for f in sorted(grams):
        for j in sorted(grams[f]):
            file.write('{0} {1} {2}\n'.format(f, j, grams[f][j]))



left_bigram = {}
left_trigram = {}
right_bigram = {}
right_trigram = {}
central_trigram = {}
for f in open(sys.argv[1]).readlines():
    words = f.rstrip().split(' ')
    words.insert(0,'<bos>')
    words.append('<eos>')
    for i in range(len(words)):
        if i >= 1 and i < len(words)-1:
            cword = words[i]
            left_context = words[i-1]
            right_context = words[i+1]
            center_context = left_context + ':' + right_context
            insert_dict(left_context, cword, left_bigram)
            insert_dict(right_context,cword, right_bigram)
            insert_dict(center_context, cword, central_trigram)
            if i >= 2 and i < len(words)-2:
                left2 = words[i-2] + ':'+ words[i-1]
                right2 = words[i+1] + ':' + words[i+2]
                insert_dict(left2, cword, left_trigram)
                insert_dict(right2, cword, right_trigram)

with open(sys.argv[1]+'.left_bigram', 'w') as m:
    print_dict(left_bigram, m)

with open(sys.argv[1]+'.right_bigram', 'w') as m:
    print_dict(right_bigram, m)

with open(sys.argv[1]+'.central_trigram', 'w') as m:
    print_dict(central_trigram, m)

with open(sys.argv[1]+'.left_trigram', 'w') as m:
    print_dict(left_trigram, m)

with open(sys.argv[1]+'.right_trigram', 'w') as m:
    print_dict(right_trigram, m)
