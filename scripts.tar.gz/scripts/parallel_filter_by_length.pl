#!/usr/bin/perl
open FILE0, $ARGV[0] or die;
open FILE1, $ARGV[1] or die;
open FILE2, ">$ARGV[2]" or die;
open FILE3, ">$ARGV[3]" or die;

$max_len=175;

if($ARGV[4] ne "") {
  $max_len = $ARGV[4];
}
while($src=<FILE0>) {
  $tgt=<FILE1>;
  @srcwords = split " ", $src;
  @tgtwords = split " ", $tgt;
  if($#srcwords <= $max_len && $#tgtwords <= $max_len) {
    print FILE2 $src;
    print FILE3 $tgt;
  }
}
close FILE1;
close FILE2;
close FILE3;
close FILE4;

