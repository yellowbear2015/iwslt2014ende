#!/usr/bin/perl
my $skipnum = 0;
while(<>) {
  @words = split " ";
  if($#words > 250) {
    $skipnum++;
    next;
  }
  my $newsent = "";
  for($i = 0; $i <= $#words; $i++) {
    if(length($words[$i]) > 128) {
      $words[$i] = substr($words[$i], 0, 128);
    }
  }
  $newsent = join " ", @words;
  print "$newsent\n";
}
print STDERR "Skipped $skipnum sentences. \n";
