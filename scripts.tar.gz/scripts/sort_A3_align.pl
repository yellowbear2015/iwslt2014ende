#!/usr/bin/perl
my @all;
while(<>) {
  if(/^# Sentence pair \((\d+)\)/) {
    $line = $_;
    $sentid = $1;
    $line .= <>;
    $line .= <>;
    $all[$sentid] = $line;
#    print "$sentid\n$line";
  }
}

for($i = 0; $i <= $#all; $i++) {
    print $all[$i];
}
