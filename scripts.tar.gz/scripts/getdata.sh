#!/bin/bash
#source /mnt/vol/hive/dis/lib/utils/hive.include

# 1) get data from hive table
echo "Step (1): Get data from Hive according to the query request..."
echo "hive --namespace bi -e \"SELECT b.text, a.dob_year, a.city_from_ip, a.country, b.gender, b.age_bracket, b.region_name, b.content_sentiment, b.sentiment_confidence, b.predicted_language FROM  dim_all_users a JOIN chorus_content_stories b ON a.userid=b.actor_id $2 LIMIT 5000000\"" 
hive --namespace bi -e "SELECT b.text, a.dob_year, a.city_from_ip, a.country, b.gender, b.age_bracket, b.region_name, b.content_sentiment, b.sentiment_confidence, b.predicted_language FROM  dim_all_users a JOIN chorus_content_stories b ON a.userid=b.actor_id $2 LIMIT 5000000" 
