#!/usr/bin/perl
while(<>) {
#    print;
    @data = split " ";
    if($data[0] == 0) {
        print "-1\n";
    }
    else {
        for($i = 1; $i <= $#data; $i++) {
            $data[$i]/=$data[0];
        }
        $idxMax=1;
        $data[$idxMax] > $data[$_] or $idxMax = $_ for 2 .. $#data;
#        print $idxMax-1, "\t", $data[$idxMax], "\n";
        if($data[$idxMax] <= -20.0) {
            print "5\n";
        }
        else {
            print $idxMax-1, "\n";
        }
    }
}
