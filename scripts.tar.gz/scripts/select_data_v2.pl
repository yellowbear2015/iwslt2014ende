#!/usr/bin/perl
open FILE, $ARGV[0] or die;
while(<FILE>) {
  ($fbid, $src, $tgt) = split "\t", $_;
  $alldata{$fbid}  = $_;
}
close FILE;


open FILE2, $ARGV[1] or die;

while(<FILE2>) {
  ($conf, $fbid, $src, $tgt) = split "\t", $_;
  if(exists $alldata{$fbid}) {
    print "$conf\t$alldata{$fbid}";
  } 
}
close FILE2;
